<?php
include('../include/session.php');

unset($_SESSION['error']);

ini_set('display_errors', 'On');
error_reporting(E_ALL); ?>
<head>
    <style>
        .wrapper{
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            width: 400px;
            margin: 50vh auto 0;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-transform: translateY(-50%);
            transform: translateY(-50%);
        }

        .switch_box{
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            max-width: 200px;
            min-width: 200px;
            height: 200px;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
        }

        /* Switch 1 Specific Styles Start */

        .box_1{
            background: #eee;
        }

        input[type="checkbox"].switch_1{
            font-size: 15px;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            width: 3.5em;
            height: 1.5em;
            background: #ddd;
            border-radius: 3em;
            position: relative;
            cursor: pointer;
            outline: none;
            -webkit-transition: all .2s ease-in-out;
            transition: all .2s ease-in-out;
        }

        input[type="checkbox"].switch_1:checked{
            background: #0ebeff;
        }

        input[type="checkbox"].switch_1:after{
            position: absolute;
            content: "";
            width: 1.5em;
            height: 1.5em;
            border-radius: 50%;
            background: #fff;
            -webkit-box-shadow: 0 0 .25em rgba(0,0,0,.3);
            box-shadow: 0 0 .25em rgba(0,0,0,.3);
            -webkit-transform: scale(.7);
            transform: scale(.7);
            left: 0;
            -webkit-transition: all .2s ease-in-out;
            transition: all .2s ease-in-out;
        }

        input[type="checkbox"].switch_1:checked:after{
            left: calc(100% - 1.5em);
        }
        .select2-selection {
            height:100px;
        }
        .select2-search__field,.select2-selection--multiple
        {
            width:311px !important;
        }
        #example {
            white-space: nowrap !important;
        }
        #example td, #example th {
            padding: 10px;
            min-width: 100px;
            background: white;
            box-sizing: border-box;
            text-align: left;
        }
        .table-container {
            position: relative;
            max-height:  300px;
            width: 500px;
            overflow: scroll;
        }

        #example thead th {
            position: -webkit-sticky;
            position: sticky;
            top: 0;
        }

        #example thead th:first-child {
            left: 0;
            z-index: 3;
        }
        #example thead th:nth-child(2) {
            left: 100px;
            z-index: 3;
        }
        #example tfoot {
            position: -webkit-sticky;
            bottom: 0;
            z-index: 2;
        }

        #example tfoot td {
            position: sticky;
            bottom: 0;
            z-index: 2;
        }

        #example tfoot td:first-child {
            z-index: 3;
        }

        #example tbody {
            overflow: scroll;
            height: 200px;
        }
        #example tr > :first-child {
            position: -webkit-sticky;
            position: sticky;
            left: 0;
            background-color: #343a40;
            color: white;
        }
        #example tr > :nth-child(2) {
            position: -webkit-sticky;
            position: sticky;
            left: 100px;
            background-color: #343a40;
            color: white;
        }
    </style>
</head>
<?php if(!$session->logged_in)
{
	?>
	<script type="text/javascript">
	window.location = '<?php echo SECURE_PATH; ?>';
	</script>
	<?php
}
else
{
	?>
	<!-- Breadcrumbs-->
	<section class="breadcrumbs-area2 my-3">
		<div class="container-fluid">
			<div class="d-flex justify-content-between align-items-center">
				<div class="title">
					
				</div>
			</div>
        </div>
	</section>
    <div class="content mb-4" id="loadButton">
        <script>
            setState('loadButton','<?php echo SECURE_PATH; ?>employeeMaster/process.php','loadButton=1')
        </script>
    </div>
    <div class="content" id="addForm" style="display: none;">
        <script>
            setState('addForm','<?php echo SECURE_PATH; ?>employeeMaster/process.php','addForm=1')
        </script>
    </div>
    <div class="content" id="tableDisplay">
        <script>
            setState('tableDisplay','<?php echo SECURE_PATH;?>employeeMaster/process.php','tableDisplay=1');
        </script>
    </div>
    <?php
}
?>
</div>

