<?php
error_reporting(0);
ini_set('display_errors','On');
include('../include/session.php');
if(!$session->logged_in){
    ?>
    <script type="text/javascript">
        setStateGet('main','<?php echo SECURE_PATH;?>login_process.php','loginForm=1');
    </script>
    <?php
} ?>
<?php if(isset($_POST['loadButton'])){
    ?>
    <button class="btn btn-primary" id="create_employee"><i class="fa fa-plus-circle text-white"></i> Create Employee</button>
    <script>
        // $('#addForm').css('display', 'none');
        $('#create_employee').on('click',function(){
            $('#addForm').slideToggle();
        })
    </script>
<?php } ?>
<?php if(isset($_POST['addForm'])){ ?>
    <?php if($_POST['addForm'] == 2 && isset($_POST['editform'])){ ?>
        <script>
            $('#addForm').slideDown();
        </script>
        <?php $data_sel = $session->query("SELECT * FROM employee WHERE id = :id");
        $data_sel->execute(array('id'=>$_POST['editform']));
        $data = $data_sel->fetch(PDO::FETCH_ASSOC);
        $_POST = array_merge($data,$_POST);
    }
    ?>
    <section class="content-area">
        <div class="row">
            <div class="col-xl-12 col-lg-12">
                <div class="card border-0 shadow mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h5 class="m-0 font-weight-bold text-primary">Create New Employee</h5>
                        <span class="float-right">
                                <a role="button" onclick="setState('addForm','<?php echo SECURE_PATH ?>employeeMaster/process.php','addForm=1 ')"><i class="fa fa-refresh text-primary text-lg-right"></i> Refresh</a>
                            </span>
                    </div>
                    <?php if($session->userlevel == 9)
                    { ?>
                       <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Check If This Employee is Head Of a Department</h6>
                        <span class="float-right">
                            <input type="checkbox" class="switch_1 text-center mt-2" <?php if(isset($_POST['admin'])){if($_POST['admin'] == 1){echo "checked";}}?> />
                        </span>
                    </div>
                    <?php }?>
                    <script>
                        $(document).ready(function(){
                            $('input[type="checkbox"]').click(function(){
                                if($(this).prop("checked") == true){
                                    setState('addForm','<?php echo SECURE_PATH ?>employeeMaster/process.php','addForm=1&admin=1&employee_code='+$('#employee_code').val()+'&employee_name='+$('#employee_name').val()+'&employment_type='+$('#employment_type').val()+'&department='+$('#department').val()+'&designation='+$('#designation').val()+'&location='+$('#location').val()+'&mobile='+$('#mobile').val()+'&email='+$('#email').val()+'&dob='+$('#dob').val()+'&doj='+$('#doj').val()+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform']; }?>')
                                    $('#designation-div').hide(500);

                                }
                                else if($(this).prop("checked") == false){
                                    setState('addForm','<?php echo SECURE_PATH ?>employeeMaster/process.php','addForm=1&admin=0&employee_code='+$('#employee_code').val()+'&employee_name='+$('#employee_name').val()+'&employment_type='+$('#employment_type').val()+'&department='+$('#department').val()+'&designation='+$('#designation').val()+'&location='+$('#location').val()+'&mobile='+$('#mobile').val()+'&email='+$('#email').val()+'&dob='+$('#dob').val()+'&doj='+$('#doj').val()+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform']; }?>')
                                    $('#designation-div').show(500);
                                }
                            });
                        });
                    </script>
                    <div class="card-body">
                        <form id="taskForm">
                            <div class="form-group ">
                                <div class="form-group row">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6 col-md-12">
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Employee Code<span style="color:red;">*</span></label>
                                                    <div class="col-sm-8">
                                                        <input id="employee_code" class="form-control text-uppercase" placeholder="Employee Code" value="<?php if(isset($_POST['employee_code'])){echo $_POST['employee_code'];}?>" />
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['employee_code'])){echo $_SESSION['error']['employee_code'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Employment Type</label>
                                                    <div class="col-sm-8">
                                                        <select id="employment_type" class="form-control">
                                                            <option value="">Select Employment Type</option>
                                                            <option value="contract" <?php if(isset($_POST['employment_type'])){if($_POST['employment_type'] == 'contract'){echo "selected";}}?> >Contract</option>
                                                            <option value="outsourcing" <?php if(isset($_POST['employment_type'])){if($_POST['employment_type'] == 'outsourcing'){echo "selected";}}?>>Outsourcing</option>
                                                            <option value="regular" <?php if(isset($_POST['employment_type'])){if($_POST['employment_type'] == 'regular'){echo "selected";}}?>>Regular</option>
                                                        </select>
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['employment_type'])){echo $_SESSION['error']['employment_type'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row" id="designation-div" style="<?php if(isset($_POST['admin'])) { if($_POST['admin'] == 1){echo "display:none";}} ?> " >
                                                    <label class="col-sm-4 col-form-label">Designation<span style="color:red;">*</span></label>
                                                    <div class="col-sm-8">
                                                        <select class="form-control text-capitalize" id="designation">
                                                            <option value="">Select</option>
                                                            <?php
                                                            if(isset($_POST['department']))
                                                            {
                                                                if(strlen($_POST['department']) == '')
                                                                { ?>
                                                                    <option value="0">Select Designation</option>
                                                                <?php }
                                                                $query = $session->query("select * from designation where department =:department");
                                                                $query->execute(array('department'=>$_POST['department']));
                                                                while($row = $query->fetch(PDO::FETCH_ASSOC))
                                                                { ?>
                                                                    <option value="<?php echo $row['id']?>"
                                                                        <?php
                                                                        if(isset($_POST['designation']))
                                                                        {
                                                                            if($_POST['designation'] == $row['id'])
                                                                            {
                                                                                echo "selected";
                                                                            }
                                                                        } ?>
                                                                    ><?php echo $row['designation']?></option>
                                                                <?php }
                                                            }
                                                            ?>
                                                        </select>
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['designation'])){echo $_SESSION['error']['designation'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Mobile Number<span style="color:red;">*</span></label>
                                                    <div class="col-sm-8">
                                                        <input id="mobile" class="form-control" autocomplete="off" placeholder="Mobile Number" maxlength="10" value="<?php if(isset($_POST['mobile'])){echo $_POST['mobile'];}?>" onkeypress="return isNumber(event)" />
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['mobile'])){echo $_SESSION['error']['mobile'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Date Of Birth<span class="text-danger">*</span></label>
                                                    <div class="col-sm-8">
                                                        <input class="form-control datepicker1" id="dob" value="<?php if(isset($_POST['dob'])){echo $_POST['dob'] ;}?>" maxlength="10" autocomplete="off" tabindex="1" placeholder="Date Of Birth">
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['dob'])){ echo $_SESSION['error']['dob'];}?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-md-12">
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Employee Name<span style="color:red;">*</span></label>
                                                    <div class="col-sm-8">
                                                        <input id="employee_name" class="form-control text-capitalize" value="<?php if(isset($_POST['employee_name'])){echo $_POST['employee_name'];}?>" placeholder="Employee Name" />
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['employee_name'])){echo $_SESSION['error']['employee_name'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Department<span style="color:red;">*</span></label>
                                                    <div class="col-sm-8">
                                                        <?php if($session->userlevel == 9)
                                                            { ?>
                                                        <select class="form-control" id="department" <?php if(isset($_POST['admin'])){ if($_POST['admin'] == 0){ ?>onchange="setState('addForm','<?php echo SECURE_PATH ?>employeeMaster/process.php','addForm=1&admin=<?php if(isset($_POST['admin'])){if($_POST['admin'] == ''){echo 0;}else {echo $_POST['admin']; } }else {echo 0;}?>+&employee_code='+$('#employee_code').val()+'&employee_name='+$('#employee_name').val()+'&employment_type='+$('#employment_type').val()+'&department='+$(this).val()+'&designation='+$('#designation').val()+'&location='+$('#location').val()+'&mobile='+$('#mobile').val()+'&email='+$('#email').val()+'&dob='+$('#dob').val()+'&doj='+$('#doj').val()+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform']; }?>')" <?php }}else { ?> onchange="setState('addForm','<?php echo SECURE_PATH ?>employeeMaster/process.php','addForm=1&admin=<?php if(isset($_POST['admin'])){if($_POST['admin'] == ''){echo 0;}else {echo $_POST['admin']; } }else {echo 0;}?>+&employee_code='+$('#employee_code').val()+'&employee_name='+$('#employee_name').val()+'&employment_type='+$('#employment_type').val()+'&department='+$(this).val()+'&designation='+$('#designation').val()+'&location='+$('#location').val()+'&mobile='+$('#mobile').val()+'&email='+$('#email').val()+'&dob='+$('#dob').val()+'&doj='+$('#doj').val()+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform']; }?>')"<?php } ?> >
                                                            <?php }elseif ($session->userlevel == 4)
                                                            { ?>
                                                            <select class="form-control" id="department"  onchange="setState('addForm','<?php echo SECURE_PATH ?>employeeMaster/process.php','addForm=1&admin=0&employee_code='+$('#employee_code').val()+'&employee_name='+$('#employee_name').val()+'&employment_type='+$('#employment_type').val()+'&department='+$(this).val()+'&designation='+$('#designation').val()+'&location='+$('#location').val()+'&mobile='+$('#mobile').val()+'&email='+$('#email').val()+'&dob='+$('#dob').val()+'&doj='+$('#doj').val()+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform']; }?>')"<?php } ?> >
                                                            <option value="">Select Department</option>
                                                            <?php
                                                            $query = $session->query("select * from department");
                                                            $query->execute();
                                                            while($row = $query->fetch(PDO::FETCH_ASSOC))
                                                            { ?>
                                                                <option value="<?php echo $row['id']?>"
                                                                <?php
                                                                    if(isset($_POST['department']))
                                                                    {
                                                                        if($_POST['department'] == $row['id'] )
                                                                        {
                                                                            echo "selected";
                                                                        }
                                                                    }
                                                                ?>
                                                                ><?php echo $row['department'] ?></option>
                                                            <?php }
                                                            ?>
                                                        </select>
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['department'])){echo $_SESSION['error']['department'];
                                                            }?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Work Location<span class="text-danger">*</span></label>
                                                    <div class="col-sm-8">
                                                        <select class="form-control" id="location">
                                                            <option value="">Select Work Location</option>
                                                            <?php
                                                            $query = $session->query("select * from location");
                                                            $query->execute();
                                                            while ($row = $query->fetch(PDO::FETCH_ASSOC))
                                                            { ?>
                                                                <option value="<?php echo $row['id'] ?>"
                                                                    <?php
                                                                        if(isset($_POST['location']))
                                                                        {
                                                                            if($_POST['location'] == $row['id'])
                                                                            {
                                                                                echo "selected";
                                                                            }
                                                                        }
                                                                    ?> ><?php echo $row['location'] ?></option>
                                                            <?php }
                                                            ?>
                                                        </select>
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['location'])){ echo $_SESSION['error']['location'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Email<span class="text-danger">*</span></label>
                                                    <div class="col-sm-8">
                                                        <input class="form-control" id="email" value="<?php if(isset($_POST['email'])){echo $_POST['email'] ;}?>" autocomplete="off" tabindex="1" placeholder="Enter Email Id">
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['email'])){ echo $_SESSION['error']['email'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Date Of Joining<span class="text-danger">*</span></label>
                                                    <div class="col-sm-8">
                                                        <input class="form-control datepicker1" id="doj" value="<?php if(isset($_POST['doj'])){echo $_POST['doj'] ;}?>" maxlength="10" autocomplete="off" tabindex="1" placeholder="Date Of Joining">
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['doj'])){ echo $_SESSION['error']['doj'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <?php
                                                    if(isset($_POST['editform']))
                                                    {
                                                        if($session->userlevel == 9)
                                                        { ?>
                                                        <a class="ml-5 mt-3 radius-20 btn btn-primary text-white px-5" style="cursor: pointer;" onclick="setState('result','<?php echo SECURE_PATH ?>employeeMaster/process.php','validateForm=1+<?php if(isset($_POST['admin'])){if($_POST['admin'] == ''){echo '&admin=0'; }else { echo '&admin='.$_POST['admin'] ;} }?>+&employee_code='+$('#employee_code').val()+'&employee_name='+$('#employee_name').val()+'&employment_type='+$('#employment_type').val()+'&department='+$('#department').val()+'&designation='+$('#designation').val()+'&location='+$('#location').val()+'&mobile='+$('#mobile').val()+'&email='+$('#email').val()+'&dob='+$('#dob').val()+'&doj='+$('#doj').val()+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform']; }?>' )">Update</a>
                                                    <?php }
                                                            elseif ($session->userlevel == 4)
                                                            { ?>
                                                                <a class="ml-5 mt-3 radius-20 btn btn-primary text-white px-5" style="cursor: pointer;" onclick="setState('result','<?php echo SECURE_PATH ?>employeeMaster/process.php','validateForm=1&admin=0&employee_code='+$('#employee_code').val()+'&employee_name='+$('#employee_name').val()+'&employment_type='+$('#employment_type').val()+'&department='+$('#department').val()+'&designation='+$('#designation').val()+'&location='+$('#location').val()+'&mobile='+$('#mobile').val()+'&email='+$('#email').val()+'&dob='+$('#dob').val()+'&doj='+$('#doj').val()+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform']; }?>' )">Update</a>
                                                            <?php }
                                                        }
                                                    else {
                                                        if($session->userlevel == 9)
                                                        { ?>
                                                            <a class="ml-5 mt-3 radius-20 btn btn-success text-white px-5" style="cursor: pointer;" onclick="setState('result','<?php echo SECURE_PATH ?>employeeMaster/process.php','validateForm=1+<?php if(isset($_POST['admin'])){if($_POST['admin'] == ''){echo '&admin=0';}else {echo '&admin='.$_POST['admin']; } }?>+&employee_code='+$('#employee_code').val()+'&employee_name='+$('#employee_name').val()+'&employment_type='+$('#employment_type').val()+'&department='+$('#department').val()+'&designation='+$('#designation').val()+'&location='+$('#location').val()+'&mobile='+$('#mobile').val()+'&email='+$('#email').val()+'&dob='+$('#dob').val()+'&doj='+$('#doj').val() )">Create</a>
                                                        <?php }
                                                        elseif($session->userlevel == 4)
                                                            { ?>
                                                                <a class="ml-5 mt-3 radius-20 btn btn-success text-white px-5" style="cursor: pointer;" onclick="setState('result','<?php echo SECURE_PATH ?>employeeMaster/process.php','validateForm=1+&admin=0&employee_code='+$('#employee_code').val()+'&employee_name='+$('#employee_name').val()+'&employment_type='+$('#employment_type').val()+'&department='+$('#department').val()+'&designation='+$('#designation').val()+'&location='+$('#location').val()+'&mobile='+$('#mobile').val()+'&email='+$('#email').val()+'&dob='+$('#dob').val()+'&doj='+$('#doj').val() )">Create</a>
                                                            <?php }
                                                        }
                                                    ?>
                                                    <a class="ml-5 mt-3 radius-20 btn btn-danger text-white px-5" style="cursor: pointer;" onclick="setState('addForm','<?php echo SECURE_PATH?>employeeMaster/process.php','addForm=1')">Reset</a>
                                                </div>
                                                <div id="result" class="row mt-5 ml-5">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script type="text/javascript">
        $(document).ready(function() {
            $(function () {
                $('.datepicker1,.datepicker2,.datepicker3').datetimepicker({
                    format: 'DD-MM-YYYY'
                });
            })
        });
    </script>
    <script>
        function isNumber(evt) {
            var iKeyCode = (evt.which) ? evt.which : evt.keyCode;
            if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
                return false;

            return true;
        }
    </script>
    <?php
}

if(isset($_POST['tableDisplay']))
{ ?>
    <script type="text/javascript">
        var tableToExcel = (function () {
            var uri = 'data:application/vnd.ms-excel;base64,'
                ,
                template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
                , base64 = function (s) {
                    return window.btoa(unescape(encodeURIComponent(s)))
                }
                , format = function (s, c) {
                    return s.replace(/{(\w+)}/g, function (m, p) {
                        return c[p];
                    })
                };
            return function (table, name) {
                if (!table.nodeType) table = document.getElementById(table)
                var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
                window.location.href = uri + base64(format(template, ctx))
            }
        })()
    </script>
    <?php
    $i=1;;
    $query = $session->query("select * from employee ");
    $query->execute();
    ?>
    <section class="content-area">
        <div class="row">
            <div class="col-xl-12 col-lg-12">
                <div class="card border-0 shadow mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">List Of Employees</h6>
                        <button class="btn btn-success" onclick="tableToExcel('example', 'List of Circles')"><i
                                    class="fa fa-file-excel-o"></i> Download</button>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php if($query->rowCount() >0){ ?>
                                <table class="table table-hover table-bordered table-responsive" id="example">
                                    <thead>
                                    <tr>
                                        <th>SNO</th>
                                        <th>Employee Code</th>
                                        <th>Employee Name</th>
                                        <th>Employement Type</th>
                                        <th>Department</th>
                                        <th>Designation</th>
                                        <th>Location</th>
                                        <th>Mobile</th>
                                        <th>Email</th>
                                        <th>Date Of Birth</th>
                                        <th>Date of Joining</th>
                                        <th>#</th>
                                    </tr>
                                    </thead>
                                    <?php while($row = $query->fetch(PDO::FETCH_ASSOC))
                                    { ?>
                                        <tbody>
                                        <tr>
                                            <td class="text-capitalize"><?php echo $i++; ?></td>
                                            <td class="text-capitalize"><?php echo $row['employee_code'] ?></td>
                                            <td class="text-capitalize"><?php echo $row['employee_name'] ?></td>
                                            <td class="text-capitalize"><?php echo $row['employment_type'] ?></td>
                                            <td class="text-capitalize"><?php echo $database->get_name('department','id',$row['department'],'department') ?></td>
                                            <td class="text-capitalize"><?php echo $row['admin'] == 1 ? "<b>Admin</b>" : $database->get_name('designation','id',$row['designation'],'designation') ?></td>
                                            <td class="text-capitalize"><?php echo $database->get_name('location','id',$row['location'],'location') ?></td>
                                            <td><?php echo $row['mobile'] ?></td>
                                            <td><?php echo $row['email'] ?></td>
                                            <td><?php echo $row['dob'] ?></td>
                                            <td><?php echo $row['doj'] ?></td>
                                            <td><a type="button" id="edit" class="btn btn-warning" onclick="setState('addForm','<?php echo SECURE_PATH?>employeeMaster/process.php','addForm=2&editform=<?php echo $row['id'] ?>')" ><i class="fa fa-edit"></i></a></td>
                                        </tr>
                                        </tbody>
                                    <?php } ?>
                                </table>

                            <?php }
                            else {
                                echo "Currently There are no Employees. Click on <b>&nbsp;&nbsp;Create Employee&nbsp;&nbsp;</b> To Create an Employee";
                            }?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php }
if(isset($_POST['validateForm']))
{
    $_SESSION['error'] = array();
    $field = 'employee_code';
    if(!$_POST['employee_code'] || strlen(trim($_POST['employee_code'])) == 0)
    {
        $_SESSION['error'][$field] = "* Please Enter Employee Code";
    }

    $field = 'employee_name';
    if(!$_POST['employee_name'] || strlen(trim($_POST['employee_name'])) == 0)
    {
        $_SESSION['error'][$field] = "* Please Enter Employee Name";
    }

    $field = 'employment_type';
    if(!$_POST['employment_type'] || strlen(trim($_POST['employment_type'])) == 0)
    {
        $_SESSION['error'][$field] = "* Please Select Employment Type";
    }

    $field = 'department';
    if(!$_POST['department'] || strlen(trim($_POST['department'])) == 0 )
    {
        $_SESSION['error'][$field] = "* Please Select Department";
    }

    if($_POST['admin'] == 0)
    {
        $field = 'designation';
        if(!$_POST['designation'] || strlen(trim($_POST['designation'])) == 0 )
        {
            $_SESSION['error'][$field] = "* Please Select Designation";
        }
    }

    $field = 'location';
    if(!$_POST['location'] || strlen(trim($_POST['location'])) == 0 )
    {
        $_SESSION['error'][$field] = "* Please Enter Location";
    }

    $field = 'mobile';
    if(!$_POST['mobile'] || strlen(trim($_POST['mobile'])) == 0 )
    {
        $_SESSION['error'][$field] = "* Please Enter Mobile Number";
    }

    $field = 'email';
    if(!$_POST['email'] || strlen(trim($_POST['email'])) == 0 )
    {
        $_SESSION['error'][$field] = "* Please Enter Email-Id";
    }

    $field = "dob";
    if(!$_POST['dob'] || strlen(trim($_POST['dob'])) == 0 )
    {
        $_SESSION['error'][$field] = "* Please Select Date Of Birth";
    }

    $field = "doj";
    if(!$_POST['doj'] || strlen(trim($_POST['doj'])) == 0 )
    {
        $_SESSION['error'][$field] = "* Please Select Date Of Joining";
    }

    if(count($_SESSION['error']) > 0)
    {
        ?>
        <script type="text/javascript">
            setState('addForm','<?php echo SECURE_PATH ?>employeeMaster/process.php','addForm=1&admin=<?php if(isset($_POST['admin'])){echo $_POST['admin'] ;}?>&employee_code=<?php echo $_POST['employee_code'] ?>'+'&employee_name=<?php echo $_POST['employee_name']?>'+'&employment_type=<?php echo $_POST['employment_type']?>'+'&department=<?php echo $_POST['department'] ?>'+'&designation=<?php echo $_POST['designation'] ?>'+'&location=<?php echo $_POST['location']?>'+'&mobile=<?php echo $_POST['mobile'] ?>'+'&email=<?php echo $_POST['email']?>'+'&dob=<?php echo $_POST['dob']?>'+'&doj=<?php echo $_POST['doj']?>'+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform']; }?>' )
        </script>
        <?php

    }
    else
    {
        unset($_SESSION['error']);
        if(isset($_POST['editform']))
        {
            $up = $session->query("UPDATE employee SET admin='".$_POST['admin']."',employee_code='" . $_POST['employee_code'] . "',employee_name='" . $_POST['employee_name'] . "',employment_type='" . $_POST['employment_type'] . "',department='" . $_POST['department'] . "',designation='" . $_POST['designation'] . "',location='" .$_POST['location'] . "',mobile='".$_POST['mobile']."',email='".$_POST['email']."',dob='" . $_POST['dob'] . "',doj='" . $_POST['doj'] . "',username='" . $_POST['employee_name'] . "',timestamp='" . time() . "' WHERE id=:id");
            $up->execute(array('id'=>$_POST['editform']));
            if($up)
            {
                switch ($_POST['admin'])
                {
                    case 1 : $updateUsers = $database->query("update users set username='".$_POST['employee_name']."',password='".$_POST['mobile']."',userlevel = 4,email='".$_POST['email']."',mobile='".$_POST['mobile']."',name='".$_POST['employee_name']."' where username='".$_POST['employee_name']."' ");
                        break;
                    case 0 : $updateUsers = $database->query("update users set username='".$_POST['employee_name']."',password='".md5($_POST['mobile'])."',userlevel = 3,email='".$_POST['email']."',mobile='".$_POST['mobile']."',name='".$_POST['employee_name']."' where username='".$_POST['employee_name']."' ");
                        break;
                }
                if($up && $updateUsers)
                {
                    ?>
                    <span class="alert alert-warning">Employee Details Updated</span>
                    <script>
                        setTimeout(function() {
                            setState('addForm', '<?php echo SECURE_PATH; ?>employeeMaster/process.php','addForm=1');
                            setState('tableDisplay', '<?php echo SECURE_PATH; ?>employeeMaster/process.php','tableDisplay=1');
                        },3000)
                    </script>
                    <?php
                }
            }
            else
            {
                ?>
                <div class="alert alert-danger"><?php echo mysqli_error($database->connection); ?></div>
                <script>
                    setTimeout(function() {
                        setState('addForm', '<?php echo SECURE_PATH; ?>employeeMaster/process.php','addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>employeeMaster/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
        }
        else
        {
            $check = $session->query("select id from employee where employee_code = :employee_code");
            $check->execute(array('employee_code'=>$_POST['employee_code']));
            if($check->rowCount() > 0)
            {
                echo "<span class='alert alert-info'>A Employee with Same Employee Code Already Exists</span>"; ?>
                <script>
                    setTimeout(function(){
                        setState('addForm','<?php echo SECURE_PATH; ?>/employeeMaster/process.php','addForm=1');
                        setState('tableDisplay','<?php echo SECURE_PATH; ?>/employeeMaster/process.php','tableDisplay=1');
                    },3000)
                </script>
            <?php }else {
                $insert = $session->query("INSERT INTO employee values (:nu,:admin,:employee_code,employee_name,:employment_type,:department,:designation,:location,:mobile,:email,:dob,:doj,:empl_name,:ti )  ");
                $insert->execute(array('nu'=>NULL,'admin'=>$_POST['admin'],'employee_code'=>$_POST['employee_code'],'employee_name'=>$_POST['employee_name'],'employment_type'=>$_POST['employment_type'],'department'=>$_POST['department'],'designation'=>$_POST['designation'],'location'=>$_POST['location'],'mobile'=>$_POST['mobile'],'email'=>$_POST['email'],'dob'=>$_POST['dob'],'doj'=>$_POST['doj'],'empl_name'=>$_POST['employee_name'],'ti'=>time()));
                if($insert)
                {
                    switch ($_POST['admin'])
                    {
                        case 1 : $insertUsers = $session->query("insert into users values (:employee_name,:mobile,:nu,:four,:email,:mobile,:zero,:ti,:one,:empl_name,:val,:tim) ");
                        $insertUsers->execute(array('employee_name'=>$_POST['employee_name'],'mobile'=>md5($_POST['mobile']),'nu'=>NULL,'four'=>4,'email'=>$_POST['email'],'mobile'=>$_POST['mobile'],'zero'=>0,'ti'=>time(),'one'=>1,'empl_name'=>$_POST['employee_name'],'val'=>'89152a0b5a0a202774589b5b0c54842c','tim'=>time()));
                        break;
                        case 0 : $insertUsers = $session->query("insert into users values (:employee_name,:mobile,:nu,:three,:email,:mobile,:zero,:ti,:one,:empl_name,:val,:tim) ");
                            $insertUsers->execute(array('employee_name'=>$_POST['employee_name'],'mobile'=>md5($_POST['mobile']),'nu'=>NULL,'three'=>3,'email'=>$_POST['email'],'mobile'=>$_POST['mobile'],'zero'=>0,'ti'=>time(),'one'=>1,'empl_name'=>$_POST['employee_name'],'val'=>'89152a0b5a0a202774589b5b0c54842c','tim'=>time()));
                        break;
                    }
                    if($insert && $insertUsers)
                    {
                        ?>
                        <span class="alert alert-success">Employee Created Succesfully</span>
                        <script>
                            setTimeout(function(){
                                setState('addForm','<?php echo SECURE_PATH; ?>/employeeMaster/process.php','addForm=1');
                                setState('tableDisplay','<?php echo SECURE_PATH; ?>/employeeMaster/process.php','tableDisplay=1');
                            },3000)
                        </script>
                        <?php
                    }
                }
                else
                {
                    ?>
                    <div class="alert alert-danger"><?php echo mysqli_error($database->connection); ?></div>
                    <script>
                        setTimeout(function() {
                            setState('addForm', '<?php echo SECURE_PATH; ?>employeeMaster/process.php','addForm=1');
                            setState('tableDisplay', '<?php echo SECURE_PATH; ?>employeeMaster/process.php','tableDisplay=1');
                        },3000)
                    </script>
                    <?php
                }
            }
        }
        ?>
        <?php
    }
    }
?>
