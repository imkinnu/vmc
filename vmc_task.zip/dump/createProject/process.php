<?php
error_reporting(0);
ini_set('display_errors','On');
include('../include/session.php');
if(!$session->logged_in){
    ?>
    <script type="text/javascript">
        setStateGet('main','<?php echo SECURE_PATH;?>login_process.php','loginForm=1');
    </script>
    <?php
}
if(isset($_POST['loadButton'])){
?>
    <button class="btn btn-primary" id="create_project"><i class="fa fa-plus-circle text-white"></i> Create Project</button>
    <script>
        $('#addForm').hide();
        $('#create_project').on('click',function(){
            $('#addForm').slideToggle();
        })
    </script>
<?php } ?>
<?php if(isset($_POST['addForm'])){
        if($_POST['addForm'] == 2 && isset($_POST['editform'])){
            $data_sel = $database->query("SELECT * FROM project WHERE id = '".$_POST['editform']."'");
            $data = $data_sel->fetch_assoc();
            $flag=1;
            $_POST = array_merge($data,$_POST);
            }
    ?>
    <section class="content-area">
            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="card border-0 shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Create New Project</h6>
                            <span class="float-right">
                                <a role="button" onclick="setState('addForm','<?php echo SECURE_PATH ?>createProject/process.php','addForm=1 ')"><i class="fa fa-refresh text-primary text-lg-right"></i> Refresh</a>
                            </span>
                        </div>
                        <div class="card-body">
                            <form id="taskForm">
                                <div class="form-group ">
                                    <div class="form-group row">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-lg-6 col-md-12">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Project Name<span style="color:red;">*</span></label>
                                                        <div class="col-sm-8">
                                                            <input id="project_name" class="form-control" placeholder="Project Name" value="<?php if(isset($_POST['project_name'])){echo $_POST['project_name'];}?>" />
                                                            <span class="text-danger"><?php if(isset($_SESSION['error']['project_name'])){echo $_SESSION['error']['project_name'];}?></span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Other Details</label>
                                                        <div class="col-sm-8">
                                                            <textarea id="other_details" class="form-control" rows="4" placeholder="Enter Any Other Details Here.."><?php if(isset($_POST['other_details'])){echo $_POST['other_details'];}?></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row mt-4">
                                                        <label class="col-sm-4 col-form-label">Project Type<span style="color:red;">*</span></label>
                                                        <div class="col-sm-8">
                                                            <select class="form-control text-capitalize" id="project_type">
                                                                <option value="">Select</option>
                                                                <option value="new"<?php if(isset($_POST['project_type'])){if($_POST['project_type'] == 'new'){echo "selected";} }?> >New</option>
                                                                <option value="maintainance"<?php if(isset($_POST['project_type'])){if($_POST['project_type'] == 'maintainance'){echo "selected";} } ?> >Maintainance</option>
                                                            </select>
                                                            <span class="text-danger"><?php if(isset($_SESSION['error']['project_type'])){echo $_SESSION['error']['project_type'];}?></span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row mt-4">
                                                        <label class="col-sm-4 col-form-label">Stakeholders<span style="color:red;">*</span></label>
                                                        <div class="col-sm-8">
                                                            <select class="js-example-basic-multiple form-control text-capitalize" id="stakeholders" multiple="multiple">
                                                                <?php
                                                                $query = $database->query("select id,username from employee");
                                                                while($row = $query->fetch_assoc())
                                                                { ?>
                                                                    <option value="<?php echo $row['id']?>"
                                                                        <?php if(isset($_POST['stakeholder']))
                                                                        {
                                                                            $exStake = explode(',',$_POST['stakeholder']);
                                                                            for($k = 0;$k<count($exStake);$k++)
                                                                            {
                                                                                if($exStake[$k] == $row['id'])
                                                                                {
                                                                                    echo 'selected="selected"';
                                                                                }
                                                                            }
                                                                        } ?>
                                                                    ><?php echo $row['username'] ?></option>
                                                                <?php }
                                                                ?>
                                                            </select>
                                                            <span class="text-danger"><?php if(isset($_SESSION['error']['stakeholder'])){echo $_SESSION['error']['stakeholder'];}?></span>
                                                        </div>
                                                        <script>
                                                            $(document).ready(function() {
                                                                $('.js-example-basic-multiple ').select2({
                                                                    placeholder: 'Start Entering a Name..',
                                                                    dropdownAutoWidth : true,
                                                                    // selectOnClose:true
                                                                });
                                                            });
                                                        </script>
                                                    </div>
                                                    <div class="form-group row mt-4r">
                                                        <label class="col-sm-4 col-form-label">Final Value<span style="color:red;">*</span></label>
                                                        <div class="col-sm-8">
                                                            <div class="input-group mb-3">
                                                                <div class="input-group-prepend">
                                                                    <span class="input-group-text">₹</span>
                                                                </div>
                                                                <input type="text" id="final_value" class="form-control" aria-label="Amount (to the nearest rupee)" value="<?php if(isset($_POST['final_value'])){echo $_POST['final_value'];}?>">
                                                                <div class="input-group-append">
                                                                    <span class="input-group-text">.00</span>
                                                                </div>
                                                            </div>
                                                            <span class="text-center text-danger"><?php if(isset($_SESSION['error']['final_value'])){echo $_SESSION['error']['final_value'];}?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6 col-md-12">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Project Brief<span style="color:red;">*</span></label>
                                                        <div class="col-sm-8">
                                                            <textarea id="project_brief" class="form-control" rows="5" placeholder="Start Typing Project Brief.."><?php if(isset($_POST['project_brief'])){echo $_POST['project_brief'];}?></textarea>
                                                            <span class="text-danger"><?php if(isset($_SESSION['error']['project_brief'])){echo $_SESSION['error']['project_brief'];}?></span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row file_uploader mt-5">
                                                        <label class="col-sm-6 col-form-label" style="text-align:left;">Other Attachments If Any<span style="color:red;">*</span></label>
                                                        <div id="file-uploader2" style="display:inline">
                                                            <noscript>
                                                                <p>Please enable JavaScript to use file uploader.</p>
                                                                <!-- or put a simple form for upload here -->
                                                            </noscript>
                                                        </div>
                                                        <script>

                                                            function createUploader(){

                                                                var uploader = new qq.FileUploader({
                                                                    element: document.getElementById('file-uploader2'),
                                                                    action: '<?php echo SECURE_PATH;?>theme/js/upload/php2.php?upload=image&upload_type=single&filetype=file',
                                                                    debug: true,
                                                                    multiple:false
                                                                });
                                                            }

                                                            createUploader();



                                                            // in your app create uploader as soon as the DOM is ready
                                                            // don't wait for the window to load

                                                        </script>
                                                        <input type="hidden" name="image" id="image" value="<?php if(isset($_POST['image'])) { echo $_POST['image']; } ?>"/>
                                                        <?php
                                                        if(isset($_POST['file']))
                                                        {
                                                            ?>
                                                            <a href="<?php echo SECURE_PATH."files/".$_POST['image'];?>" target="_blank" >View Document</a>
                                                            <?php

                                                        }
                                                        ?>
                                                    </div>
                                                    <!--                                                    <div class="form-group row">-->
                                                    <!--                                                        <label class="col-sm-4 col-form-label">Date <span style="color:red;">*</span></label>-->
                                                    <!--                                                        <div class="col-sm-8">-->
                                                    <!--                                                            <input class="form-control datepicker1" id="date" name="date" value="--><?php //if(isset($_POST['date'])){echo $_POST['date'] ;}?><!--" maxlength="10" autocomplete="off" id="date" tabindex="1">-->
                                                    <!--                                                            <span style="color:red;">--><?php //if(isset($_SESSION['error']['date'])){ echo $_SESSION['error']['date'];}?><!--</span>-->
                                                    <!--                                                        </div>-->
                                                    <!--                                                    </div>-->
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label"><span style="color:red;">*</span>Estimated Value</label>
                                                        <div class="col-sm-8">
                                                            <div class="input-group mb-3">
                                                                <div class="input-group-prepend">
                                                                    <span class="input-group-text">₹</span>
                                                                </div>
                                                                <input type="text" id="estimated_value" class="form-control" aria-label="Amount (to the nearest rupee)" value="<?php if(isset($_POST['estimated_value'])){echo $_POST['estimated_value'];}?>">
                                                                <div class="input-group-append">
                                                                    <span class="input-group-text">.00</span>
                                                                </div>
                                                            </div>
                                                            <span class="text-danger text-center"><?php if(isset($_SESSION['error']['estimated_value'])){echo $_SESSION['error']['estimated_value'];}?></span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <?php
                                                        if(isset($_POST['editform']))
                                                        { ?>
                                                            <a class="ml-5 mt-2 radius-20 btn btn-primary text-white px-5" style="cursor: pointer;" onclick="setState('result','<?php echo SECURE_PATH ?>createProject/process.php','validateForm=1&project_name=<?php echo $_POST['project_name']?>'+'&project_brief=<?php echo $_POST['project_brief']?>'+'&other_details=<?php echo $_POST['other_details']?>'+'&project_type=<?php echo $_POST['project_type']?>'+'&attachments=<?php echo $_POST['attachments'] ?>'+'&stakeholder='+$('#stakeholders').val()+'&estimated_value=<?php echo $_POST['estimated_value']?>'+'&final_value=<?php echo $_POST['final_value']?>'+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform'];}?>' )">Update</a>
                                                        <?php }
                                                        else { ?>
                                                            <a class="ml-5 mt-2 radius-20 btn btn-success text-white px-5" style="cursor: pointer;" onclick="setState('result','<?php echo SECURE_PATH ?>createProject/process.php','validateForm=1&project_name='+$('#project_name').val()+'&project_brief='+$('#project_brief').val()+'&other_details='+$('#other_details').val()+'&project_type='+$('#project_type').val()+'&attachments='+$('#image').val()+'&stakeholder='+$('#stakeholders').val()+'&estimated_value='+$('#estimated_value').val()+'&final_value='+$('#final_value').val() )">Create</a>
                                                        <?php }
                                                        ?>
                                                        <a class="ml-2 mt-2 radius-20 btn btn-danger text-white px-5" style="cursor: pointer;" onclick="setState('addForm','<?php echo SECURE_PATH?>createProject/process.php','addForm=1')">Reset</a>
                                                    </div>
                                                    <div id="result" class="row mt-5 ml-5">

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <script type="text/javascript">
        $(document).ready(function() {
            $(function () {
                $('.datepicker1,.datepicker2,.datepicker3').datetimepicker({
                    format: 'DD-MM-YYYY'
                });
            })
        });
    </script>
    <?php
}
if(isset($_POST['tableDisplay']))
{
    $i=1;
    $uname = 'admin';
    $query = $database->query("select * from project") ?>
    <section class="content-area">
            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="card border-0 shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Projects Assigned</h6>
                            <span class="float-right">
                                <a role="button" onclick="setState('tableDisplay','<?php echo SECURE_PATH ?>createProject/process.php','tableDisplay=1 ')"><i class="fa fa-refresh text-primary text-lg-right"></i></a>
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="form-group ">
                                <div class="form-group row">
                                    <div class="card-body">
                                        <div class="row">
                                            <?php if(mysqli_num_rows($query) >0){ ?>
                                                <table class="table table-bordered ">
                                                    <thead>
                                                    <tr>
                                                        <th>SNO</th>
                                                        <th>Project Name</th>
                                                        <th>Project Brief</th>
                                                        <th>Other Details</th>
                                                        <th>Projet Type</th>
                                                        <th>Current Task</th>
                                                        <th>Currently With</th>
                                                        <th>Stakeholders</th>
                                                        <th>Estimated Value</th>
                                                        <th>Final Value</th>
                                                        <th>#</th>
                                                    </tr>
                                                    </thead>
                                                    <?php while($row = $query->fetch_assoc())
                                                    { ?>
                                                        <tbody>
                                                        <tr>
                                                            <td><?php echo $i++; ?></td>
                                                            <td><?php echo $row['project_name'] ?></td>
                                                            <td><?php echo $row['project_brief'] ?></td>
                                                            <td><?php echo empty($row['other_details'])? "--" : $row['other_details'] ?></td>
                                                            <td class="text-capitalize"><?php echo $row['project_type'] ?></td>
                                                            <td class="text-capitalize"><?php
                                                            $stakeholder = explode(',',$row['stakeholder']);
                                                            for($x = 0 ; $x < count($stakeholder) ; $x++){
                                                                echo $database->get_name('employee','id',$stakeholder[$x],'username').",";
                                                            }
                                                            ?></td>
                                                            <td><?php echo $row['estimated_value'] ?></td>
                                                            <td><?php echo $row['final_value'] ?></td>
                                                            <td><input type="button" id="edit" class="btn btn-warning" value="Edit" onclick="setState('addForm','<?php echo SECURE_PATH?>createProject/process.php','addForm=2&editform=<?php echo $row['id'] ?>')" </td>
                                                        </tr>
                                                        </tbody>
                                                    <?php } ?>
                                                </table>
                                            <?php }
                                            else {
                                                echo "No results to display";
                                            }?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
<?php }
if(isset($_POST['validateForm']))
{
    ?>

    <?php

    $_SESSION['error'] = array();
    $field = 'project_name';
    if(!$_POST['project_name'] || strlen(trim($_POST['project_name'])) == 0)
    {
        $_SESSION['error'][$field] = "* Please Enter Project Name";
    }

    $field = 'project_brief';
    if(!$_POST['project_brief'] || strlen(trim($_POST['project_brief'])) == 0)
    {
        $_SESSION['error'][$field] = "* Please Enter Project Brief";
    }

//    $field = 'other_details';
//    if(!$_POST['other_details'] || strlen(trim($_POST['other_details'])) == 0)
//    {
//        $_SESSION['error'][$field] = "* Please Select Employee";
//    }

    $field = 'project_type';
    if(!$_POST['project_type'] || strlen(trim($_POST['project_type'])) == 0)
    {
        $_SESSION['error'][$field] = "* Please Select Project Type";
    }

    $field = 'stakeholder';
    if(!$_POST['stakeholder'] || strlen(trim($_POST['stakeholder'])) == 0 || $_POST['stakeholder'] == 'null')
    {
        $_SESSION['error'][$field] = "* Please Select Stakeholders";
    }

    $field = 'estimated_value';
    if ($_POST['estimated_value'] == "")
    {
        $_SESSION['error'][$field]  = "* Please Enter Estimated Value";
    }

    $field = 'final_value';
    if ($_POST['final_value'] == "")
    {
        $_SESSION['error'][$field]  = "* Please Enter Final Value";
    }

    if(count($_SESSION['error']) > 0)
    {
        ?>
        <script type="text/javascript">
            setState('addForm','<?php echo SECURE_PATH ?>createProject/process.php','addForm=1&project_name='+$('#project_name').val()+'&project_brief='+$('#project_brief').val()+'&other_details='+$('#other_details').val()+'&project_type='+$('#project_type').val()+'&attachments='+$('#image').val()+'&stakeholder='+$('#stakeholders').val()+'&estimated_value='+$('#estimated_value').val()+'&final_value='+$('#final_value').val() )
        </script>
        <?php

    }
    else
    {
        unset($_SESSION['error']);
        if(isset($_POST['editform']))
        {
                $up = $database->query("UPDATE project SET project_name='" . $_POST['project_name'] . "',project_brief='" . $_POST['project_brief'] . "',other_details='" . $_POST['other_details'] . "',project_type='" . $_POST['project_type'] . "',attachments='" . $_POST['attachments'] . "',stakeholder='" .$_POST['stakeholder'] . "',estimated_value='" . $_POST['estimated_value'] . "',final_value='" . $_POST['final_value'] . "',username='" . $session->username . "',timestamp='" . time() . "' WHERE id='" . $_POST['editform'] . "'");
            if($up)
            {
                ?>
                <span class="alert alert-warning">Project Details Updated</span>
                <script>
                    setTimeout(function() {
                        setState('addForm', '<?php echo SECURE_PATH; ?>createProject/process.php','addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>createProject/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
            else
            {
                ?>
                <div class="alert alert-danger"><?php echo mysqli_error($database->connection); ?></div>
                <script>
                    setTimeout(function() {
                        setState('addForm', '<?php echo SECURE_PATH; ?>createProject/process.php','addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>createProject/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
        }
        else
        {

            $desg='';
            $selmax=$database->query("SELECT MAX(project_idi) FROM project");
            $rowmax=mysqli_fetch_array($selmax);

            $emaxid=$rowmax[0]+1;

            $xlen=strlen($emaxid);
            $xval=5-$xlen;
            for($x=1;$x<=$xval;$x++)
            {
                $desg .="0";
            }

            $empidD=$desg.$emaxid;
            $projectidi = "PJ".$empidD;
            $insert = $database->query("INSERT INTO project values (NULL,'".$emaxid."','".$projectidi."','".$_POST['project_name']."','".$_POST['project_brief']."','".$_POST['other_details']."','".$_POST['project_type']."','".$_POST['image']."','".$_POST['stakeholder']."','".$_POST['estimated_value']."','".$_POST['final_value']."','".$session->username."','".time()."' ) ");
            if($insert)
            {
                ?>
                <span class="alert alert-success">Project Created Succesfully</span>
                <script>
                    setTimeout(function(){
                        setState('addForm','<?php echo SECURE_PATH; ?>createProject/process.php','addForm=1');
                        setState('tableDisplay','<?php echo SECURE_PATH; ?>createProject/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
            else
            {
                ?>
                <div class="alert alert-danger"><?php echo mysqli_error($database->connection); ?></div>
                <script>
                    setTimeout(function() {
                        setState('addForm', '<?php echo SECURE_PATH; ?>createProject/process.php','addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>createProject/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
        }
        ?>
        <?php
    }
}
?>