<?php
error_reporting(0);
ini_set('display_errors','On');
include('../include/session.php');
if(!$session->logged_in){
    ?>
    <script type="text/javascript">
        setStateGet('main','<?php echo SECURE_PATH;?>login_process.php','loginForm=1');
    </script>
    <?php
}

//Metircs Forms, Tables and Functions
//Display cadre form
if(isset($_POST['addForm'])){
        if($_POST['addForm'] == 2 && isset($_POST['editform'])){
            $data_sel = $database->query("SELECT * FROM task WHERE id = '".$_POST['editform']."'");
            $data = $data_sel->fetch_assoc();
            $flag=1;
            $_POST = array_merge($data,$_POST);
            }
    ?>
    <section class="content-area">
            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="card border-0 shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Create New Task</h6>
                            <span class="float-right">
                                <a role="button" onclick="setState('addForm','<?php echo SECURE_PATH ?>createTask/process.php','addForm=1 ')"><i class="fa fa-refresh text-primary text-lg-right"></i> Refresh</a>
                            </span>
                        </div>
                        <div class="card-body">
                            <form id="taskForm">
                                <div class="form-group ">
                                    <div class="form-group row">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-lg-6 col-md-12">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Task Title<span class="text-danger">*</span></label>
                                                        <div class="col-sm-8">
                                                            <input id="task_title" class="form-control" placeholder="Task Of Title" value="<?php if(isset($_POST['title'])){echo $_POST['title'];}?>" />
                                                            <span class="text-danger"><?php if(isset($_SESSION['error']['title'])){echo $_SESSION['error']['title'];}?></span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row mt-4">
                                                        <label class="col-sm-4 col-form-label">Assigned To<span class="text-danger">*</span></label>
<!--                                                        --><?php //if(isset($_POST['assignedto']))
//                                                        {
//                                                            $split = str_split($_POST['assignedto'], 1);
//                                                            print_r($split);
//                                                            $query = $database->query("select id,stakeholder from project where id='" . $_POST['project_name'] . "' and stakeholder IN ('".$split."')");
//                                                        } ?>
                                                        <div class="col-sm-8">
                                                            <select class="js-example-basic-multiple form-control text-capitalize" id="assignedto" multiple="multiple">
                                                                <option value="">Select</option>
                                                            <?php
                                                            if(isset($_POST['project_name'])) {
                                                                    $query = $database->query("select id,stakeholder from project where id='" . $_POST['project_name'] . "'");
                                                                while ($row = $query->fetch_assoc()) {
                                                                    $stakeholder = explode(',', $row['stakeholder']);
                                                                    for ($x = 0; $x < count($stakeholder); $x++) { ?>
                                                                        <option value="<?php echo $stakeholder[$x] ?>"
                                                                        <?php
                                                                            if(isset($_POST['assignedto']))
                                                                            {
                                                                                $assigned = explode(',',$_POST['assignedto']);
                                                                                for($z=0;$z<count($assigned);$z++)
                                                                                {
                                                                                    if($assigned[$z] == $stakeholder[$x])
                                                                                    {
                                                                                        echo 'selected="selected"';
                                                                                    }
                                                                                }
                                                                            }
                                                                        ?>
                                                                        ><?php echo $database->get_name('employee', 'id', $stakeholder[$x], 'username') ?></option>
                                                                    <?php }
                                                                }
                                                            }?>
                                                            </select>
                                                            <span class="text-danger"><span class="text-danger"><?php if(isset($_SESSION['error']['assignedto'])){echo $_SESSION['error']['assignedto'];}?></span></span>
                                                        </div>
                                                        <script>
                                                            $(document).ready(function() {
                                                                $('.js-example-basic-multiple ').select2({
                                                                    placeholder: 'Start Entering a Name..',
                                                                    dropdownAutoWidth : true,
                                                                    // selectOnClose:true
                                                                });
                                                            });
                                                        </script>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Due Date<span class="text-danger">*</span></label>
                                                        <div class="col-sm-8">
                                                            <input class="form-control datepicker1" id="due_date" value="<?php if(isset($_POST['due_date'])){echo date('d-m-Y',$_POST['due_date']) ;}?>" maxlength="10" autocomplete="off" tabindex="1">
                                                            <span class="text-danger"><span class="text-danger"><?php if(isset($_SESSION['error']['due_date'])){echo $_SESSION['error']['due_date'];}?></span></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6 col-md-12">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Select Project<span class="text-danger">*</span></label>
                                                        <div class="col-sm-8">
                                                            <?php
                                                            $getProject = $database->query("select id,project_name from project");
                                                            ?>
                                                            <select class="form-control text-capitalize" id="sel_project" onchange="setState('addForm','<?php echo SECURE_PATH ?>createTask/process.php','addForm=1&title='+$('#task_title').val()+'&assignedto='+$('#assignedto').val()+'&project_name='+$('#sel_project').val()+'&assigned_date='+$('#assigned_date').val()+'&due_date='+$('#due_date').val())">
                                                             <option value="">Select</option>
                                                             <?php
                                                                while($getProjectName = $getProject->fetch_assoc())
                                                                { ?>
                                                                    <option value="<?php echo $getProjectName['id'] ?>"
                                                                    <?php
                                                                        if(isset($_POST['project_name']))
                                                                        {
                                                                            if($_POST['project_name'] == $getProjectName['id'])
                                                                            {
                                                                                echo "selected";
                                                                            }
                                                                        }
                                                                    ?>
                                                                    ><?php echo $getProjectName['project_name'] ?></option>
                                                                <?php }
                                                             ?>
                                                            </select>
                                                            <span class="text-danger"><?php if(isset($_SESSION['error']['project_name'])){echo $_SESSION['error']['project_name'];}?></span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Assigned Date<span class="text-danger">*</span></label>
                                                        <div class="col-sm-8">
                                                            <input class="form-control datepicker1" id="assigned_date" value="<?php if(isset($_POST['assigned_date'])){echo date('d-m-Y',$_POST['assigned_date']) ;}?>" maxlength="10" autocomplete="off" tabindex="1">
                                                            <span class="text-danger"><span class="text-danger"><?php if(isset($_SESSION['error']['assigned_date'])){echo $_SESSION['error']['assigned_date'];}?></span></span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <?php
                                                        if(isset($_POST['editform']))
                                                        { ?>
                                                            <a class="ml-5 mt-2 radius-20 btn btn-primary text-white px-5" style="cursor: pointer;" onclick="setState('result','<?php echo SECURE_PATH ?>createTask/process.php','validateForm=1&title=<?php echo $_POST['title'] ?>'+'&assignedto='+$('#assignedto').val()+'&project_name=<?php echo $_POST['project_name']?>'+'&assigned_date=<?php echo $_POST['assigned_date']?>'+'&due_date=<?php echo $_POST['due_date']?>'+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform'];}?>' )">Update</a>
                                                        <?php }
                                                        else { ?>
                                                            <a class="ml-5 mt-2 radius-20 btn btn-success text-white px-5" style="cursor: pointer;" onclick="setState('result','<?php echo SECURE_PATH ?>createTask/process.php','validateForm=1&title='+$('#task_title').val()+'&assignedto='+$('#assignedto').val()+'&project_name='+$('#sel_project').val()+'&assigned_date='+$('#assigned_date').val()+'&due_date='+$('#due_date').val())">Create</a>
                                                        <?php }
                                                        ?>
                                                        <a class="ml-2 mt-2 radius-20 btn btn-danger text-white px-5" style="cursor: pointer;" onclick="setState('addForm','<?php echo SECURE_PATH?>createTask/process.php','addForm=1')">Reset</a>
                                                    </div>
                                                    <div id="result" class="row mt-5 ml-5">

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <script type="text/javascript">
        $(document).ready(function() {
            $(function () {
                $('.datepicker1,.datepicker2,.datepicker3').datetimepicker({
                    format: 'DD-MM-YYYY'
                });
            })
        });
    </script>
    <?php
}
if(isset($_POST['validateForm']))
{
    ?>

    <?php

    $_SESSION['error'] = array();
    $field = 'title';
    if(!$_POST['title'] || strlen(trim($_POST['title'])) == 0)
    {
        $_SESSION['error'][$field] = "* Please Enter Task Title";
    }

    $field = 'assignedto';
    if(!$_POST['assignedto'] || strlen(trim($_POST['assignedto'])) == 0 || $_POST['assignedto'] == 'null')
    {
        $_SESSION['error'][$field] = "* Please Select Stakeholders";
    }

    $field = 'project_name';
    if(!$_POST['project_name'] || strlen(trim($_POST['project_name'])) == 0)
    {
        $_SESSION['error'][$field] = "* Please Select One Project";
    }

    $field = 'assigned_date';
    if ($_POST['assigned_date'] == "")
    {
        $_SESSION['error'][$field]  = "* Please Select Assigned Date";
    }
    $field = 'due_date';
    if ($_POST['due_date'] == "")
    {
        $_SESSION['error'][$field]  = "* Please Select Assigned Date";
    }

    if(count($_SESSION['error']) > 0)
    {
        ?>
        <script type="text/javascript">
            setState('addForm','<?php echo SECURE_PATH ?>createTask/process.php','addForm=1&title='+$('#task_title').val()+'&assignedto='+$('#assignedto').val()+'&project_name='+$('#sel_project').val()+'&assigned_date='+$('#assigned_date').val()+'&due_date='+$('#due_date').val())
        </script>
        <?php

    }
    else
    {
        unset($_SESSION['error']);
        if(isset($_POST['editform']))
        {
            $up = $database->query("UPDATE task SET title='" . $_POST['title'] . "',assignedto='" . $_POST['assignedto'] . "',project_name='" . $_POST['project_name'] . "',assigned_date='" . strtotime($_POST['assigned_date']) . "',due_date='" . strtotime($_POST['due_date']) . "' WHERE id='" . $_POST['editform'] . "'");
            if($up)
            {
                ?>
                <span class="alert alert-warning">Task Details Updated</span>
                <script>
                    setTimeout(function() {
                        setState('addForm', '<?php echo SECURE_PATH; ?>//createTask/process.php','addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>createTask/process.php','tableDisplay=1');
                   },3000)
                </script>
                <?php
            }
            else
            {
                ?>
                <div class="alert alert-danger"><?php echo mysqli_error($database->connection); ?></div>
                <script>
                    setTimeout(function() {
                        setState('addForm', '<?php echo SECURE_PATH; ?>createTask/process.php','addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>createTask/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
        }
        else
        {

            $desg='';
            $selmax=$database->query("SELECT MAX(task_idi) FROM task");
            $rowmax=mysqli_fetch_array($selmax);

            $emaxid=$rowmax[0]+1;

            $xlen=strlen($emaxid);
            $xval=5-$xlen;
            for($x=1;$x<=$xval;$x++)
            {
                $desg .="0";
            }

            $empidD=$desg.$emaxid;
            $taskidi = "TK".$empidD;
            $insert = $database->query("INSERT INTO task values (NULL,'".$emaxid."','".$taskidi."','".$_POST['title']."','".$_POST['assignedto']."','".$session->username."','".$_POST['project_name']."','".strtotime($_POST['assigned_date'])."','".strtotime($_POST['due_date'])."',1,'".$session->username."','".time()."' ) ");
            if($insert)
            {
                ?>
                <span class="alert alert-success">Task Created Succesfully</span>
                <script>
                    setTimeout(function(){
                        setState('addForm','<?php echo SECURE_PATH; ?>createTask/process.php','addForm=1');
                        setState('tableDisplay','<?php echo SECURE_PATH; ?>createTask/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
            else
            {
                ?>
                <div class="alert alert-danger"><?php echo mysqli_error($database->connection); ?></div>
                <script>
                    setTimeout(function() {
                        setState('addForm', '<?php echo SECURE_PATH; ?>createTask/process.php','addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>createTask/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
        }
        ?>
        <?php
    }
}
if(isset($_POST['tableDisplay']))
{
    $i=1;
    $uname = 'admin';
    $query = $database->query("select * from task") ?>
    <section class="content-area">
            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="card border-0 shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Tasks Created</h6>
                            <span class="float-right">
                                <a role="button" onclick="setState('tableDisplay','<?php echo SECURE_PATH ?>createTask/process.php','tableDisplay=1')"><i class="fa fa-refresh text-primary text-lg-right"></i> Refresh</a>
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="form-group ">
                                <div class="form-group row">
                                    <div class="card-body">
                                        <div class="row">
                                            <?php if(mysqli_num_rows($query) >0){ ?>
                                                <table class="table table-bordered ">
                                                    <thead>
                                                    <tr>
                                                        <th>SNO</th>
                                                        <th>Title Of Task</th>
                                                        <th>Assigned To</th>
                                                        <th>Created By</th>
                                                        <th>Project Name</th>
                                                        <th>Assigned Date</th>
                                                        <th>Due Date</th>
                                                        <th>#</th>
                                                    </tr>
                                                    </thead>
                                                    <?php while($row = $query->fetch_assoc())
                                                    { ?>
                                                        <tbody>
                                                        <tr>
                                                            <td><?php echo $i++; ?></td>
                                                            <td><?php echo $row['title'] ?></td>
                                                            <td class="text-capitalize"><?php
                                                                $assignedTo = explode(',',$row['assignedto']);
                                                                for($x = 0 ; $x < count($assignedTo) ; $x++){
                                                                    echo $database->get_name('employee','id',$assignedTo[$x],'username').",";
                                                                }
                                                                ?></td>
                                                            <td class="text-capitalize"><?php echo $row['created_by']?></td>
                                                            <td><?php echo $database->get_name('project','id',$row['project_name'],'project_name') ?></td>
                                                            <td><?php echo date('d-m-Y',$row['assigned_date']) ?></td>
                                                            <td><?php echo date('d-m-Y',$row['due_date']) ?></td>
                                                            <td><input type="button" id="edit" class="btn btn-warning" value="Edit" onclick="setState('addForm','<?php echo SECURE_PATH?>createTask/process.php','addForm=2&editform=<?php echo $row['id'] ?>')" </td>
                                                        </tr>
                                                        </tbody>
                                                    <?php } ?>
                                                </table>
                                            <?php }
                                            else {
                                                echo "No results to display";
                                            }?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php }
?>