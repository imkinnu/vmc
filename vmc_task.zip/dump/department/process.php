<?php
error_reporting(0);
ini_set('display_errors','On');
include('../include/session.php');
if(!$session->logged_in){
    ?>
    <script type="text/javascript">
        setStateGet('main','<?php echo SECURE_PATH;?>login_process.php','loginForm=1');
    </script>
    <?php
}

//Metircs Forms, Tables and Functions
//Display cadre form
if(isset($_POST['addForm'])) {
    $filtered_array = array_filter($session->getTasks($session->username));
    $taskfilter = ''; ?>
    <div class="card-body pt-3">
    <h6 class="card-header">Tasks Assigned<span class="float-right">
            <a role="button" onclick="setState('addForm','<?php echo SECURE_PATH ?>department/process.php','addForm=1 ')"><i
                        class="fa fa-refresh text-primary text-lg-right"></i></a> Refresh</span></h6>
    <?php for($j = 0;$j<count($filtered_array);$j++) {
        if ($filtered_array[$j] != '' && $filtered_array[$j] != ',') {
            $query = $database->query("select * from task where task_id ='" . $filtered_array[$j] . "'");
            ?>
            <?php if (mysqli_num_rows($query) > 0) {
                $i = 1;
                while ($row = $query->fetch_assoc()) {
                    ?>
                    <ul class="list-unstyled">
                        <a role="button" id="getDiv" onclick="$(this).closest('ul').next('div').slideToggle()">
                            <li class="card ticket-list mt-3">
                                <div class="card-body p-2">
                                    <div class="row">
                                        <div class="col-lg-3 col-md-12 col-sm-12 py-2">
                                            <p class="font-weight-bold"><?php echo $i++ . ". " . $database->get_name('project', 'id', $row['project_name'], 'project_name') ?></p>
                                            <p>
                                                <?php
                                                switch ($row['status']) {
                                                    case "1" :
                                                        echo "<label class=\"badge badge-warning\">Open</label>";
                                                        break;
                                                    case "2" :
                                                        echo "<label class=\"badge badge-primary\">In Progress</label>";
                                                        break;
                                                    case "3" :
                                                        echo "<label class=\"badge badge-info\">Returned</label>";
                                                        break;
                                                    case "4" :
                                                        echo "<label class=\"badge badge-info\">Completed</label>";
                                                        break;
                                                    case "default" :
                                                        echo "default";
                                                        break;
                                                }
                                                ?>
                                            </p>
                                        </div>
                                        <div class="col-lg-4 col-md-12 col-sm-12 py-2">
                                            <h5 class="text-primary"><?php echo $row['details'] ?></h5>
                                            <div class="d-xl-flex flex-row align-items-center justify-content-between">
                                                <p class="text-danger"><b>Due Date: <?php echo date("D", $row['due_date']) . " " . date("M", $row['due_date']) . " " . date("Y", $row['due_date']) ?></b>
                                                </p>
                                            </div>
                                            <div>
                                                <label class="badge badge-success font-weight-normal"><?php echo "Raised :".date("D", $row['assigned_date']) . " " . date("M", $row['assigned_date']) . " " . date("Y", $row['assigned_date']) ?></label>
                                                <label class="badge badge-primary font-weight-normal text-capitalize"></label>
                                            </div>
                                        </div>
                                        <div class="col-lg-2 col-md-4 col-sm-12 py-2">
                                            <p class="font-weight-bold">Task Title</p>

                                            <p class="text-capitalize"><?php echo $row['title'] ?></p>
                                        </div>

                                        <div class="col-lg-2 col-md-4 col-sm-6 py-2">
                                            <p class="font-weight-bold">Forwarded From</p>
                                            <p class="text-capitalize"><?php echo $row['created_by'] ?></p>
                                        </div>
                                        <div class="col-lg-1 col-md-4 col-sm-6 py-2 text-center">
                                            <div class="btn btn-light btn-circle">
                                                <i class="material-icons md-18 low-priority">star</i>
                                            </div>
                                        </div>
                                        <script>
                                            $('.low-priority').click(function () {
                                                $('.low-priority').removeClass('active').addClass('inactive');
                                                $(this).removeClass('inactive').addClass('active');
                                            });
                                        </script>
                                    </div>
                                </div>
                                <div class="card-footer py-1">
                                    <div class="row">
                                        <div class="col-md-10">
                                            <ul class="list-inline">
                                                <li class="list-inline-item raisedName">Raised By: <span
                                                            class="font-weight-bold text-capitalize"><?php echo $row['created_by'] ?></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </a>
                    </ul>
                    <div class="card resdiv" style="display: none;">
                        <div class="row full-view-tickets">
                            <div class="col-md-12">
                                <div class="card border-0 shadow mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">Project Details</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="card ticket-view-list my-3">
                                            <div class="card-header">
                                                <h6 class="font-weight-bold card-title mb-0 text-uppercase">Full Details</h6>
                                            </div>
                                            <div class="card-body border-bottom">
                                                <div class="row">
                                                    <div class="single-element col-lg-6 col-md-12 col-sm-12">
                                                        <div class="row">
                                                            <div class="col-lg-4 col-md-4 col-sm-12">
                                                                <p class="mb-0 font-weight-bold">Assigned To</p>
                                                            </div>
                                                            <div class="col-lg-8 col-md-8 col-sm-12">
                                                                <p class="mb-0 text-capitalize"><?php echo $session->username ?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="single-element col-lg-6 col-md-12 col-sm-12">
                                                        <div class="row">
                                                            <div class="col-lg-4 col-md-4 col-sm-12">
                                                                <p class="mb-0 font-weight-bold">Task Type</p>
                                                            </div>
                                                            <div class="col-lg-8 col-md-8 col-sm-12">
                                                                <p class="mb-0 text-capitalize"><?php echo $database->get_name('project','id',$row['project_name'],'project_type')?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="single-element col-lg-6 col-md-12 col-sm-12">
                                                        <div class="row">
                                                            <div class="col-lg-4 col-md-4 col-sm-12">
                                                                <p class="mb-0 font-weight-bold">Project</p>
                                                            </div>
                                                            <div class="col-lg-8 col-md-8 col-sm-12">
                                                                <p class="mb-0"><?php echo $database->get_name('project','id',$row['project_name'],'project_name')?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="single-element col-lg-6 col-md-12 col-sm-12">
                                                        <div class="row">
                                                            <div class="col-lg-4 col-md-4 col-sm-12">
                                                                <p class="mb-0 font-weight-bold">Reffered By</p>
                                                            </div>
                                                            <div class="col-lg-8 col-md-8 col-sm-12">
                                                                <p class="mb-0 text-capitalize"><?php echo $row['created_by'] ?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="single-element col-lg-6 col-md-12 col-sm-12">
                                                        <div class="row">
                                                            <div class="col-lg-4 col-md-4 col-sm-12">
                                                                <p class="mb-0 font-weight-bold">Due Date</p>
                                                            </div>
                                                            <div class="col-lg-8 col-md-8 col-sm-12">
                                                                <p class="mb-0 text-danger"><?php echo date('d-m-Y',$row['due_date']) ?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="single-element col-lg-6 col-md-12 col-sm-12">
                                                        <div class="row align-items-center">
                                                            <div class="col-lg-4 col-md-4 col-sm-12">
                                                                <p class="mb-0 font-weight-bold">Status</p>
                                                            </div>
                                                            <div class="col-lg-8 col-md-8 col-sm-12">
                                                                <p><?php
                                                                    switch ($row['status']) {
                                                                        case "1" :
                                                                            echo "<label class=\"badge badge-warning\">Open</label>";
                                                                            break;
                                                                        case "2" :
                                                                            echo "<label class=\"badge badge-primary\">In Progress</label>";
                                                                            break;
                                                                        case "3" :
                                                                            echo "<label class=\"badge badge-info\">Returned</label>";
                                                                            break;
                                                                        case "4" :
                                                                            echo "<label class=\"badge badge-info\">Completed</label>";
                                                                            break;
                                                                        case "default" :
                                                                            echo "default";
                                                                            break;
                                                                    }
                                                                    ?></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="single-element col-lg-12 col-md-12 col-sm-12 my-2">
                                                        <h6 class="font-weight-bold">Description</h6>
                                                        <div class="description-text">
                                                            <p><?php echo $database->get_name('project','id',$row['project_name'],'project_brief') ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="single-element col-lg-12 col-md-12 col-sm-12 my-2">
                                                        <h6 class="font-weight-bold">Other Details</h6>
                                                        <div class="description-text">
                                                            <p><?php echo $database->get_name('project','id',$row['project_name'],'other_details') ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="single-element col-lg-12 col-md-12 col-sm-12 my-2">
                                                        <h6 class="font-weight-bold">Attachments</h6>
                                                        <div class="row align-items-center">
                                                            <div class="col-lg-3 col-md-6 col-sm-12">
                                                                <div class="img-block mb-2">
                                                                    <?php if($database->get_name('project','id',$row['project_name'],'attachments') != ''){ ?>
                                                                        <img src="<?php echo SECURE_PATH ?>files/<?php echo $database->get_name('project','id',$row['project_name'],'attachments')?>" class="img-fluid rounded shadow" alt="img">
                                                                    <?php }
                                                                    else {
                                                                        echo "NA";
                                                                    }?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="conversation">
                                                <div class="conversation-heading py-3 px-4 border-bottom">
                                                    <h6 class="mb-0 font-weight-bold text-uppercase">User Conversations</h6>
                                                </div>
                                                <div class="conversation-body py-2 px-4">
                                                    <ul class="list-unstyled">
                                                        <li class="replies">
                                                            <div class="msge-box">
                                                                <div class="personInfo mb-3">
                                                                    <h6 class="userName text-primary font-weight-bold mb-0">
                                                                        Admin</h6>
                                                                    <small class="designation text-muted">
                                                                    </small>
                                                                </div>
                                                                <p>
                                                                    working on this task</p>
                                                                <p class="mt-2 time">Friday,  23 August 2019, 03:35:13 pm </p>
                                                            </div>
                                                        </li>
                                                        <li class="replies">
                                                            <div class="msge-box">
                                                                <div class="personInfo mb-3">
                                                                    <h6 class="userName text-primary font-weight-bold mb-0">
                                                                        Admin</h6>
                                                                    <small class="designation text-muted">
                                                                    </small>
                                                                </div>
                                                                <p>
                                                                    can you please do it fast</p>
                                                                <p class="mt-2 time">Friday,  23 August 2019, 03:37:02 pm </p>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="conversation-footer py-3 px-4 border-top">
                                                <form>
                                                    <div class="row">
                                                        <div class="col-md-4 col-sm-12 form-group">
                                                            <select name="status" class="custom-select custom-select-sm form-control form-control-sm" id="status">
                                                                <option value="0">Select Status</option>
                                                                <option value="1">In Progress</option>
                                                                <option value="2">Return</option>
                                                                <option value="3">Completed</option>
                                                            </select>
                                                        </div>
                                                        <script>
                                                            $('#status').on('change',function () {
                                                                var selectedValue = $('#status').val();
                                                                if(selectedValue == '2' )
                                                                {
                                                                    $('#completeDiv').slideDown();
                                                                }
                                                                else {
                                                                    $('#completeDiv').slideUp();
                                                                }
                                                            });
                                                        </script>
                                                        <div class="col-md-4 col-sm-12 form-group selectbox" id="completeDiv" style="display:none;">
                                                            <select name="assignedto" class="custom-select" id="assignedto">
                                                                <option value="">Select Assigned To</option>
                                                                <option value="rajeev">rajeev</option>
                                                                <option value="raju">raju</option>
                                                                <option value="suresh">suresh</option>
                                                                <option value="amrutha">amrutha</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-4 col-sm-12 form-group">
                                                            <div class="input-group">
                                                                <div class="input-group-append">
                                                                    <a class="btn btn-primary" onclick="setState('adminForm','http://107.178.223.50/stms/ftview/process.php','submit=1&amp;status='+$('#status').val() )"><i class="fa fa-paper-plane" aria-hidden="true"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                } ?>
            <?php }
            else { ?>
                <span class="badge badge-primary">No Results to Display</span>
            <?php }
        }
    } ?>
    </div>
<?php }
if(isset($_REQUEST['updateStatus']))
{
    $query = $database->query("update task set status='".$_POST['status']."' where id='".$_POST['task']."'");
    if($query)
    {
        echo "<span class='alert alert-success'>Status Updated Succesfully</span>"; ?>
        <script>
            setTimeout(function(){
                setState('addForm','<?php echo SECURE_PATH; ?>department/process.php','addForm=1');
            },3000)
        </script>
    <?php }
    else {
        echo "<span class='alert alert-danger'>Something Went Wrong!Please Try Again</span>";
    }
}
?>
