<?php
include('../include/session.php');

unset($_SESSION['error']);

ini_set('display_errors', 'On');
error_reporting(E_ALL);

if(!$session->logged_in)
{
	?>
	<script type="text/javascript">
	window.location = '<?php echo SECURE_PATH; ?>';
	</script>
	<?php
}
else
{


	?>
	<!-- Breadcrumbs-->
	<section class="breadcrumbs-area2 my-3">
		<div class="container-fluid">
			<div class="d-flex justify-content-between align-items-center">
				<div class="title">
					
				</div>
			</div>
        </div>
	</section>
    <!-- End Breadcrumbs-->
    <div class="content" id="addForm">
        <script>
            setState('addForm','<?php echo SECURE_PATH; ?>department/process.php','addForm=1')
        </script>
    </div>
    <?php

}
?>