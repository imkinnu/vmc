<?php
include('../include/session.php');

unset($_SESSION['error']);

ini_set('display_errors', 'On');
error_reporting(E_ALL); ?>
<head>
    <style>
        .select2-selection {
            height:100px;
        }
        .select2-search__field,.select2-selection--multiple
        {
            width:311px !important;
        }
        #example {
            white-space: nowrap !important;
        }
        #example td, #example th {
            padding: 10px;
            min-width: 100px;
            background: white;
            box-sizing: border-box;
            text-align: left;
        }
        .table-container {
            position: relative;
            max-height:  300px;
            width: 500px;
            overflow: scroll;
        }

        #example thead th {
            position: -webkit-sticky;
            position: sticky;
            top: 0;
        }

        #example thead th:first-child {
            left: 0;
            z-index: 3;
        }
        #example thead th:nth-child(2) {
            left: 100px;
            z-index: 3;
        }
        #example tfoot {
            position: -webkit-sticky;
            bottom: 0;
            z-index: 2;
        }

        #example tfoot td {
            position: sticky;
            bottom: 0;
            z-index: 2;
        }

        #example tfoot td:first-child {
            z-index: 3;
        }

        #example tbody {
            overflow: scroll;
            height: 200px;
        }
        #example tr > :first-child {
            position: -webkit-sticky;
            position: sticky;
            left: 0;
            background-color: #343a40;
            color: white;
        }
        #example tr > :nth-child(2) {
            position: -webkit-sticky;
            position: sticky;
            left: 100px;
            background-color: #343a40;
            color: white;
        }

    </style>
</head>
<?php if(!$session->logged_in)
{
	?>
	<script type="text/javascript">
	window.location = '<?php echo SECURE_PATH; ?>';
	</script>
	<?php
}
else
{
	?>
	<!-- Breadcrumbs-->
	<section class="breadcrumbs-area2 my-3">
		<div class="container-fluid">
			<div class="d-flex justify-content-between align-items-center">
				<div class="title">
					
				</div>
			</div>
        </div>
	</section>
    <div class="content mb-4" id="loadButton">
        <script>
            setState('loadButton','<?php echo SECURE_PATH; ?>createProject/process.php','loadButton=1')
        </script>
    </div>
    <div class="content" id="addForm" style="display: none;">
        <script>
            setState('addForm','<?php echo SECURE_PATH; ?>createProject/process.php','addForm=1')
        </script>
    </div>
    <div class="content" id="tableDisplay">
        <script>
            setState('tableDisplay','<?php echo SECURE_PATH;?>createProject/process.php','tableDisplay=1');
        </script>
    </div>
    <?php
}
?>
</div>

