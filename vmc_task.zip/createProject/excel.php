<?php
/** PHPExcel */
require_once '../Classes/PHPExcel.php';
ini_set('display_errors','on');

include("../include/session.php");



if(!isset($session->logged_in)){
	header("Location: ../");
	
	exit;
	
}

$con = '';


if(isset($_REQUEST['type'])) {
    if ($_REQUEST['type'] == 'project') {
        $query = $database->query("select * from project");


        $rows = $query->rowCount();
        // Create new PHPExcel object
        $objPHPExcel = new PHPExcel();

        // Set properties
        $objPHPExcel->getProperties()->setCreator("Project Data")
            ->setLastModifiedBy("List")
            ->setTitle("List");
        // ->setSubject("PDF Test Document")
        // ->setDescription("Test document for PDF, generated using PHP classes.")
        // ->setKeywords("pdf php")
        // ->setCategory("Test result file");
        $objPHPExcel->getActiveSheet();

        //  PAGE SETUP

        //$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToWidth(1);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setVerticalCentered(true);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setHorizontalCentered(true);


        //$objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF0000');
        $objPHPExcel->getActiveSheet()->getStyle('A2:L2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('ACACAC');
        $objPHPExcel->getActiveSheet()->getStyle('A2:L2')->getFont()->setBold(true);

        // COLUMN SETUP

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(8);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(25);


        //MESSAGE
        //$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(47);  //URL
        $objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(20);

        /*$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);*/


        // setting header


        $objPHPExcel->getActiveSheet()->mergeCells('A1:Q1');


        $objPHPExcel->getActiveSheet()
            ->getCellByColumnAndRow('0', '1')->setValue("  \n  Report Data\n" . "  \n  Generated on: " . date("j M Y, g:i A ", time()) . "\n  Report contains: " . $rows . " results.");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', '2')->setValue(" S.No");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', '2')->setValue(" Project Name");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('2', '2')->setValue(" Project Brief");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('3', '2')->setValue(" Other Details");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('4', '2')->setValue(" Project Type");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('5', '2')->setValue(" Project Initiation Date");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('6', '2')->setValue(" Project Deadline");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('7', '2')->setValue(" Currently With");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('8', '2')->setValue(" Stakeholders");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('9', '2')->setValue(" Estimated Expenditure");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('10', '2')->setValue(" Expenditure Incured");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('11', '2')->setValue(" Status");


        $sno = 0;
        $rcounter = 2;

        // data loop

        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {


            $rcounter++;
            $sno++;

            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', $rcounter)->setValue($sno);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', $rcounter)->setValue($row['project_name']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('2', $rcounter)->setValue($row['project_brief']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('3', $rcounter)->setValue(empty($row['other_details']) ? "--" : $row['other_details']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('4', $rcounter)->setValue($row['project_type']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('5', $rcounter)->setValue($row['initiation_date']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('6', $rcounter)->setValue($row['deadline']);
            $query1 = $database->query("select assignedto from task where status != 5 OR status != 1 and project_name='" . $row['id'] . "'");
            while ($dummy = $query1->fetch_assoc()) {
                $employeeL .= $database->get_name('employee', 'id', $dummy['assignedto'], 'username');
            }
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('7', $rcounter)->setValue(empty($employeeL) ? "No Tasks Created" : $employeeL);
            $stakeholder = explode(',', $row['stakeholder']);
            for ($x = 0; $x < count($stakeholder); $x++) {
                $stakeholderName .= $database->get_name('employee', 'id', $stakeholder[$x], 'username') . ",";
            }
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('8', $rcounter)->setValue($stakeholderName);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('9', $rcounter)->setValue($row['estimated_value']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('10', $rcounter)->setValue($row['final_value']);
            switch ($row['status']) {
                case "2" :
                    $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('11', $rcounter)->setValue('Pending');;
                    break;
                case "1" :
                    $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('11', $rcounter)->setValue('Completed');;
                    break;
            }
        }

        // Set active sheet index to the first sheet, so Excel opens this as the first sheet

        $filename = "Project Data-" . date("j_n_y,G-i.", time()) . "xls";

        // Redirect output to a client's web browser (Excel2005)
        //header('Content-Type: application/vnd.ms-excel');
        //header("Content-Disposition: attachment;filename=".$filename."");
        //header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        //$objWriter->save('php://output');
        $objWriter->save('generatedFiles/' . $filename);
        ?>
        <script type="text/javascript">
            window.location = '<?php echo 'generatedFiles/' . $filename;?>';
        </script>
        <?php

//$objWriter->save("one.pdf");
//exit;
    }
    elseif ($_REQUEST['type'] == 'task')
    {
        $query = $database->query("select * from task");
        $rows = $query->rowCount();
        // Create new PHPExcel object
        $objPHPExcel = new PHPExcel();

        // Set properties
        $objPHPExcel->getProperties()->setCreator("Task Data")
            ->setLastModifiedBy("List")
            ->setTitle("List");
        // ->setSubject("PDF Test Document")
        // ->setDescription("Test document for PDF, generated using PHP classes.")
        // ->setKeywords("pdf php")
        // ->setCategory("Test result file");
        $objPHPExcel->getActiveSheet();

        //  PAGE SETUP

        //$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToWidth(1);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setVerticalCentered(true);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setHorizontalCentered(true);


        //$objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF0000');
        $objPHPExcel->getActiveSheet()->getStyle('A2:K2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('ACACAC');
        $objPHPExcel->getActiveSheet()->getStyle('A2:K2')->getFont()->setBold(true);

        // COLUMN SETUP

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(8);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(25);


        //MESSAGE
        //$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(47);  //URL
        $objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(20);

        /*$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);*/


        // setting header


        $objPHPExcel->getActiveSheet()->mergeCells('A1:Q1');


        $objPHPExcel->getActiveSheet()
            ->getCellByColumnAndRow('0', '1')->setValue("  \n  Task Data\n" . "  \n  Generated on: " . date("j M Y, g:i A ", time()) . "\n  Report contains: " . $rows . " results.");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', '2')->setValue(" S.No");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', '2')->setValue(" Task Title");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('2', '2')->setValue(" Assigned To");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('3', '2')->setValue(" Created By");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('4', '2')->setValue(" Project Name");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('5', '2')->setValue(" Assigned Date");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('6', '2')->setValue(" Due Date");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('7', '2')->setValue(" Expenditure");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('8', '2')->setValue(" Status");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('9', '2')->setValue(" Forwarded To");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('10', '2')->setValue(" Completed By");


        $sno = 0;
        $rcounter = 2;

        // data loop

        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {


            $rcounter++;
            $sno++;

            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', $rcounter)->setValue($sno);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', $rcounter)->setValue($row['title']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('2', $rcounter)->setValue($database->get_name('employee','id',$row['assignedto'],'employee_name' ));
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('3', $rcounter)->setValue($row['created_by']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('4', $rcounter)->setValue($database->get_name('project','id',$row['project_name'],'project_name' ));
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('5', $rcounter)->setValue($row['assigned_date']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('6', $rcounter)->setValue($row['due_date']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('7', $rcounter)->setValue(empty($row['expenditure']) ? "0" : $row['expenditure'] );
            switch ($row['status'])
            {
                case "1" :
                    $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('8', $rcounter)->setValue('Open');
                    break;
                case "2" :
                    $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('8', $rcounter)->setValue('In Progress');
                    break;
                case "3" :
                    $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('8', $rcounter)->setValue('Returned');
                    break;
                case "4" :
                    $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('8', $rcounter)->setValue('Forwarded');
                    break;
                case "5" :
                    $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('8', $rcounter)->setValue('Completed');
                    break;
                case "default" :
                    $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('8', $rcounter)->setValue('NA');
                    break;
            }
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('9', $rcounter)->setValue(empty($row['forwardto']) ? "NA" : $row['forwardto']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('10', $rcounter)->setValue(empty($row['completed_by']) ? "Not Completed" : $row['completed_by']);
        }

        // Set active sheet index to the first sheet, so Excel opens this as the first sheet

        $filename = "Task Data-" . date("j_n_y,G-i.", time()) . "xls";

        // Redirect output to a client's web browser (Excel2005)
        //header('Content-Type: application/vnd.ms-excel');
        //header("Content-Disposition: attachment;filename=".$filename."");
        //header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        //$objWriter->save('php://output');
        $objWriter->save('generatedFiles/' . $filename);
        ?>
        <script type="text/javascript">
            window.location = '<?php echo 'generatedFiles/' . $filename;?>';
        </script>
        <?php

//$objWriter->save("one.pdf");
//exit;
    }
    elseif ($_REQUEST['type'] == 'location')
    {
        $query = $database->query("select * from location");


        $rows = $query->rowCount();
        // Create new PHPExcel object
        $objPHPExcel = new PHPExcel();

        // Set properties
        $objPHPExcel->getProperties()->setCreator("Project Data")
            ->setLastModifiedBy("List")
            ->setTitle("List");
        // ->setSubject("PDF Test Document")
        // ->setDescription("Test document for PDF, generated using PHP classes.")
        // ->setKeywords("pdf php")
        // ->setCategory("Test result file");
        $objPHPExcel->getActiveSheet();

        //  PAGE SETUP

        //$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToWidth(1);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setVerticalCentered(true);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setHorizontalCentered(true);


        //$objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF0000');
        $objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('ACACAC');
        $objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFont()->setBold(true);

        // COLUMN SETUP

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(8);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(25);

        //MESSAGE
        //$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(47);  //URL
        $objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(20);

        /*$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);*/


        // setting header


        $objPHPExcel->getActiveSheet()->mergeCells('A1:Q1');


        $objPHPExcel->getActiveSheet()
            ->getCellByColumnAndRow('0', '1')->setValue("  \n  Location Data\n" . "  \n  Generated on: " . date("j M Y, g:i A ", time()) . "\n  Report contains: " . $rows . " results.");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', '2')->setValue(" S.No");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', '2')->setValue(" Location Name");
        $sno = 0;
        $rcounter = 2;

        // data loop

        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
            $rcounter++;
            $sno++;

            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', $rcounter)->setValue($sno);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', $rcounter)->setValue($row['location']);
        }

        // Set active sheet index to the first sheet, so Excel opens this as the first sheet

        $filename = "Location Data-" . date("j_n_y,G-i.", time()) . "xls";

        // Redirect output to a client's web browser (Excel2005)
        //header('Content-Type: application/vnd.ms-excel');
        //header("Content-Disposition: attachment;filename=".$filename."");
        //header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        //$objWriter->save('php://output');
        $objWriter->save('generatedFiles/' . $filename);
        ?>
        <script type="text/javascript">
            window.location = '<?php echo 'generatedFiles/' . $filename;?>';
        </script>
        <?php
    }
    elseif ($_REQUEST['type'] == 'circle')
    {
        $query = $database->query("select * from circle");


        $rows = $query->rowCount();
        // Create new PHPExcel object
        $objPHPExcel = new PHPExcel();

        // Set properties
        $objPHPExcel->getProperties()->setCreator("Circle Data")
            ->setLastModifiedBy("List")
            ->setTitle("List");
        // ->setSubject("PDF Test Document")
        // ->setDescription("Test document for PDF, generated using PHP classes.")
        // ->setKeywords("pdf php")
        // ->setCategory("Test result file");
        $objPHPExcel->getActiveSheet();

        //  PAGE SETUP

        //$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToWidth(1);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setVerticalCentered(true);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setHorizontalCentered(true);


        //$objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF0000');
        $objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('ACACAC');
        $objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFont()->setBold(true);

        // COLUMN SETUP

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(8);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(25);

        //MESSAGE
        //$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(47);  //URL
        $objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(20);

        /*$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);*/


        // setting header


        $objPHPExcel->getActiveSheet()->mergeCells('A1:Q1');


        $objPHPExcel->getActiveSheet()
            ->getCellByColumnAndRow('0', '1')->setValue("  \n  Circle Data\n" . "  \n  Generated on: " . date("j M Y, g:i A ", time()) . "\n  Report contains: " . $rows . " results.");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', '2')->setValue(" S.No");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', '2')->setValue(" Circle Name");
        $sno = 0;
        $rcounter = 2;

        // data loop

        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
            $rcounter++;
            $sno++;
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', $rcounter)->setValue($sno);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', $rcounter)->setValue($row['circle']);
        }

        // Set active sheet index to the first sheet, so Excel opens this as the first sheet

        $filename = "Circle Data-" . date("j_n_y,G-i.", time()) . "xls";

        // Redirect output to a client's web browser (Excel2005)
        //header('Content-Type: application/vnd.ms-excel');
        //header("Content-Disposition: attachment;filename=".$filename."");
        //header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        //$objWriter->save('php://output');
        $objWriter->save('generatedFiles/' . $filename);
        ?>
        <script type="text/javascript">
            window.location = '<?php echo 'generatedFiles/' . $filename;?>';
        </script>
        <?php
    }
    elseif ($_REQUEST['type'] == 'ward')
    {
        $query = $database->query("select * from ward");
        $rows = $query->rowCount();
        // Create new PHPExcel object
        $objPHPExcel = new PHPExcel();

        // Set properties
        $objPHPExcel->getProperties()->setCreator("Wards Data")
            ->setLastModifiedBy("List")
            ->setTitle("List");
        // ->setSubject("PDF Test Document")
        // ->setDescription("Test document for PDF, generated using PHP classes.")
        // ->setKeywords("pdf php")
        // ->setCategory("Test result file");
        $objPHPExcel->getActiveSheet();

        //  PAGE SETUP

        //$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToWidth(1);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setVerticalCentered(true);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setHorizontalCentered(true);


        //$objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF0000');
        $objPHPExcel->getActiveSheet()->getStyle('A2:C2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('ACACAC');
        $objPHPExcel->getActiveSheet()->getStyle('A2:C2')->getFont()->setBold(true);

        // COLUMN SETUP

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(8);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(25);

        //MESSAGE
        //$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(47);  //URL
        $objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(20);

        /*$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);*/


        // setting header


        $objPHPExcel->getActiveSheet()->mergeCells('A1:Q1');


        $objPHPExcel->getActiveSheet()
            ->getCellByColumnAndRow('0', '1')->setValue("  \n  Wards Data\n" . "  \n  Generated on: " . date("j M Y, g:i A ", time()) . "\n  Report contains: " . $rows . " results.");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', '2')->setValue(" S.No");

        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', '2')->setValue(" Circle");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('2', '2')->setValue(" Ward Name");
        $sno = 0;
        $rcounter = 2;

        // data loop

        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
            $rcounter++;
            $sno++;
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', $rcounter)->setValue($sno);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', $rcounter)->setValue($database->get_name('circle','id',$row['circle'],
                'circle'));
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('2', $rcounter)->setValue($row['ward']);
        }

        // Set active sheet index to the first sheet, so Excel opens this as the first sheet

        $filename = "Wards Data-" . date("j_n_y,G-i.", time()) . "xls";

        // Redirect output to a client's web browser (Excel2005)
        //header('Content-Type: application/vnd.ms-excel');
        //header("Content-Disposition: attachment;filename=".$filename."");
        //header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        //$objWriter->save('php://output');
        $objWriter->save('generatedFiles/' . $filename);
        ?>
        <script type="text/javascript">
            window.location = '<?php echo 'generatedFiles/' . $filename;?>';
        </script>
        <?php
    }
    elseif ($_REQUEST['type'] == 'department')
    {
        $query = $database->query("select * from department");


        $rows = $query->rowCount();
        // Create new PHPExcel object
        $objPHPExcel = new PHPExcel();

        // Set properties
        $objPHPExcel->getProperties()->setCreator("Department Data")
            ->setLastModifiedBy("List")
            ->setTitle("List");
        // ->setSubject("PDF Test Document")
        // ->setDescription("Test document for PDF, generated using PHP classes.")
        // ->setKeywords("pdf php")
        // ->setCategory("Test result file");
        $objPHPExcel->getActiveSheet();

        //  PAGE SETUP

        //$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToWidth(1);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setVerticalCentered(true);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setHorizontalCentered(true);


        //$objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF0000');
        $objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('ACACAC');
        $objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFont()->setBold(true);

        // COLUMN SETUP

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(8);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(25);

        //MESSAGE
        //$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(47);  //URL
        $objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(20);

        /*$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);*/


        // setting header


        $objPHPExcel->getActiveSheet()->mergeCells('A1:Q1');


        $objPHPExcel->getActiveSheet()
            ->getCellByColumnAndRow('0', '1')->setValue("  \n  Department Data\n" . "  \n  Generated on: " . date("j M Y, g:i A ", time()) . "\n  Report contains: " . $rows . " results.");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', '2')->setValue(" S.No");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', '2')->setValue(" Department Name");
        $sno = 0;
        $rcounter = 2;

        // data loop

        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
            $rcounter++;
            $sno++;

            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', $rcounter)->setValue($sno);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', $rcounter)->setValue($row['department']);
        }

        // Set active sheet index to the first sheet, so Excel opens this as the first sheet

        $filename = "Location Data-" . date("j_n_y,G-i.", time()) . "xls";

        // Redirect output to a client's web browser (Excel2005)
        //header('Content-Type: application/vnd.ms-excel');
        //header("Content-Disposition: attachment;filename=".$filename."");
        //header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        //$objWriter->save('php://output');
        $objWriter->save('generatedFiles/' . $filename);
        ?>
        <script type="text/javascript">
            window.location = '<?php echo 'generatedFiles/' . $filename;?>';
        </script>
        <?php
    }
    elseif ($_REQUEST['type'] == 'designation')
    {
        $query = $database->query("select * from designation");
        $rows = $query->rowCount();
        // Create new PHPExcel object
        $objPHPExcel = new PHPExcel();

        // Set properties
        $objPHPExcel->getProperties()->setCreator("Designation Data")
            ->setLastModifiedBy("List")
            ->setTitle("List");
        // ->setSubject("PDF Test Document")
        // ->setDescription("Test document for PDF, generated using PHP classes.")
        // ->setKeywords("pdf php")
        // ->setCategory("Test result file");
        $objPHPExcel->getActiveSheet();

        //  PAGE SETUP

        //$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToWidth(1);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setVerticalCentered(true);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setHorizontalCentered(true);


        //$objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF0000');
        $objPHPExcel->getActiveSheet()->getStyle('A2:C2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('ACACAC');
        $objPHPExcel->getActiveSheet()->getStyle('A2:C2')->getFont()->setBold(true);

        // COLUMN SETUP

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(8);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(25);

        //MESSAGE
        //$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(47);  //URL
        $objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(20);

        /*$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);*/


        // setting header


        $objPHPExcel->getActiveSheet()->mergeCells('A1:Q1');


        $objPHPExcel->getActiveSheet()
            ->getCellByColumnAndRow('0', '1')->setValue("  \n  Designation Data\n" . "  \n  Generated on: " . date("j M Y, g:i A ", time()) . "\n  Report contains: " . $rows . " results.");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', '2')->setValue(" S.No");

        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', '2')->setValue(" Department");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('2', '2')->setValue(" Designation");
        $sno = 0;
        $rcounter = 2;

        // data loop

        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
            $rcounter++;
            $sno++;

            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', $rcounter)->setValue($sno);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', $rcounter)->setValue($database->get_name('department','id',$row['department'],
                'department'));
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('2', $rcounter)->setValue($row['designation']);
        }

        // Set active sheet index to the first sheet, so Excel opens this as the first sheet

        $filename = "Designation Data-" . date("j_n_y,G-i.", time()) . "xls";

        // Redirect output to a client's web browser (Excel2005)
        //header('Content-Type: application/vnd.ms-excel');
        //header("Content-Disposition: attachment;filename=".$filename."");
        //header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        //$objWriter->save('php://output');
        $objWriter->save('generatedFiles/' . $filename);
        ?>
        <script type="text/javascript">
            window.location = '<?php echo 'generatedFiles/' . $filename;?>';
        </script>
        <?php
    }
    elseif ($_REQUEST['type'] == 'employee')
    {
        $query = $database->query("select * from employee");
        $rows = $query->rowCount();
        // Create new PHPExcel object
        $objPHPExcel = new PHPExcel();

        // Set properties
        $objPHPExcel->getProperties()->setCreator("Employee Data")
            ->setLastModifiedBy("List")
            ->setTitle("List");
        // ->setSubject("PDF Test Document")
        // ->setDescription("Test document for PDF, generated using PHP classes.")
        // ->setKeywords("pdf php")
        // ->setCategory("Test result file");
        $objPHPExcel->getActiveSheet();

        //  PAGE SETUP

        //$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToWidth(1);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setVerticalCentered(true);
        //$objPHPExcel->getActiveSheet()->getPageSetup()->setHorizontalCentered(true);


        //$objPHPExcel->getActiveSheet()->getStyle('A2:B2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF0000');
        $objPHPExcel->getActiveSheet()->getStyle('A2:K2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('ACACAC');
        $objPHPExcel->getActiveSheet()->getStyle('A2:K2')->getFont()->setBold(true);

        // COLUMN SETUP

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(8);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(25);

        //MESSAGE
        //$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(47);  //URL
        $objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(20);

        /*$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);*/


        // setting header


        $objPHPExcel->getActiveSheet()->mergeCells('A1:Q1');


        $objPHPExcel->getActiveSheet()
            ->getCellByColumnAndRow('0', '1')->setValue("  \n  Employee Data\n" . "  \n  Generated on: " . date("j M Y, g:i A ", time()) . "\n  Report contains: " . $rows . " results.");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', '2')->setValue(" S.No");

        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', '2')->setValue(" Employee Code");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('2', '2')->setValue(" Employee Name");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('3', '2')->setValue(" Employment Type");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('4', '2')->setValue(" Department");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('5', '2')->setValue(" Designation");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('6', '2')->setValue(" Location");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('7', '2')->setValue(" Mobile");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('8', '2')->setValue(" Email");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('9', '2')->setValue(" Date Of Birth");
        $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('10', '2')->setValue(" Date Of Joining");
        $sno = 0;
        $rcounter = 2;

        // data loop

        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
            $rcounter++;
            $sno++;
            $query1 = $database->query("select assignedto from task where status != 5 OR status != 1 and project_name='" . $row['id'] . "'");
            $employeeL = $stakeholderName = '';

            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', $rcounter)->setValue($sno);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', $rcounter)->setValue($row['employee_code']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('2', $rcounter)->setValue($row['employee_name']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('3', $rcounter)->setValue($row['employment_type']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('4', $rcounter)->setValue($database->get_name('department','id',$row['department'],'department'));
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('5', $rcounter)->setValue($database->get_name('designation','id',$row['designation'],'designation'));
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('6', $rcounter)->setValue($database->get_name('location','id',$row['location'],'location'));
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('7', $rcounter)->setValue($row['mobile']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('8', $rcounter)->setValue($row['email']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('9', $rcounter)->setValue($row['dob']);
            $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('10', $rcounter)->setValue($row['doj']);
        }

        // Set active sheet index to the first sheet, so Excel opens this as the first sheet

        $filename = "Employee Data-" . date("j_n_y,G-i.", time()) . "xls";

        // Redirect output to a client's web browser (Excel2005)
        //header('Content-Type: application/vnd.ms-excel');
        //header("Content-Disposition: attachment;filename=".$filename."");
        //header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        //$objWriter->save('php://output');
        $objWriter->save('generatedFiles/' . $filename);
        ?>
        <script type="text/javascript">
            window.location = '<?php echo 'generatedFiles/' . $filename;?>';
        </script>
        <?php
    }
}
?>