<?php
error_reporting(1);
ini_set('display_errors','On');
include('../include/session.php');
if(!$session->logged_in){
    ?>
    <script type="text/javascript">
        setStateGet('main','<?php echo SECURE_PATH;?>login_process.php','loginForm=1');
    </script>
    <?php
} ?>
<?php if(isset($_POST['loadButton'])){
    ?>
    <button class="btn btn-primary" id="create_project"><i class="fa fa-plus-circle text-white"></i> Create Project</button>
    <script>
        // $('#addForm').css('display', 'none');
        $('#create_project').on('click',function(){
            $('#addForm').slideToggle();
        })
    </script>
<?php } ?>
<?php if(isset($_POST['addForm'])){ ?>
    <?php if($_POST['addForm'] == 2 && isset($_POST['editform'])){ ?>
        <script>
            $('#addForm').slideDown();
        </script>
        <?php $data_sel = $database->connection->prepare("SELECT * FROM project WHERE id =:id");
        $data_sel->execute(array('id'=>$_POST['editform']));
        $data = $data_sel->fetch(PDO::FETCH_ASSOC);
        $flag=1;
        $_POST = array_merge($data,$_POST);
    }
    ?>
    <section class="content-area">
        <div class="row">
            <div class="col-xl-12 col-lg-12">
                <div class="card border-0 shadow mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Create New Project</h6>
                        <span class="float-right">
                                <a role="button" onclick="setState('addForm','<?php echo SECURE_PATH ?>createProject/process.php','addForm=1 ')"><i class="fa fa-refresh text-primary text-lg-right"></i> Refresh</a>
                            </span>
                    </div>
                    <div class="card-body">
                        <form id="taskForm">
                            <script type="text/javascript" src="<?php echo SECURE_PATH;?>vendor/app/js/select2.min.js"></script>
                            <link href="<?php echo SECURE_PATH;?>vendor/app/css/select2.min.css" rel="stylesheet">
                            <div class="form-group ">
                                <div class="form-group row">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6 col-md-12">
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Project Name<span style="color:red;">*</span></label>
                                                    <div class="col-sm-8">
                                                        <input id="project_name" class="form-control" placeholder="Project Name" value="<?php if(isset($_POST['project_name'])){echo $_POST['project_name'];}?>" />
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['project_name'])){echo $_SESSION['error']['project_name'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Other Details</label>
                                                    <div class="col-sm-8">
                                                        <textarea id="other_details" class="form-control" rows="4" placeholder="Enter Any Other Details Here.."><?php if(isset($_POST['other_details'])){echo $_POST['other_details'];}?></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group row mt-4">
                                                    <label class="col-sm-4 col-form-label">Project Type<span style="color:red;">*</span></label>
                                                    <div class="col-sm-8">
                                                        <select class="form-control text-capitalize" id="project_type">
                                                            <option value="">Select</option>
                                                            <option value="new"<?php if(isset($_POST['project_type'])){if($_POST['project_type'] == 'new'){echo "selected";} }?> >New</option>
                                                            <option value="maintainance"<?php if(isset($_POST['project_type'])){if($_POST['project_type'] == 'maintainance'){echo "selected";} } ?> >Maintainance</option>
                                                        </select>
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['project_type'])){echo $_SESSION['error']['project_type'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row mt-4">
                                                    <label class="col-sm-4 col-form-label">Initiation Date<span class="text-danger">*</span></label>
                                                    <div class="col-sm-8">
                                                        <input class="form-control datepicker1" id="initiation_date" value="<?php if(isset($_POST['initiation_date'])){echo $_POST['initiation_date'] ;}?>" maxlength="10" autocomplete="off" tabindex="1" placeholder="Select Project Initiation Date">
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['initiation_date'])){ echo $_SESSION['error']['initiation_date'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row mt-4">
                                                    <label class="col-sm-4 col-form-label">Deadline<span class="text-danger">*</span></label>
                                                    <div class="col-sm-8">
                                                        <input class="form-control datepicker1" id="deadline" value="<?php if(isset($_POST['deadline'])){echo $_POST['deadline'] ;}?>" maxlength="10" autocomplete="off" id="date" tabindex="1" placeholder="Select Project Deadline Date">
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['deadline'])){ echo $_SESSION['error']['deadline'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row mt-4">
                                                    <label class="col-sm-4 col-form-label">Circle<span class="text-danger">*</span></label>
                                                    <div class="col-sm-8">
                                                        <select class="form-control" id="circle" onchange="setState('addForm','<?php echo SECURE_PATH ?>createProject/process.php','addForm=1&project_name='+$('#project_name').val()+'&project_brief='+$('#project_brief').val()+'&other_details='+$('#other_details').val()+'&project_type='+$('#project_type').val()+'&attachments='+$('#image').val()+'&stakeholder='+$('#stakeholders').val()+'&initiation_date='+$('#initiation_date').val()+'&deadline='+$('#deadline').val()+'&estimated_value='+$('#estimated_value').val()+'&circle='+$(this).val()+'&ward='+$('#ward').val()+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform'];}?>' )">
                                                            <option value="">Select Circle</option>
                                                            <?php
                                                            $stmt=$database->connection->prepare("select * from circle ");
                                                            $stmt->execute();
                                                            while($row = $stmt->fetch(PDO::FETCH_ASSOC))
                                                            { ?>
                                                                <option value="<?php echo $row['id']?>"
                                                                    <?php
                                                                    if(isset($_POST['circle']))
                                                                    {
                                                                        if($_POST['circle'] == $row['id'])
                                                                        {
                                                                            echo "selected";
                                                                        }
                                                                    }
                                                                    ?>
                                                                ><?php echo $row['circle']?></option>
                                                            <?php }
                                                            ?>
                                                        </select>
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['circle'])){ echo $_SESSION['error']['circle'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row file_uploader mt-5">
                                                    <label class="col-sm-6 col-form-label" style="text-align:left;">Other Attachments If Any<span style="color:red;">*</span></label>
                                                    <div id="file-uploader2" style="display:inline">
                                                        <noscript>
                                                            <p>Please enable JavaScript to use file uploader.</p>
                                                            <!-- or put a simple form for upload here -->
                                                        </noscript>
                                                    </div>
                                                    <script>

                                                        function createUploader(){
                                                            var uploader = new qq.FileUploader({
                                                                element: document.getElementById('file-uploader2'),
                                                                action: '<?php echo SECURE_PATH;?>theme/js/upload/php2.php?upload=image&upload_type=single&filetype=file',
                                                                debug: true,
                                                                multiple:false
                                                            });
                                                        }
                                                        createUploader();
                                                        // in your app create uploader as soon as the DOM is ready
                                                        // don't wait for the window to load

                                                    </script>
                                                    <input type="hidden" name="image" id="image" value="<?php if(isset($_POST['image'])) { echo $_POST['image']; } ?>"/>
                                                    <?php
                                                    if(isset($_POST['file']))
                                                    {
                                                        ?>
                                                        <a href="<?php echo SECURE_PATH."files/".$_POST['image'];?>" target="_blank" >View Document</a>
                                                        <?php

                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-md-12">
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Project Brief<span style="color:red;">*</span></label>
                                                    <div class="col-sm-8">
                                                        <textarea id="project_brief" class="form-control" rows="7" placeholder="Start Typing Project Brief.."><?php if(isset($_POST['project_brief'])){echo $_POST['project_brief'];}?></textarea>
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['project_brief'])){echo $_SESSION['error']['project_brief'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Stakeholders<span style="color:red;">*</span></label>
                                                    <div class="col-sm-8">
                                                            <select tabindex="3" class="js-example-basic-multiple form-control text-capitalize" id="stakeholders" multiple="multiple">
                                                            <?php
                                                            $stmt=$database->connection->prepare("select id,username,department,designation from employee ");
                                                            $stmt->execute();
                                                            while($row = $stmt->fetch(PDO::FETCH_ASSOC))
                                                            { ?>
                                                                <option value="<?php echo $row['id']?>"
                                                                    <?php if(isset($_POST['stakeholder']))
                                                                    {
                                                                        $exStake = explode(',',$_POST['stakeholder']);
                                                                        for($k = 0;$k<count($exStake);$k++)
                                                                        {
                                                                            if($exStake[$k] == $row['id'])
                                                                            {
                                                                                echo 'selected="selected"';
                                                                            }
                                                                        }
                                                                    } ?>
                                                                ><?php echo strtoupper($row['username']."(".$database->get_name('department','id',$row['department'],'department').",". $database->get_name('designation','id',$row['designation'],'designation').")") ?></option>
                                                            <?php }
                                                            ?>
                                                        </select>
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['stakeholder'])){echo $_SESSION['error']['stakeholder'];}?></span>
                                                    </div>
                                                    <script>

                                                        $( document ).ready(function() {
                                                            $('.js-example-basic-multiple ').select2({
                                                                placeholder: 'Start Entering a Name..',
                                                                dropdownAutoWidth : true,
                                                                // selectOnClose:true
                                                            });
                                                        });

                                                    </script>
                                                </div>

                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label"><span style="color:red;">*</span>Estimated Value</label>
                                                    <div class="col-sm-8">
                                                        <div class="input-group mb-3">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text">₹</span>
                                                            </div>
                                                            <input type="text" id="estimated_value" class="form-control" aria-label="Amount (to the nearest rupee)" value="<?php if(isset($_POST['estimated_value'])){echo $_POST['estimated_value'];}?>">
                                                            <div class="input-group-append">
                                                                <span class="input-group-text">.00</span>
                                                            </div>
                                                        </div>
                                                        <span class="text-danger text-center"><?php if(isset($_SESSION['error']['estimated_value'])){echo $_SESSION['error']['estimated_value'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Ward<span class="text-danger">*</span></label>
                                                    <div class="col-sm-8">
                                                        <select class="form-control" id="ward">
                                                            <option value="">Select Ward</option>
                                                            <?php
                                                            if(isset($_POST['circle']))
                                                            {
                                                                $stmt = $database->connection->prepare("select * from ward where circle = :circle");
                                                                $stmt->execute(array('circle'=>$_POST['circle']));
                                                                while($row = $stmt->fetch(PDO::FETCH_ASSOC))
                                                                { ?>
                                                                    <option value="<?php echo $row['id']?>"
                                                                        <?php
                                                                        if(isset($_POST['ward']))
                                                                        {
                                                                            if($_POST['ward'] == $row['id'])
                                                                            {
                                                                                echo "selected";
                                                                            }
                                                                        }
                                                                        ?>
                                                                    ><?php echo $row['ward']?></option>
                                                                <?php }
                                                            } ?>
                                                        </select>
                                                        <span class="text-danger"><?php if(isset($_SESSION['error']['ward'])){ echo $_SESSION['error']['ward'];}?></span>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <?php
                                                    if(isset($_POST['editform']))
                                                    { ?>
                                                        <a class="ml-5 mt-2 radius-20 btn btn-primary text-white px-5" style="cursor: pointer;" onclick="setState('result','<?php echo SECURE_PATH ?>createProject/process.php','validateForm=1&project_name='+$('#project_name').val()+'&project_brief='+$('#project_brief').val()+'&other_details='+$('#other_details').val()+'&project_type='+$('#project_type').val()+'&attachments='+$('#image').val()+'&stakeholder='+$('#stakeholders').val()+'&initiation_date='+$('#initiation_date').val()+'&deadline='+$('#deadline').val()+'&estimated_value='+$('#estimated_value').val()+'&circle='+$('#circle').val()+'&ward='+$('#ward').val()+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform'];}?>' )">Update</a>
                                                    <?php }
                                                    else { ?>
                                                        <a class="ml-5 mt-2 radius-20 btn btn-success text-white px-5" style="cursor: pointer;" onclick="setState('result','<?php echo SECURE_PATH ?>createProject/process.php','validateForm=1&project_name='+$('#project_name').val()+'&project_brief='+$('#project_brief').val()+'&other_details='+$('#other_details').val()+'&project_type='+$('#project_type').val()+'&attachments='+$('#image').val()+'&stakeholder='+$('#stakeholders').val()+'&initiation_date='+$('#initiation_date').val()+'&deadline='+$('#deadline').val()+'&estimated_value='+$('#estimated_value').val()+'&circle='+$('#circle').val()+'&ward='+$('#ward').val() )">Create</a>
                                                    <?php }
                                                    ?>
                                                    <a class="ml-2 mt-2 radius-20 btn btn-danger text-white px-5" style="cursor: pointer;" onclick="setState('addForm','<?php echo SECURE_PATH?>createProject/process.php','addForm=1')">Reset</a>
                                                </div>
                                                <div id="result" class="row mt-5 ml-5">

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script type="text/javascript">
        $(document).ready(function() {
            $(function () {
                $('.datepicker1,.datepicker2,.datepicker3').datetimepicker({
                    format: 'DD-MM-YYYY'
                });
            })
        });
    </script>
    <?php
}
if(isset($_POST['tableDisplay']))
{ ?>
    <script type="text/javascript">
        var tableToExcel = (function () {
            var uri = 'data:application/vnd.ms-excel;base64,'
                ,
                template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
                , base64 = function (s) {
                    return window.btoa(unescape(encodeURIComponent(s)))
                }
                , format = function (s, c) {
                    return s.replace(/{(\w+)}/g, function (m, p) {
                        return c[p];
                    })
                };
            return function (table, name) {
                if (!table.nodeType) table = document.getElementById(table)
                var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
                window.location.href = uri + base64(format(template, ctx))
            }
        })()
    </script>
    <?php
    $i=1;
    $uname = 'admin';
    $stmt1 = $database->connection->prepare("select * from project order by status ASC");
    $stmt1->execute();
    ?>
    <section class="content-area">
        <div class="row">
            <div class="col-xl-12 col-lg-12">
                <div class="card border-0 shadow mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Projects Created</h6>
                        <button class="btn btn-success" onclick="tableToExcel('example', 'List of Circles')"><i
                                    class="fa fa-file-excel-o"></i> Download</button>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php if($stmt1->rowCount()>0){ ?>
                                <table class="table table-bordered table-responsive ml-3" id="example">
                                    <thead>
                                    <tr>
                                        <th>SNO</th>
                                        <th>Project Name</th>
                                        <th>Project Brief</th>
                                        <th>Other Details</th>
                                        <th>Project Type</th>
                                        <th>Project Initiation Date</th>
                                        <th>Project Deadline</th>
                                        <th>Currently With</th>
                                        <th>Stakeholders</th>
                                        <th>Estimated Expenditure</th>
                                        <th>Expenditure Incured</th>
                                        <th>Status</th>
                                        <th colspan="2">#</th>
                                    </tr>
                                    </thead>
                                    <?php
                                    while($row = $stmt1->fetch(PDO::FETCH_ASSOC))
                                    {
                                        ?>
                                        <tbody>
                                        <tr>
                                            <td><?php echo $i++; ?></td>
                                            <td><?php echo $row['project_name'] ?></td>
                                            <td><?php echo $row['project_brief'] ?></td>
                                            <td><?php echo empty($row['other_details'])? "--" : $row['other_details'] ?></td>
                                            <td class="text-capitalize"><?php echo $row['project_type'] ?></td>
                                            <td><?php echo $row['initiation_date'] ?></td>
                                            <td><?php echo $row['deadline'] ?></td>
                                            <td class="text-capitalize"><?php
                                                $session->getAssignedTo($row['id']);
                                                ?></td>
                                            <td class="text-capitalize"><?php
                                                $stakeholder = explode(',',$row['stakeholder']);$stakeholderV = '';
                                                for($x = 0 ; $x < count($stakeholder) ; $x++){
                                                    $stakeholderV .= $database->get_name('employee','id',$stakeholder[$x],'username').",";
                                                }
                                                echo rtrim($stakeholderV,",");
                                                ?></td>
                                            <td><?php echo $row['estimated_value'] ?></td>
                                            <td><?php echo $row['final_value'] ?></td>
                                            <td><?php switch ($row['status'])
                                                {
                                                    case "2" :echo "<span class='badge badge-warning'>Pending</span>";
                                                        break;
                                                    case "1" : echo "<span class='badge badge-success'>Completed</span>";
                                                }?></td>
                                            <?php if($row['status'] == 2){ ?>
                                                <td><a type="button" id="edit" class="btn btn-warning" onclick="setState('addForm','<?php echo SECURE_PATH?>createProject/process.php','addForm=2&editform=<?php echo $row['id'] ?>')" ><i class="fa fa-edit"></i></a></td>
                                                <td><button onclick="completeProject(<?php echo $row['id'] ?>)" class="btn btn-success"><i class="fa fa-check"></i></button></td><?php }
                                            else { ?>
                                                <td><?php echo "NA";?></td>
                                                <td><?php echo "NA";?></td>
                                            <?php } ?>
                                        </tr>
                                        </tbody>
                                    <?php } ?>
                                </table>

                            <?php }
                            else {
                                echo "No results to display";
                            }?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php }
if(isset($_POST['validateForm']))
{
    $_SESSION['error'] = array();
    $field = 'project_name';
    if(!$_POST['project_name'] || strlen(trim($_POST['project_name'])) == 0)
    {
        $_SESSION['error'][$field] = "* Please Enter Project Name";
    }

    $field = 'project_brief';
    if(!$_POST['project_brief'] || strlen(trim($_POST['project_brief'])) == 0)
    {
        $_SESSION['error'][$field] = "* Please Enter Project Brief";
    }

//    $field = 'other_details';
//    if(!$_POST['other_details'] || strlen(trim($_POST['other_details'])) == 0)
//    {
//        $_SESSION['error'][$field] = "* Please Select Employee";
//    }

    $field = 'project_type';
    if(!$_POST['project_type'] || strlen(trim($_POST['project_type'])) == 0)
    {
        $_SESSION['error'][$field] = "* Please Select Project Type";
    }

    $field = 'stakeholder';
    if(!$_POST['stakeholder'] || strlen(trim($_POST['stakeholder'])) == 0 || $_POST['stakeholder'] == 'null')
    {
        $_SESSION['error'][$field] = "* Please Select Stakeholders";
    }

    $field = "initiation_date";
    if(!$_POST['initiation_date'] || strlen(trim($_POST['initiation_date'])) == 0 )
    {
        $_SESSION['error'][$field] = "* Please Select Project Iniatition Date";
    }

    $field = "deadline";
    if(!$_POST['deadline'] || strlen(trim($_POST['deadline'])) == 0 )
    {
        $_SESSION['error'][$field] = "* Please Select Project Project Deadline";
    }

    $field = 'estimated_value';
    if ($_POST['estimated_value'] == "")
    {
        $_SESSION['error'][$field]  = "* Please Enter Estimated Value";
    }

//    $field = 'final_value';
//    if ($_POST['final_value'] == "")
//    {
//        $_SESSION['error'][$field]  = "* Please Enter Final Value";
//    }

    if(count($_SESSION['error']) > 0)
    {
        ?>
        <script type="text/javascript">
            setState('addForm','<?php echo SECURE_PATH ?>createProject/process.php','addForm=1&project_name='+$('#project_name').val()+'&project_brief='+$('#project_brief').val()+'&other_details='+$('#other_details').val()+'&project_type='+$('#project_type').val()+'&attachments='+$('#image').val()+'&stakeholder='+$('#stakeholders').val()+'&initiation_date='+$('#initiation_date').val()+'&deadline='+$('#deadline').val()+'&estimated_value='+$('#estimated_value').val() )
        </script>
        <?php

    }
    else
    {
        unset($_SESSION['error']);
        if(isset($_POST['editform']))
        {
            $stmt = $database->connection->prepare("UPDATE project SET project_name='" . $_POST['project_name'] . "',project_brief='" . $_POST['project_brief'] . "',other_details='" . $_POST['other_details'] . "',project_type='" . $_POST['project_type'] . "',attachments='" . $_POST['attachments'] . "',stakeholder='" .$_POST['stakeholder'] . "',initiation_date='".$_POST['initiation_date']."',deadline='".$_POST['deadline']."',estimated_value='" . $_POST['estimated_value'] . "',username='" . $session->username . "',timestamp='" . time() . "' WHERE id=:id");
            $stmt->execute(array("id"=>$_POST['editform']));
            if($stmt)
            {
                ?>
                <span class="alert alert-warning">Project Details Updated</span>
                <script>
                    setTimeout(function() {
                        setState('addForm', '<?php echo SECURE_PATH; ?>createProject/process.php','addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>createProject/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
            else
            {
                ?>
                <script>
                    setTimeout(function() {
                        setState('addForm', '<?php echo SECURE_PATH; ?>createProject/process.php','addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>createProject/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
        }
        else
        {
            $desg='';
            $stmt = $database->connection->prepare("SELECT MAX(project_idi) FROM project");
            $stmt->execute();
            $rowmax=$stmt->fetch(PDO::FETCH_ASSOC);

            $emaxid=$rowmax['MAX(project_idi)']+1;

            $xlen=strlen($emaxid);
            $xval=5-$xlen;
            for($x=1;$x<=$xval;$x++)
            {
                $desg .="0";
            }

            $empidD=$desg.$emaxid;
            $projectidi = "PJ".$empidD;
            $insert = $database->connection->prepare("insert into project values (:nu,:emaxid,:projectidi,:project_name,:project_brief,:other_details,:project_type,:initiation_date,:deadline,:attachments,:stakeholder,:estimated_value,:zero,:circle,:ward,:username,:two,:ti) ");
            $insert->execute(array("nu"=>NULL,"emaxid"=>$emaxid,"projectidi"=>$projectidi,"project_name"=>$_POST['project_name'],"project_brief"=>$_POST['project_brief'],"other_details"=>$_POST['other_details'],"project_type"=>$_POST['project_type'],"initiation_date"=>$_POST['initiation_date'],"deadline"=>$_POST['deadline'],"attachments"=>$_POST['attachments'],"stakeholder"=>$_POST['stakeholder'],"estimated_value"=>$_POST['estimated_value'],"zero"=>0,"circle"=>$_POST['circle'],"ward"=>$_POST['ward'],"username"=>$session->username,"two"=>2,"ti"=>time() ));
            if($insert)
            {
                ?>
                <span class="alert alert-success">Project Created Succesfully</span>
                <script>
                    setTimeout(function(){
                        setState('addForm','<?php echo SECURE_PATH; ?>/createProject/process.php','addForm=1');
                        setState('tableDisplay','<?php echo SECURE_PATH; ?>/createProject/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
            else
            {
                echo "fail";
                ?>
                <div class="alert alert-danger"><?php echo $database->connection->errorInfo(); ?></div>
                <script>
                    setTimeout(function() {
                        setState('addForm', '<?php echo SECURE_PATH; ?>createProject/process.php','addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>createProject/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
        }
        ?>
        <?php
    }
}
if(isset($_REQUEST['complete']))
{
    $query = $database->connection->prepare("update project set status=1 where id=:id");
    $query->execute(array('id'=>$_REQUEST['id']));
    if($query)
    {
        echo '<span class="text-success">Status Changed To Completed</span>' ?>
        <script>
            setTimeout(function() {
                setState('addForm', '<?php echo SECURE_PATH; ?>createProject/process.php','addForm=1');
                setState('tableDisplay', '<?php echo SECURE_PATH; ?>createProject/process.php','tableDisplay=1');
            },3000)
        </script>
    <?php }
}
?>
<div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModal3Label" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModal3Label">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                ...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>

<script>
    function completeProject(id)
    {
        var r = confirm("Are You Sure to want to mark this project as completed?");
        if (r == true) {
            setState('tableDisplay','<?php echo SECURE_PATH?>createProject/process.php','complete=1&id='+id);
        } else {
            txt = "You pressed Cancel!";
        }
    }
</script>

