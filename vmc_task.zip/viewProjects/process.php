<?php
error_reporting(1);
ini_set('display_errors', 'On');
include('../include/session.php');
if (!$session->logged_in) {
    ?>
    <script type="text/javascript">
        setStateGet('main', '<?php echo SECURE_PATH;?>login_process.php', 'loginForm=1');
    </script>
    <?php
}
if (isset($_POST['addForm'])) { ?>
<section class="content-area">
    <div class="row">
        <div class="col-xl-12 col-lg-12">
            <div class="card border-0 shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h4 class="m-0 font-weight-bold text-primary">Your Projects</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php if (isset($_REQUEST['project_id'])) {
                            $query = $session->query("select * from project where project_id=:project_id");
                            $query->execute(array('project_id' => $_REQUEST['project_id']));
                            $row = $query->fetch(PDO::FETCH_ASSOC);
                        } else {
                            $filtered_array = array_filter($session->getProjects($session->username));
                            if (count($filtered_array) > 0) {
                                $query = $session->query("select * from project where project_id=:filtered_array");
                                $query->execute(array('filtered_array' => $filtered_array[0]));
                                $row = $query->fetch(PDO::FETCH_ASSOC);
                            } else {
                                echo "No Results to Display";
                            }
                        }
                        ?>
                        <div>
                            <div class="card-header">
                                <h1>Project Title :
                                    <small><?php echo $row['project_name'] ?></small>
                                </h1>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <img class="img-fluid"
                                         src="<?php echo SECURE_PATH ?><?php echo empty($row['attachments']) ? 'vendor/images/no-photo.jpg' : 'files/' . $row['attachments'] ?>"
                                         alt="">
                                </div>
                                <div class="col-md-4">
                                    <h3 class="my-3">Project Description</h3>
                                    <p><?php echo $row['project_brief'] ?></p>
                                    <h3 class="my-3">Stakeholders</h3>
                                    <?php
                                    $stakeholder = explode(',', $row['stakeholder']);
                                    ?>
                                    <ul type="1">
                                        <?php for ($i = 0; $i < count($stakeholder); $i++) { ?>
                                            <li class="text-capitalize"><?php echo $database->get_name('employee', 'id', $stakeholder[$i], 'username') ?></li>
                                        <?php } ?>
                                    </ul>
                                    <h3 class="my-3">Other Details</h3>
                                    <p class="my-3"><?php echo $row['other_details'] ?></p>
                                    <span><?php echo "<span class='badge badge-success'>" . $row['initiation_date'] . "</span> - <span class='badge badge-danger'>" . $row['deadline'] . "</span>" ?></span>
                                    <script>
                                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>viewProjects/process.php', 'tableDisplay=1')
                                    </script>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
if (isset($_REQUEST['tableDisplay'])) { ?>
    <h3 class="my-4">Related Projects</h3>
    <?php
    $filtered_array = array_filter($session->getProjects($session->username));
    if (count($filtered_array) > 0) { ?>
        <div class="row">
            <?php for ($i = 0; $i < count($filtered_array); $i++) {
                $query = $session->query("select * from project where project_id=:filteredArray");
                $query->execute(array('filteredArray' => $filtered_array[$i]));
                while ($row = $query->fetch(PDO::FETCH_ASSOC)) { ?>
                    <div class="col-md-3 ml-2 card-header col-sm-6 mb-4 card"
                         onclick="setState('addForm','<?php echo SECURE_PATH ?>viewProjects/process.php','addForm=1&project_id=<?php echo $row['project_id'] ?>')">
                        <a href="#">
                            <span class="text-capitalize"><?php echo $row['project_name'] ?></span>
                            <img class="img-fluid"
                                 src="<?php echo SECURE_PATH ?>files/<?php echo $row['attachments'] ?>" alt="">
                        </a>
                    </div>
                <?php }
            }
            ?>
        </div>
    <?php }
}
?>
