<?php
include('include/session.php');
ini_set('display_errors', 1);
if (isset($_GET['loginForm'])){
$usererror = "";
$passerror = "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
<section class="login-page">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                <div class="card-block border-0 shadow p-5">
                    <form class="">
                        <div class="title text-center py-xl-4 py-lg-2 mb-3">
                            <h1 class="h3 text-uppercase font-weight-bold">Log in</h1>
                        </div>
                        <div class="form-field">
                            <input type="text" id="user" class="input" required name="user" value=""
                                   placeholder="Username" autofocus autocomplete="off">
                            <span class="error" style="color:red;">
											<?php if (isset($_SESSION['error']['user'])) {
                                                echo $_SESSION['error']['user'];
                                            } ?>
										</span>
                            <!-- <label for="inputUser" class="label">Username</label> -->
                        </div>
                        <div class="form-field">
                            <input type="password" id="pass" class="input" required name="pass" value=""
                                   placeholder="Password" autocomplete="off">
                            <span class="error" style="color:red;">
											<?php if (isset($_SESSION['error']['pass'])) {
                                                echo $_SESSION['error']['pass'];
                                            } ?>
										</span>
                            <!-- <label for="inputPassword" class="label">Password</label> -->
                        </div>
                        <div class="form-field text-center">
                            <a class="radius-25 btn btn-theme px-5"
                               onClick="setState('loginForm','<?php echo SECURE_PATH; ?>login_process.php','login=1&user='+$('#user').val()+'&pass='+$('#pass').val())">Log
                                In</a>
                            <a class="radius-25 btn btn-danger px-5 text-white"
                               onClick="setState('loginForm','<?php echo SECURE_PATH; ?>login_process.php','signUp=1')">Signup</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript">
    $('#user').focus();
</script>
<?php
unset($_SESSION['error']);
}
?>
<?php
if (isset($_POST['login'])) {
    $_POST = $session->cleanInput($_POST);
    $_SESSION['error'] = array();
    $subuser = $_POST['user'];
    $subpass = $_POST['pass'];


    $q = $session->query("SELECT valid FROM " . TBL_USERS . " WHERE username=:subuser");
    $q->execute(array('subuser' => $subuser));
    $valid = $q->fetch(PDO::FETCH_ASSOC);

    /* Username error checking */
    $field = "user";

    if (!$subuser || strlen($subuser = trim($subuser)) == 0) {
        $_SESSION['error'][$field] = "* Username not entered";
    } else {
        /* Check if username is not alphanumeric */
        $allowed = array("@", ".", "/", "-", "(", ")", "1");
    }

    if ($valid['valid'] == 0) {
        $_SESSION['error'][$field] = "* Access denied";
    }

    /* Password error checking */
    $field = "pass";  //Use field name for password
    if (!$subpass) {
        $_SESSION['error'][$field] = "* Password not entered";
    }

    /* Return if form errors exist */
    if (count($_SESSION['error']) == 0) {
        /* Checks that username is in database and password is correct */
        $subuser = stripslashes($subuser);
        $result = $database->confirmUserPass($subuser, $subpass);

        /* Check error codes */
        if ($result == 1) {
            $field = "user";
            $_SESSION['error'][$field] = "* Username not found";
        } else if ($result == 2) {
            $field = "pass";
            $_SESSION['error'][$field] = "* Invalid password";
        }
    }

    /* Login successful */
    if (count($_SESSION['error']) == 0) {
        /* Username and password correct, register session variables */
        $session->userinfo = $database->getUserInfo($subuser);
        $session->username = $_SESSION['username'] = $session->userinfo['username'];
        $session->userid = $_SESSION['userid'] = $session->generateRandID();
        $session->userlevel = $session->userinfo['userlevel'];
        $session->userFullname = $_SESSION['userFullname'] = $session->userinfo['name'];
        $session->userslno = $_SESSION['userslno'] = $session->userinfo['slno'];

        /* Insert userid into database and update active users table */
        $database->updateUserField($session->username, "userid", $session->userid);
        //$database->addActiveUser($session->username, $session->time);
        $database->removeActiveGuest($_SERVER['REMOTE_ADDR']);

        /**
         * This is the cool part: the user has requested that we remember that
         * he's logged in, so we set two cookies. One to hold his username,
         * and one to hold his random value userid. It expires by the time
         * specified in constants.php. Now, next time he comes to our site, we will
         * log him in automatically, but only if he didn't log out before he left.
         */
        //      if($subremember){
        setcookie("cookname", $session->username, time() + COOKIE_EXPIRE, COOKIE_PATH);
        setcookie("cookid", $session->userid, time() + COOKIE_EXPIRE, COOKIE_PATH);
        //     }

        //$session->activity( $session->username." Logged in.!!",$session->username,1);
        ?>
        <script type="text/javascript">
            window.location = '<?php echo SECURE_PATH;?>home/';
        </script>
    <?php
    }
    /* Login failed */
    else
    {
    ?>
        <script type="text/javascript">
            window.location = '<?php echo SECURE_PATH;?>admin/';
        </script>
        <?php
    }
}
if (isset($_REQUEST['userLogout'])) {

    $session->logout();
    ?>
    <script type="text/javascript">
        window.location = '<?php echo SECURE_PATH;?>';
    </script>
    <?php
}
if (isset($_POST['signUp'])) { ?>
    <section class="login-page">
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                    <div class="card-block border-0 shadow p-5">
                        <form class="">
                            <div class="title text-center py-xl-4 py-lg-2 mb-3">
                                <h1 class="h3 text-uppercase font-weight-bold">Signup</h1>
                            </div>
                            <div class="form-field">
                                <input type="text" id="username" class="input mandatory" required name="Username"
                                       value=""
                                       placeholder="Enter username" autofocus autocomplete="off">
                            </div>
                            <div class="form-field">
                                <input type="password" id="password" class="input mandatory" required name="Password"
                                       value=""
                                       placeholder="Enter Password" autocomplete="off">
                            </div>
                            <div class="form-field">
                                <input type="password" id="cpassword" class="input mandatory" required
                                       name="Confirm Password" value=""
                                       placeholder="Enter Confirm Password" autocomplete="off">
                            </div>
                            <div class="form-field text-center">
                                <a class="radius-25 btn btn-danger px-5 text-white"
                                   onclick="createAccount()">CreateAccount</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
}
if (isset($_POST['createAccount'])) {

    //check whether this user exists
    $check = $database->query("select username from users where username='".$_POST['username']."'");
    if($check->rowCount() == 0) {
        $ins_users = $database->query("insert into users values ('" . $_POST['username'] . "','" . md5($_POST['password']) . "','" . md5(uniqid(rand(), true)) . "',5,'test@test.com','9876543210',0,'" . time() . "',1,'" . $_POST['username'] . "','" . md5(uniqid(rand(), true)) . "','" . time() . "')");
        ?>
        <script>
            alert('User registration succesfull');
            location.reload();
        </script>;
        <?php
    }else{ ?>
        <script>alert("Username already exists");location.reload();</script>
    <?php }
}
?>
<script type="text/javascript">
    $('#loginForm').keyup(function (e) {
        if (e.which == 13) {
            //stuff
            setState('loginForm', '<?php echo SECURE_PATH;?>login_process.php', 'login=1&user=' + $('#user').val() + '&pass=' + $('#pass').val());
        }
    });

    function ValidateFormFieldsNew() {
        var err = 0;
        $('.err_msg').html('');
        $(".mandatory").filter(function () {
            var name = $(this).attr('name');
            if ($(this).prop("type") == "checkbox" || $(this).prop("type") == "radio" || $(this).prop("type") == "select-one" || $(this).prop("type") == "select") {
                if ($(this).val() == '') {
                    err++;
                    $(this).after("<span class='err_msg text-danger'  style='margin-top:5px;font-size: 13px;'>Please Select " + name + "</span>");
                    return $(this).val().trim() == "" || !this.checked;
                }
            } else {
                var minLength = $(this).prop("minlength");
                if (minLength > $(this).val().length) {
                    err++;
                    $(this).after("<span class='err_msg'  style='margin-top:5px;color: #f08f1c;font-size: 13px;'>You can't write less than " + minLength + " chacters</span>");
                }
                if ($(this).prop("type") == "text" || $(this).prop("type") == "textarea" || $(this).prop("type") == "password" || $(this).prop("type") == "date") {
                    if ($(this).val() == '') {
                        err++;
                        $(this).after("<span class='err_msg text-danger'  style='margin-top:5px;font-size: 13px;'>Please Enter " + name + "</span>");
                    }
                } else if ($(this).prop("type") == "email") {
                    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
                    if ($(this).val() == '') {
                        err++;
                        $(this).after("<span class='err_msg text-danger'  style='font-size: 13px;'>Please fill this field</span>");
                    } else if (!emailReg.test($(this).val())) {
                        err++;
                        $(this).after("<span class='err_msg text-danger'  style='margin-top:5px;margin-left: 5px;font-size: 13px;'>Please Enter Valid email</span>");
                    }
                }
                return $(this).prop('id');
                // return this.value.trim() == "";
            }

        }).first().focus();
        if (err > 0) {
            return "1";

        } else {
            return "0";
        }
    }

    function createAccount() {
        if (ValidateFormFieldsNew() == 0) {
            setState('loginForm', '<?php echo SECURE_PATH;?>login_process.php', 'createAccount=1&username=' + $('#username').val() + '&pass=' + $('#password').val() + '&cpassword=' + $('#cpassword').val());
        }
    }
</script>
</body>
</html>