<?php
error_reporting(1);
ini_set('display_errors', 'On');
include('../include/session.php');
if (!$session->logged_in) {
    ?>
    <script type="text/javascript">
        setStateGet('main', '<?php echo SECURE_PATH;?>login_process.php', 'loginForm=1');
    </script>
    <?php
}

//Metircs Forms, Tables and Functions
//Display cadre form
if (isset($_POST['addForm'])) {
    ?>

<?php }
if (isset($_REQUEST['tableDisplay'])) {
    $query = $session->query("select * from task where created_by=:created_by");
    $query->execute(array('created_by' => $session->username));
    ?>
    <?php if ($query->rowCount() > 0) { ?>
        <?php
        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
            $currentTime = time();
            $due_date = strtotime($row['due_date']);

            ?>
            <ul class="list-unstyled">
            <li class="card ticket-list my-3">
                <div class="card-body p-2">
                    <div class="row">
                        <div class="col-lg-2 col-md-12 col-sm-12 py-2">
                            <p class="font-weight-bold">Deadline</p>
                            <p class="badge badge-danger"><?php echo $row['due_date'] ?></p>
                            <?php
                            if ($row['status'] != '5') {
                                echo (($due_date - $currentTime) / 60 / 60 / 24 > 0) ? "<p class='text text-danger'>Due in " . (int)(($due_date - $currentTime) / 60 / 60 / 24) . " Days</p>" : "<p class='text text-danger'>OverDue for " . (int)ltrim(($due_date - $currentTime) / 60 / 60 / 24, '-') . " Days </p>";
                            }
                            ?>
                        </div>
                        <div class="col-lg-4 col-md-12 col-sm-12 py-2">
                            <h5 class="text-primary"><?php echo $row['title'] ?></h5>
                            <div class="d-xl-flex flex-row align-items-center justify-content-between">
                                <p><b>Task Initiation Date: <?php echo $row['assigned_date'] ?></b></p>

                            </div>
                            <div>
                                <label class="badge badge-success font-weight-normal"><?php echo $database->get_name('department', 'id', $row['assignedto'], 'department') ?></label>
                                <?php
                                $row['assignedto'] = explode(',', $row['assignedto']);
                                    for ($i = 0; $i < count($row['assignedto']); $i++) { ?>
                                        <label class="badge badge-primary font-weight-normal text-capitalize"><?php echo $database->get_name('employee', 'id', $row['assignedto'][$i], 'username') ?></label>
                                    <?php
                                    }
                                ?>
                            </div>
                        </div>
                        <div class="col-lg-1 col-md-4 col-sm-12 py-2">
                            <p class="font-weight-bold">Status</p>
                            <p>
                                <?php
                                switch ($row['status']) {
                                    case "1" :
                                        echo "<label class=\"badge badge-warning\">Open</label>";
                                        break;
                                    case "2" :
                                        echo "<label class=\"badge badge-primary\">In Progress</label>";
                                        break;
                                    case "5" :
                                        echo "<label class=\"badge badge-info\">Completed</label>";
                                        break;
                                    case "default" :
                                        echo "default";
                                        break;
                                }
                                ?>
                            </p>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 py-2">
                            <p class="font-weight-bold">Expenditure Incured</p>
                            <p class="text-capitalize"><?php echo empty($row['expenditure']) ? "0" : $row['expenditure'] ?></p>
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-6 py-2">
                            <p class="font-weight-bold">Completed By</p>
                            <p class="text-capitalize"><?php echo empty($row['completed_by']) ? "NA" : $row['completed_by'] ?></p>
                        </div>
                        <div class="col-lg-1 col-md-4 col-sm-6 py-2 text-center">
                            <div class="btn btn-light btn-circle">
                                <i class="material-icons md-18 low-priority">star</i>
                            </div>
                        </div>
                        <script>
                            $('.low-priority').click(function () {
                                $('.low-priority').removeClass('active').addClass('inactive');
                                $(this).removeClass('inactive').addClass('active');
                            });
                        </script>
                    </div>
                </div>
                <!--                    <div class="card-footer py-1">-->
                <!--                        <div class="row">-->
                <!--                            <div class="col-md-10">-->
                <!--                                <ul class="list-inline">-->
                <!--                                    <li class="list-inline-item raisedName">Raised By: <span class="font-weight-bold">Alert Desk</span>-->
                <!--                                    </li>-->
                <!--                                </ul>-->
                <!--                            </div>-->
                <!--                        </div>-->
                <!--                    </div>-->
            </li>
        <?php } ?>
        </ul>
    <?php } else { ?>
        <span class="badge badge-primary">No Results to Display</span>
    <?php } ?>
<?php } ?>
