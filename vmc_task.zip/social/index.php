<?php
include('../include/session.php');

if(!$session->logged_in){
?>
<script type="text/javascript">
setStateGet('main','<?php echo SECURE_PATH;?>login_process.php','loginForm=1');
</script>

<?php
}
else{
	?>
   
    <div class="content" id="adminForm"style="margin:2% 0 0 0;background-color:#fff;padding:10px;">
    	<script>
			setState('adminForm','<?php echo SECURE_PATH; ?>social/process.php','addForm=1')
		</script>
    </div>
    <?php
	}
?>