<?php

include('../include/session.php');

if(!$session->logged_in){

?>
<script type="text/javascript">

setStateGet('main','<?php echo SECURE_PATH;?>login_process.php','loginForm=1');

</script>
<?php

}

?>
    <script>
        jQuery(document).ready(function () {
            // Date Picker
            $('.datepicker, #datepicker2, #datepicker3').datepicker({
                format: "dd-mm-yyyy"
            });
            // Select2
            $(".select2").select2();
        });
    </script>
<?php

if(isset($_REQUEST['addForm']))
{
	if($_REQUEST['addForm'] == 2 && isset($_POST['editform']))
	{
		$data_sel = $database->query("SELECT * FROM add_tickets WHERE id = '".$_POST['editform']."'");
		if(mysqli_num_rows($data_sel) > 0)
		{
			$data = mysqli_fetch_array($data_sel);
			$_POST = array_merge($_POST,$data);
   		}

	}
	
	
	
	?>
    <div class="content">
                <div class="container">
                  <!--  <div class="row">
                        <!-- Page-Title-2 
                        <div class="col-sm-12">
                            <div class="page-header-2">
                                <h4 class="page-title">Message Communication Details </h4>
                                <ol class="breadcrumb">
                                    <li>
                                        <a href="#">Tickets</a>
                                    </li>
                                    <li class="active">
                                            Message Communication Details
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div> -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="alert-details" id="dummy">
                                <div class="bootstrap-table table-responsive  text-center">
                                	<h4 class="font-bold">Hazard Wise Message Communication Details</h4>
                                                      					<?php
                    $data_sel=$database->query("SELECT * FROM tickets WHERE status NOT IN (3,4) AND del_flag=1 ORDER BY timestamp ASC");
                    if(mysqli_num_rows($data_sel)>0)
					{
						$sno=1;
                    ?>
                                    <table class="table-bordered table-condensed">
           
                                        <thead class="bg-theme">
                                            <tr>
                                                <th class="text-center" rowspan="2" colspan="1">S.No</th>
                                                <th class="text-center" rowspan="2" colspan="1">Alert Id</th>
                                                <th class="text-center" rowspan="2" colspan="1">Date &amp; Time</th>

                                                <th class="text-center" rowspan="1" colspan="5">WhatsApp</th>
                                                <th class="text-center" rowspan="1">Telegram</th>
                                                <th class="text-center" rowspan="2" colspan="1">Message Format</th>
                                                <th class="text-center" rowspan="2" colspan="1">Comments</th>
                                                <th class="text-center" rowspan="2" colspan="1">Close Tickets</th>
                                            </tr>
                                            <tr>
                                                <th class="text-center">&nbsp;DRO&nbsp;</th>
                                                <th class="text-center">D Section </th>
                                                <th class="text-center">&nbsp;RDO&nbsp;</th>
                                                <th class="text-center">&nbsp;Alerts&nbsp;</th>
                                                <th class="text-center">&nbsp;MRO&nbsp;</th>
                                                <th class="text-center">MRO</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php while($row=mysqli_fetch_assoc($data_sel)) { ?>
                                            <tr>
                                                <td><?php echo $sno; ?></td>
                                                <td><?php echo $row['ticket_id']; ?></td>
                                                <td><?php echo $row['date']."<br>".$row['time']; ?></td>
                                                <td>
                                                    <div class="checkbox checkbox-primary m-r-15">
                                                        <input id="drowp_<?php echo $row['id']; ?>" type="checkbox" 
                                                        onchange="if($(this).is(':checked')){ $('#drowps_<?php echo $row['id']; ?>').val('1'); } else { $('#drowps_<?php echo $row['id']; ?>').val('0'); }">
                                                        <label for="checkbox1">Yes</label>
                                                    </div>
                                                    <input id="drowps_<?php echo $row['id']; ?>" type="hidden" value="0">
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-primary m-r-15">
                                                        <input id="dswp_<?php echo $row['id']; ?>" type="checkbox" onchange="if($(this).is(':checked')){ $('#dswp_<?php echo $row['id']; ?>').val('1'); } else { $('#dswp_<?php echo $row['id']; ?>').val('0'); }">
                                                        <label for="checkbox2">Yes</label>
                                                    </div>
                                                    <input id="dswps_<?php echo $row['id']; ?>" type="hidden" value="0">
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-primary m-r-15">
                                                        <input id="rdowp" type="checkbox" onchange="if($(this).is(':checked')){ $('#rdowps_<?php echo $row['id']; ?>').val('1'); } else { $('#rdowps_<?php echo $row['id']; ?>').val('0'); }">
                                                        <label for="checkbox3">Yes</label>
                                                    </div>
                                                    <input id="rdowps_<?php echo $row['id']; ?>" type="hidden" value="0">
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-primary m-r-15">
                                                        <input id="alwp" type="checkbox" onchange="if($(this).is(':checked')){ $('#alwps_<?php echo $row['id']; ?>').val('1'); } else { $('#alwps_<?php echo $row['id']; ?>').val('0'); }">
                                                        <label for="checkbox4">Yes</label>
                                                    </div>
                                                    <input id="alwps_<?php echo $row['id']; ?>" type="hidden" value="0">
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-primary m-r-15">
                                                        <input id="mrowp" type="checkbox" onchange="if($(this).is(':checked')){ $('#mrowps_<?php echo $row['id']; ?>').val('1'); } else { $('#mrowps_<?php echo $row['id']; ?>').val('0'); }">
                                                        <label for="checkbox5">Yes</label>
                                                    </div>
                                                    <input id="mrowps_<?php echo $row['id']; ?>" type="hidden" value="0">
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-primary m-r-15">
                                                        <input id="mrotg" type="checkbox" onchange="if($(this).is(':checked')){ $('#mrotgs_<?php echo $row['id']; ?>').val('1'); } else { $('#mrotgs_<?php echo $row['id']; ?>').val('0'); }">
                                                        <label for="checkbox6"> No </label>
                                                    </div>
                                                    <input id="mrotgs_<?php echo $row['id']; ?>" type="hidden" value="0">
                                                </td>
                                                <td style="text-align:left !important;">
                                                
                                                    <p>Date: <span class="text-primary">*21-05-2019*</span>
                                                        Time: <span class="text-primary">*09:42:10*</span></p><br />
                                                    <p><span class="text-primary">*SEOC-APSDMA*</span></p>
                                                    <p>Dear sir/madam,</p>
                                                    <p>Ther is a possibility of <span class="text-primary">
                                                    *<?php echo $database->get_name("global_hazards","id",$row['hazard'],"hazard"); ?>*</span> in<br />
                                                        <span class="text-primary">District: *<?php echo $database->get_name("global_districts","uid",$row['district'],"district"); ?>*</span><br />
                                                        <span class="text-primary">Mandal: *<?php echo $database->get_name("global_mandals","uid",$row['mandal'],"mandal"); ?>*</span><br />
                                                        <span class="text-primary">Village: *<?php echo $row['villages']; ?>*</span><br />
                                                    </p>
                                                    <p>In Another <span class="text-primary">*30-40*</span> minutes</p>
                                                    <p>Please notify all concern and take necessary action</p>
                                                    <p>
                                                        <span class="text-primary">*VRO's are requested to be on
                                                            alert.*</span>
                                                    </p>
                                                    <p>
                                                        <span class="text-primary">*Regards*</span>
                                                    </p>
                                                    <p>
                                                        <span class="text-primary">*SEOC*</span>
                                                    </p>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <textarea class="form-control" name="" id="comments_<?php echo $row['id']; ?>" cols="6" rows="8"></textarea>
                                                    </div>
                                                </td>
                                                <td>
                                                     <button class="btn btn-sm btn-primary" 
                                                    onclick="setState('dummy','<?php echo SECURE_PATH; ?>social/process.php','validateForm=1&ticket_id=<?php echo $row['id']; ?>&tick_id=<?php echo $row['ticket_id']; ?>&drowps='+$('#drowps_<?php echo $row['id']; ?>').val()+'&dswps='+$('#dswps_<?php echo $row['id']; ?>').val()+'&rdowps='+$('#rdowps_<?php echo $row['id']; ?>').val()+'&alwps='+$('#alwps_<?php echo $row['id']; ?>').val()+'&mrowps='+$('#mrowps_<?php echo $row['id']; ?>').val()+'&mrotgs='+$('#mrotgs_<?php echo $row['id']; ?>').val()+'&comments='+$('#comments_<?php echo $row['id']; ?>').val())">close</button>
                                                </td>
                                            </tr>
                                                                         <?php $sno++; } ?>
                                        </tbody>
                                    </table>
									<?php
                                    }
                                    else
                                    {
										?>
										<div class="text-center alert alert-danger">No Results Found</div>
										<?php
                                    }
                                    ?>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            </div>
										  					
	 <?php
     
	 unset($_SESSION['error']);

}


if(isset($_POST['validateForm'])){

	

	$_SESSION['error'] = array();

	

	$post = $session->cleanInput($_POST);


	$id=NULL;
	if(isset($post['editform'])){ $id = $post['editform'];}

	$flag=0;
	
	$field = 'drowps';
	if(!isset($post[$field]) || strlen($post[$field]) == 0 || $post[$field] == 0)
	{
		$flag++;
	}
	
	$field = 'dswps';
	if(!isset($post[$field]) || strlen($post[$field]) == 0 || $post[$field] == 0)
	{
		$flag++;
	}
	
	$field = 'rdowps';
	if(!isset($post[$field]) || strlen($post[$field]) == 0 || $post[$field] == 0)
	{
		$flag++;
	}
	
	$field = 'alwps';
	if(!isset($post[$field]) || strlen($post[$field]) == 0 || $post[$field] == 0)
	{
		$flag++;
	}
	
	$field = 'mrowps';
	if(!isset($post[$field]) || strlen($post[$field]) == 0 || $post[$field] == 0)
	{
		$flag++;
	}
	
	$field = 'mrotgs';
	if(!isset($post[$field]) || strlen($post[$field]) == 0 || $post[$field] == 0)
	{
		$flag++;
	}	
	
		


//Check if any errors exist	

		if($flag==6){
?>

 
	<script type="text/javascript">
   		alert('Please select any of six at ticket number <?php echo $_REQUEST["tick_id"]; ?>');
    </script>
	
	
	
	

<?php	

	}

	else{

$ins=$database->query("INSERT INTO tickets_social VALUES (NULL,'".$post['ticket_id']."','".$post['drowps']."','".$post['dswps']."','".$post['rdowps']."','".$post['alwps']."','".$post['mrowps']."','".$post['mrotgs']."','".$post['comments']."','".time()."') ON DUPLICATE KEY UPDATE drowps='".$post['drowps']."',dswps='".$post['dswps']."',rdowps='".$post['rdowps']."',alwps='".$post['alwps']."',mrowps='".$post['mrowps']."',mrotgs='".$post['mrotgs']."',comments='".$post['comments']."',timestamp='".time()."'");

$telecom_check=$database->query("SELECT id FROM tickets_telecom WHERE ticket_id='".$post['ticket_id']."'");
if(mysqli_num_rows($telecom_check)>0)
{
	$update=$database->query("UPDATE tickets SET status=4 WHERE id='".$post['ticket_id']."'");
}
else
{
	$update=$database->query("UPDATE tickets SET status=3 WHERE id='".$post['ticket_id']."'");
}

		
		if(!$ins || !$update) { echo mysqli_error($database->connection); }

		
		else
		{
			?>	
			<div class="alert alert-success " id="sucmsg"><i class="fa fa-thumbs-up fa-2x"></i>Information saved successfully!</div>
			<script type="text/javascript">
				setTimeout(function(){ 
						$('#sucmsg').hide(); setState('adminForm','<?php echo SECURE_PATH; ?>social/process.php','addForm=1'); 
					},3000);
			</script>
			<?php
		}
	}
}

//Delete events 
					?>	
