<?php
include('../include/session.php');


if(!$session->logged_in){
?>
<script type="text/javascript">
setStateGet('main','login_process.php','loginForm=1');
</script>

<?php
}


//Customer Home Screen
if(isset($_REQUEST['getDashboard'])){

//Overview counts


		$panchayat_con = "";
		$panchayat_con1 = "";
if ($session->userlevel <= 6){
	 $user = $session->userinfo;
   
    
  $_REQUEST['district'] = $user['district'];
  $_REQUEST['division'] = $user['division'];
  $_REQUEST['mandal'] = $user['mandal'];
   $_REQUEST['panchayat'] = $user['panchayat'];
   
   $_REQUEST['state_code']= $database->get_name('global_districts','uid',$user['district'],'state_code');
   
   			$district_con = "";
	if(isset($_REQUEST['district'])){
	   $district_con = "district = '".$_REQUEST['district']."'";
	}
	
		$state_con = "";
	if(isset($_REQUEST['state_code'])){
	   $state_con = " AND state_code = '".$_REQUEST['state_code']."'";
	}
	$division_con = "";
	if(isset($_REQUEST['division'])){
	   $division_con = " AND division = '".$_REQUEST['division']."'";
	}
	
	
	$mandal_con = "";
	if(isset($_REQUEST['mandal'])){
	   $mandal_con = " AND mandal = '".$_REQUEST['mandal']."'";
	}
	
	
		
	$pan_con = '';	
	$p_con = "";
	if(isset($_REQUEST['panchayat'])){
	   $p_con = " AND panchayat_id = '".$_REQUEST['panchayat']."'";
	   $pan_con = " AND panchayat = '".$_REQUEST['panchayat']."'";

	}
   
   	$con_sel = $database->query("SELECT * FROM global_panchayats WHERE ".$district_con." ".$division_con.$mandal_con.$state_con.$p_con);
	 $panchayat_con = $district_con." ".$division_con.$mandal_con.$state_con.$p_con;

	 $panchayat_con1 = $district_con." ".$division_con.$mandal_con.$state_con.$pan_con;

		
			$p = '';
		    $p_array = array();
		if(mysqli_num_rows($con_sel) > 0){
		   while($panchayat = mysqli_fetch_array($con_sel)){
			       $p.= "'".$panchayat['panchayat_id']."',";
		       $p_array[]  = $panchayat['panchayat_id'];
		   }
		   
		   
		}
		
			 
		if(count($p_array) > 0){
		//     $panchayat_con = " AND  house_tax.panchayat IN(".trim($p,',').")";	
		}
  
   }
			 	
				
				$info_txt = "Last 24 hrs";
	$doe_con = 	" doe >= '".strtotime('today')."'";	
	
	if(isset($_REQUEST['duration'])){
	   if($_REQUEST['duration'] == 1){
		    
	      $doe_con = 	" doe >= '".strtotime('today')."'";	
	   }
	   else if($_REQUEST['duration'] == 7){
		    	
				$info_txt = "Last 7 days";
	      $doe_con = 	" doe >= '".(strtotime('today')-(7*60*60*24))."'";	
	   }
	   else if($_REQUEST['duration'] == 30){
		    	
				$info_txt = "Last 30 days";
	      $doe_con = 	" doe >= '".(strtotime('today')-(30*60*60*24))."'";	
	   }
	   else if($_REQUEST['duration'] == 90){
		    	
				$info_txt = "Last 3 months";
	      $doe_con = 	" doe >= '".(strtotime('today')-(90*60*60*24))."'";	
	   }
	     else if($_REQUEST['duration'] == 180){
		    	
				$info_txt = "Last 6 months";
	      $doe_con = 	" doe >= '".(strtotime('today')-(180*60*60*24))."'";	
	   }
	   else if($_REQUEST['duration'] == 365){
		    	
				$info_txt = "Last 1 year";
	      $doe_con = 	" doe >= '".(strtotime('today')-(365*60*60*24))."'";	
	   }
		else if($_REQUEST['duration'] == 'all'){
		    		
				$info_txt = "All records till date";
 	      $doe_con = 	" doe >= 0";	
	   }
		
		
		
	}
				
				
				if(strlen($panchayat_con) > 0){
					
				      $panchayat_con = " AND ".$panchayat_con;	
				}
			

$h_sel = $database->query("SELECT count(hid) as ht, SUM(private_taps) as pt FROM house_tax, global_panchayats WHERE ".$doe_con." AND house_tax.panchayat = global_panchayats.panchayat_id AND house_tax.del_flag = 1 ".$panchayat_con);

$hdata = mysqli_fetch_array($h_sel);

$c_sel = $database->query("SELECT SUM(two_wheeler) as soak, SUM(four_wheeler) as tree FROM house_tax, global_panchayats, citizens WHERE house_tax.citizen_id = citizens.citizen_id AND house_tax.panchayat = global_panchayats.panchayat_id AND house_tax.del_flag = 1  ".$panchayat_con);
$cdata = mysqli_fetch_array($c_sel);
/*//echo "SELECT hid FROM house_tax WHERE ".$doe_con." ".$panchayat_con;

$w_sel = $database->query("SELECT hid FROM house_tax WHERE ".$doe_con." AND house_tax.panchayat = global_panchayats.panchayat_id AND house_tax.del_flag = 1 AND private_taps > 0 ".$panchayat_con);*/
?>
<div class="row state-overview">

<div class="pull-right">
<a onclick="setState('dashboard','<?php echo SECURE_PATH;?>home/process.php','getDashboard=true&duration=1')">1d</a> | 
<a onclick="setState('dashboard','<?php echo SECURE_PATH;?>home/process.php','getDashboard=true&duration=7')">1w</a> | 
<a onclick="setState('dashboard','<?php echo SECURE_PATH;?>home/process.php','getDashboard=true&duration=30')">1m</a> | 
<a onclick="setState('dashboard','<?php echo SECURE_PATH;?>home/process.php','getDashboard=true&duration=90')">3m</a> | 
<a onclick="setState('dashboard','<?php echo SECURE_PATH;?>home/process.php','getDashboard=true&duration=180')">6m</a> | 
<a onclick="setState('dashboard','<?php echo SECURE_PATH;?>home/process.php','getDashboard=true&duration=365')">1yr</a> | 
<a onclick="setState('dashboard','<?php echo SECURE_PATH;?>home/process.php','getDashboard=true&duration=all')">All</a> 
</div>
<br />
<div style="clear:both"></div>
    <!-- 
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol red">
                              <i class="fa fa-home"></i>
                          </div>
                          <div class="value">
                              <h1 class="count">
                                  <script type="text/javascript">
								     
									 countUp(<?php echo mysqli_num_rows($h_sel);?>,'.count',100,8);
								    
								  </script>
                              </h1>
                              <p>House Tax Enrollments</p>
                          </div>
                      </section>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol terques">
                              <i class="fa fa-tint"></i>
                          </div>
                          <div class="value">
                              <h1 class=" count2">
                                  <script type="text/javascript">
								     
									 countUp(<?php echo mysqli_num_rows($w_sel);?>,'.count2',50,10);
								    
								  </script>
                              </h1>
                              <p>Private Tap Enrollments</p>
                          </div>
                      </section>
                  </div>
                  
                
           
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                        <div class="col-xs-6">
                         House Tax Demand
                        </div>
                       
                        
                        <div class="col-xs-6">
                        0
                        </div>  <div style="clear:both"></div>
                      
                         <div class="col-xs-6">
                        Private Tap Fee Demand
                        </div>
                        <div class="col-xs-6">
                        0
                        </div>
              
                                 </section>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                           <div class="col-xs-6">
                         House Tax Collection
                        </div>
                       
                        
                        <div class="col-xs-6">
                        0
                        </div> 
                         <div style="clear:both"></div>
                       
                        
                        <div class="col-xs-6">
                        Private Tap Fee Collection
                        </div>
                        <div class="col-xs-6">
                        0
                        </div>
                        
                     
                      </section>
                  </div>
              -->
              
                  
                  
              </div>
<div class="row">
                            <div class="col-lg-3 col-sm-6">
                                <div class="widget-panel widget-style-2 bg-white">
                                    <i class="md md-home text-pink"></i>
                                    <h2 class="m-0 text-dark counter font-600"><?php echo $hdata['ht'];?></h2>
                                    <div class="text-muted m-t-5">Assessments</div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6">
                                <div class="widget-panel widget-style-2 bg-white">
                                    <i class="fa fa-tint text-info"></i>
                                    <h2 class="m-0 text-dark counter font-600"><?php
									if(strlen($hdata['pt']) == 0)
									   $hdata['pt'] = 0;
									 echo $hdata['pt'];?></h2>
                                    <div class="text-muted m-t-5">Private Taps</div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6">
                                <div class="widget-panel widget-style-2 bg-white">
                                    <i class="md md-adjust text-info"></i>
                                    <h2 class="m-0 text-dark counter font-600"><?php echo $cdata['soak'];?></h2>
                                    <div class="text-muted m-t-5">Soak pits</div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6">
                                <div class="widget-panel widget-style-2 bg-white">
                                    <i class="md md-nature-people text-custom"></i>
                                    <h2 class="m-0 text-dark counter font-600"><?php echo $cdata['tree'];?></h2>
                                    <div class="text-muted m-t-5">Trees</div>
                                </div>
                            </div>
                        </div>
                        
                        
                        
                       <?php
					   
				$due_year = date('Y').'-'.substr(date('Y')+1,2);
	
	 	
	if(time()  <  strtotime('01-'.VALID_MONTH.'-'.date('Y')))
     	$due_year = (date('Y')-1).'-'.substr(date('Y'),2);
		
		
		$captime = strtotime('01-'.VALID_MONTH.'-'.(date('Y')+1));
			   
 				      $demand_sel = $database->query("SELECT ROUND(SUM(demand)) as ht FROM dcb_stats WHERE due_year = '".$due_year."' ".$panchayat_con1."  GROUP BY taxtype ORDER BY taxtype ASC");
					  
					    
					   $collection_sel = $database->query("SELECT ROUND(SUM(collection)) as ht FROM dcb_stats WHERE  due_year = '".$due_year."'   ".$panchayat_con1."  GROUP BY taxtype  ORDER BY taxtype ASC");
					   
					   $demand = mysqli_fetch_array($demand_sel);
					   $kdemand = mysqli_fetch_array($demand_sel);
					   $ademand = mysqli_fetch_array($demand_sel);
					   $tdemand = mysqli_fetch_array($demand_sel);
					   $audemand = mysqli_fetch_array($demand_sel);
 					   $demandw = mysqli_fetch_array($demand_sel);
					   
					   $collection = mysqli_fetch_array($collection_sel);
                       $kcollection = mysqli_fetch_array($collection_sel);
                       $acollection = mysqli_fetch_array($collection_sel);
                       $tcollection = mysqli_fetch_array($collection_sel);
                       $aucollection = mysqli_fetch_array($collection_sel);

					   $collectionw = mysqli_fetch_array($collection_sel);
					   
					 
					 
					 //Kolagaaram Tax  
					  
					   
					   
					   
					    //Advertisement Tax  
					  
					   
					 
					   ?> 
                        
                        
                        
                        
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-lg-3">
                                <div class="card-box widget-box-1 bg-white">
                                	<i class="fa fa-info-circle text-muted pull-right inform" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="<?php echo 'For Year:'.$due_year;?>"></i>
                                	<h4 class="text-dark">House Tax</h4>
                                	<h2 class="text-primary text-center"><i class="fa fa-rupee"></i> <span data-plugin="counterup"><?php echo $collection['ht'];?></span></h2>
                                	<p class="text-muted">Total Demand: <i class="fa fa-rupee"></i> <?php echo $demand['ht'];?> <span class="pull-right"><?php echo round($collection['ht']/$demand['ht'], 2)*100;?>%</span></p>
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-lg-3">
                                <div class="card-box widget-box-1 bg-white">
                                	<i class="fa fa-info-circle text-muted pull-right inform" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="<?php echo 'For Year:'.$due_year;?>"></i>
                                	<h4 class="text-dark">Private Tap Fee</h4>
                                	<h2 class="text-pink text-center"><i class="fa fa-rupee"></i> <span data-plugin="counterup"><?php echo $collectionw['ht'];?></span></h2>
                                	<p class="text-muted">Total Fee: <i class="fa fa-rupee"></i> <?php echo $demandw['ht'];?> <span class="pull-right"><?php echo round($collectionw['ht']/($demandw['ht']+1), 2)*100;?>%</span></p>
                                </div>
                            </div>

                          
                             

                          
                            <div class="col-md-6 col-sm-6 col-lg-3">
                                <div class="card-box widget-box-1 bg-white">
                                	<i class="fa fa-info-circle text-muted pull-right inform" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="<?php echo 'For Year:'.$due_year;?>"></i>
                                	<h4 class="text-dark">Kolagaaram Tax</h4>
                                	<h2 class="text-pink text-center"><i class="fa fa-rupee"></i> <span data-plugin="counterup"><?php echo $kcollection['ht'];?></span></h2>
                                	<p class="text-muted">Total Demand: <i class="fa fa-rupee"></i> <?php echo $kdemand['ht'];?> <span class="pull-right"><?php echo round($kcollection['ht']/(1+$kdemand['ht']), 2)*100;?>%</span></p>
                                </div>
                            </div>

                          
<div class="col-md-6 col-sm-6 col-lg-3">
                                <div class="card-box widget-box-1 bg-white">
                                	<i class="fa fa-info-circle text-muted pull-right inform" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="<?php echo 'For Year:'.$due_year;?>"></i>
                                	<h4 class="text-dark">Advertisement Tax</h4>
                                	<h2 class="text-pink text-center"><i class="fa fa-rupee"></i> <span data-plugin="counterup"><?php echo $acollection['ht'];?></span></h2>
                                	<p class="text-muted">Total Demand: <i class="fa fa-rupee"></i> <?php echo $ademand['ht'];?> <span class="pull-right"><?php echo round($acollection['ht']/(1+$ademand['ht']), 2)*100;?>%</span></p>
                                </div>
                            </div>
                        </div>
<?php
//Overview end

}
if(isset($_REQUEST['getDashboard1'])){ 

echo 'Welcome '.$session->username;
}

if(isset($_REQUEST['sideNavigation'])){

?>	  
<?php
}


if(isset($_REQUEST['tableTop'])){
	?>
 
    <?php
}

if(isset($_REQUEST['rightSideBar'])){
	?>
 <h5 class="side-title">Quick Reports</h5>
          
          <h5 class="side-title"> pending Task</h5>
          <ul class="p-task tasks-bar">
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Dashboard v1.3</div>
                          <div class="percent">40%</div>
                      </div>
                      <div class="progress progress-striped">
                          <div style="width: 40%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-success">
                              <span class="sr-only">40% Complete (success)</span>
                          </div>
                      </div>
                  </a>
              </li>
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Database Update</div>
                          <div class="percent">60%</div>
                      </div>
                      <div class="progress progress-striped">
                          <div style="width: 60%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="60" role="progressbar" class="progress-bar progress-bar-warning">
                              <span class="sr-only">60% Complete (warning)</span>
                          </div>
                      </div>
                  </a>
              </li>
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Iphone Development</div>
                          <div class="percent">87%</div>
                      </div>
                      <div class="progress progress-striped">
                          <div style="width: 87%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="20" role="progressbar" class="progress-bar progress-bar-info">
                              <span class="sr-only">87% Complete</span>
                          </div>
                      </div>
                  </a>
              </li>
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Mobile App</div>
                          <div class="percent">33%</div>
                      </div>
                      <div class="progress progress-striped">
                          <div style="width: 33%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="80" role="progressbar" class="progress-bar progress-bar-danger">
                              <span class="sr-only">33% Complete (danger)</span>
                          </div>
                      </div>
                  </a>
              </li>
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Dashboard v1.3</div>
                          <div class="percent">45%</div>
                      </div>
                      <div class="progress progress-striped active">
                          <div style="width: 45%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="45" role="progressbar" class="progress-bar">
                              <span class="sr-only">45% Complete</span>
                          </div>
                      </div>

                  </a>
              </li>
              <li class="external">
                  <a href="#">See All Tasks</a>
              </li>
          </ul>    
    <?php
}
?>

