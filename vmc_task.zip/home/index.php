<?php
include('../include/session.php');
if (!$session->logged_in) {

    ?>

    <script type="text/javascript">
        window.location = '<?php echo SECURE_PATH;?>';
    </script>
    <?php
} else {
    ?>
    <!DOCTYPE html>
    <html>

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="Swamy">
        <meta name="theme-color" content="#0c8bf1"/>
        <meta name="keywords" content="">

        <link rel="icon" href="<?php echo SECURE_PATH ?>vendor/images/vmc_logo.png" type="image/gif" sizes="16x16">

        <?php echo $session->vmc_title(); ?>

        <?php $session->commonAdminCSS();

        $session->commonJS();
        $session->commonFooterAdminJS();
        ?>
        <style>
            .modal-backdrop {
                position: unset !important;
            }

            .error {
                color: red !important;
            }

            .side-menu li a:hover {
                cursor: pointer;
            }
        </style>

    </head>


    <body id="page-top">


    <div class="loading" id="formLoader" style="display: none">
        <img src="../vendor/images/loader.gif">
    </div>

    <nav id="sidebar">
        <div class="sidebar-header">
            <a href="../home/">
                <!--                <h1 class="m-0"><img src="--><?php //echo SECURE_PATH
                ?><!--vendor/images/logo1.png" height="50" width="50"> VMC-->
                <!--                </h1>-->
                <h1 class="m-0"><img class="mr-1" width="30%" src="<?php echo SECURE_PATH ?>vendor/images/vmc_logo.png">VMC
                </h1>
            </a>
        </div>
        <ul class="side-menu accordion" id="accordionSidebar">
            <?php
            if ($session->userlevel == 3) {
                ?>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>department/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-success">book</i>
                        <span> My Tasks</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>viewProjects/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-primary">assignment</i>
                        <span> My Projects</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <?php
            }
            if ($session->userlevel == 4) {
                ?>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>department/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-success">assignment</i>
                        <span>View Tasks</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>viewProjects/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-primary">assignment</i>
                        <span> My Projects</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <?php
            }
            if ($session->userlevel == 5) {
                ?>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>addLocation/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-primary">near_me</i>
                        <span>Add Location</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>addDepartment/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-warning">house</i>
                        <span>Add Department</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>addDesignation/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-info">event_seat</i>
                        <span>Add Designation</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>addCircle/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-success">room</i>
                        <span>Add Circle</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>addWard/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-info">commute</i>
                        <span>Add Ward</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <?php
            } else if ($session->userlevel == 9) {
                ?>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>addLocation/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-primary">near_me</i>
                        <span>Add Location</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>addDepartment/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-warning">house</i>
                        <span>Add Department</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>addDesignation/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-info">event_seat</i>
                        <span>Add Designation</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>addCircle/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-success">room</i>
                        <span>Add Circle</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>addWard/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-info">commute</i>
                        <span>Add Ward</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>employeeMaster/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-danger">account_circle</i>
                        <span>Employee Master</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>createProject/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-primary">assignment_turned_in</i>
                        <span>Create Project</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>createTask/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-warning">book</i>
                        <span>Create Task</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <li class="nav-item">
                    <a onClick="setState('content-page','<?php echo SECURE_PATH; ?>viewTasks/','getLayout=true')"
                       class="nav-link">
                        <i class="material-icons icon text-success">assignment</i>
                        <span>View Tasks</span>
                        <!-- <span class="menu-arrow"></span> -->
                    </a>
                </li>
                <?php
            }

            ?>

        </ul>
    </nav>

    <div class="menu-overlay"></div>

    <main class="main-wrapper">
        <header class="header-area">
            <nav class="navbar navbar-expand navbar-light bg-admin">
                <div class="container">
                    <button class="btn btn-light btn-circle text-theme order-1 order-sm-0" id="sidebarCollapse">
                        <i class="material-icons text-theme md-18">menu</i>
                    </button>
                    <!-- Navbar Search -->
                    <div class="col-md-9 text-center">
                        <!--                        <span class="banner">Andhra Pradesh Pollution Control Board</span>-->
                        <h4>
                            <img class="mr-1" width="5%" src="<?php echo SECURE_PATH ?>vendor/images/vmc_logo.png"/>Vijayawada
                            Municipal Corporation
                        </h4>
                    </div>

                    <!-- Navbar -->
                    <ul class="navbar-nav ml-auto ml-md-0">


                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle pt-1" href="#" id="userDropdown" role="button"
                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="<?php echo SECURE_PATH; ?>vendor/images/user-profile.png" width="35"
                                     alt="profile-user" class="rounded-circle">
                                <div class="d-none d-xl-inline-block text-capitalize"><?php echo "Welcome <b>" . $session->userinfo['username'] . "</b>"; ?></div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right logout" aria-labelledby="userDropdown">
                                <a class="dropdown-item"
                                   onclick="setState('content-page','<?php echo SECURE_PATH; ?>settings/','getLayout=true')"><i
                                            class="material-icons">settings</i> Settings</a>
                                <a class="dropdown-item" href="#"><i class="material-icons">style</i> Activity Log</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item"
                                   onClick="setState('content-page','<?php echo SECURE_PATH; ?>login_process.php','userLogout=true')"><i
                                            class="material-icons">exit_to_app</i>
                                    Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class="content-wrapper" id="content-page">


            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="material-icons">navigation</i>
            </a>
        </div>
        <footer class="footer border-top py-3 text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="copy-rights">
                            <span class="text-dark">&copy; 2019 <a href="#" target="_blank">Admin</a> All rights
                                reserved.</span>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </main>


    <script src="<?php echo SECURE_PATH; ?>vendor/bootstrap-datetimepicker/js/moment.min.js"></script>
    <script src="<?php echo SECURE_PATH; ?>vendor/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>

    <script>
        $(document).ready(function () {
            //setState('content-page','<?php echo SECURE_PATH; ?>team_selection','getLayout=true');
            <?php if($session->userlevel == 9)
            {
            ?>
            setState('content-page', '<?php echo SECURE_PATH; ?>createProject', 'getLayout=true');
            <?php
            }
            else if($session->userlevel == 4)
            {
            ?>
            setState('content-page', '<?php echo SECURE_PATH; ?>viewTasks', 'getLayout=true');
            <?php
            }
            else if($session->userlevel == 5)
            {
            ?>
            setState('content-page', '<?php echo SECURE_PATH; ?>addDepartment', 'getLayout=true');
            <?php
            }
            else if($session->userlevel == 3)
            {
            ?>
            setState('content-page', '<?php echo SECURE_PATH; ?>department', 'getLayout=true');
            <?php
            }

            ?>
        });
    </script>
    </body>

    </html>

<?php }
?>