<?php
error_reporting(1);
ini_set('display_errors','On');
include('../include/session.php');
if(!$session->logged_in){
    ?>
    <script type="text/javascript">
        setStateGet('main','<?php echo SECURE_PATH;?>login_process.php','loginForm=1');
    </script>
    <?php
}

//Metircs Forms, Tables and Functions
//Display cadre form
if(isset($_POST['addForm'])) { ?>
    <?php if($_POST['addForm'] == 2 && isset($_POST['editform'])){ ?>
        <script>
            $('#addForm').slideDown();
        </script>
        <?php $data_sel = $database->connection->prepare("SELECT * FROM location WHERE id =:id");
        $data_sel->execute(array('id'=>$_POST['editform']));
        $data = $data_sel->fetch(PDO::FETCH_ASSOC);
        $flag=1;
        $_POST = array_merge($data,$_POST);
    }
    ?>
<section class="content-area">
    <div class="row">
        <div class="col-xl-12 col-lg-12">
            <div class="card border-0 shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Add New Location</h6>
                    <span class="float-right">
                                <a role="button" onclick="setState('addForm','<?php echo SECURE_PATH ?>addLocation/process.php','addForm=1 ')"><i class="fa fa-refresh text-primary text-lg-right"></i> Refresh</a>
                            </span>
                </div>
                <div class="card-body">
                    <form id="taskForm">
                        <div class="form-group ">
                            <div class="form-group row">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group row">
                                                <label class="col-sm-4 col-form-label">Location Name<span style="color:red;">*</span></label>
                                                <div class="col-sm-8">
                                                    <input id="location" class="form-control" autocomplete="off" placeholder="Enter Location" value="<?php if(isset($_POST['location'])){echo $_POST['location'];}?>" />
                                                    <span class="text-danger"><?php if(isset($_SESSION['error']['location'])){echo $_SESSION['error']['location'];}?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-8">
                                                    <?php
                                                        if(isset($_POST['editform']))
                                                        { ?>
                                                            <input class="btn btn-primary btn-block" type="button" value="Update" onclick="setState('result','<?php echo SECURE_PATH ?>addLocation/process.php','validateForm=1&location='+$('#location').val()+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform'] ;}?>' )" />
                                                        <?php }
                                                        else {
                                                    ?>
                                                    <input class="btn btn-primary btn-block" type="button" value="Add" onclick="setState('result','<?php echo SECURE_PATH ?>addLocation/process.php','validateForm=1&location='+$('#location').val())" />
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-lg-6">

                                        </div>
                                        <div class="col-lg-6" id="result">

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</section>
<?php }
if(isset($_REQUEST['validateForm']))
{
    $_SESSION['error'] = array();
    $field = 'location';
    if(!$_POST['location'] || strlen(trim($_POST['location'])) == 0) {
        $_SESSION['error'][$field] = "* Please Enter Location";
    }
        if(count($_SESSION['error']) > 0)
        {
            ?>
            <script type="text/javascript">
                setState('addForm','<?php echo SECURE_PATH ?>addLocation/process.php','addForm=1&location=<?php $_POST['location']?>' )
            </script>
            <?php
        }
        else
        {
            unset($_SESSION['error']);
            if(isset($_POST['editform']))
            {
                $up = $database->connection->prepare("UPDATE location SET location='" . $_POST['location'] . "' WHERE id=:id");
                $up->execute(array('id'=>$_POST['editform']));
                if($up)
                {
                    ?>
                    <span class="alert alert-warning">Location Details Updated</span>
                    <script>
                        setTimeout(function() {
                            setState('addForm', '<?php echo SECURE_PATH; ?>addLocation/process.php','addForm=1');
                            setState('tableDisplay', '<?php echo SECURE_PATH; ?>addLocation/process.php','tableDisplay=1');
                        },3000)
                    </script>
                    <?php
                }
                else
                {
                    ?>
                    <div class="alert alert-danger"><?php echo $database->connection->errorInfo(); ?></div>
                    <script>
                        setTimeout(function() {
                            setState('addForm', '<?php echo SECURE_PATH; ?>addLocation/process.php','addForm=1');
                            setState('tableDisplay', '<?php echo SECURE_PATH; ?>addLocation/process.php','tableDisplay=1');
                        },3000)
                    </script>
                    <?php
                }
            }
            else
            {
                $insert = $database->connection->prepare("INSERT INTO location values (:nu,:location)");
                $insert->execute(array('nu'=>NULL,'location'=>$_POST['location']));
                if($insert)
                {
                    ?>
                    <span class="alert alert-success">Location Created Succesfully!</span>
                    <script>
                        setTimeout(function(){
                            setState('addForm','<?php echo SECURE_PATH; ?>/addLocation/process.php','addForm=1');
                            setState('tableDisplay','<?php echo SECURE_PATH; ?>/addLocation/process.php','tableDisplay=1');
                        },3000)
                    </script>
                    <?php
                }
                else
                {
                    ?>
                    <div class="alert alert-danger"><?php echo $database->connection->errorInfo(); ?></div>
                    <script>
                        setTimeout(function() {
                            setState('addForm', '<?php echo SECURE_PATH; ?>addLocation/process.php','addForm=1');
                            setState('tableDisplay', '<?php echo SECURE_PATH; ?>addLocation/process.php','tableDisplay=1');
                        },3000)
                    </script>
                    <?php
                }
            }
    }

}
if(isset($_REQUEST['tableDisplay']))
{
$u = 1;
$query = $database->connection->query("select * from location");
$query->execute();
?>
<section class="content-area">
    <div class="row">
        <div class="col-xl-12 col-lg-12">
            <div class="card border-0 shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">List Of Locations</h6>
                    <span class="tools pull-right"><a target="_blank" href="<?php echo SECURE_PATH ?>createProject/excel.php?type=location" ><i class="fa fa-file-excel-o fa-2x" style="color:green;" aria-hidden="true"></i></a></span>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php if ($query->rowCount() > 0){ ?>
                            <table class="table table-hover table-bordered">
                                <thead class="thead-dark">
                                <th>SNO</th>
                                <th>Location</th>
                                <th>#</th>
                                </thead>
                                <?php
                                while ($row = $query->fetch(PDO::FETCH_ASSOC))
                                { ?>
                                <tbody>
                                <td><?php echo $u++ ?></td>
                                <td><?php echo $row['location'] ?></td>
                                <td><a type="button" id="edit" class="btn btn-warning"
                                       onclick="setState('addForm','<?php echo SECURE_PATH ?>addLocation/process.php','addForm=2&editform=<?php echo $row['id'] ?>')"><i
                                                class="fa fa-edit"></i></a></td>
                                <?php }
                                }
                                else {
                                    echo "Currently There are no Locations. Click on Locations Added Will be shown here";
                                } ?>
                                </tbody>
                            </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php }
?>
