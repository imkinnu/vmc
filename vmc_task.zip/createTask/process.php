<?php
error_reporting(1);
ini_set('display_errors','On');
include('../include/session.php');
if(!$session->logged_in){
    ?>
    <script type="text/javascript">
        setStateGet('main','<?php echo SECURE_PATH;?>login_process.php','loginForm=1');
    </script>
    <?php
}
if(isset($_POST['loadButton'])){
    ?>
    <button class="btn btn-primary" id="create_task"><i class="fa fa-plus-circle text-white"></i> Create Task</button>
    <script>
        // $('#addForm').css('display', 'none');
        $('#create_task').on('click',function(){
            $('#addForm').slideToggle();
        })
    </script>
<?php }
//Metircs Forms, Tables and Functions
//Display cadre form
if(isset($_POST['addForm'])){
        if($_POST['addForm'] == 2 && isset($_POST['editform'])){ ?>
            <script>
                $('#addForm').slideDown();
            </script>
            <?php $data_sel = $session->query("SELECT * FROM task WHERE id = :id");
            $data_sel->execute(array('id'=>$_POST['editform']));
            $data = $data_sel->fetch(PDO::FETCH_ASSOC);
            $flag=1;
            $_POST = array_merge($data,$_POST);
            }
    ?>
    <section class="content-area">
            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="card border-0 shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Create New Task</h6>
                            <span class="float-right">
                                <a role="button" onclick="setState('addForm','<?php echo SECURE_PATH ?>createTask/process.php','addForm=1 ')"><i class="fa fa-refresh text-primary text-lg-right"></i> Refresh</a>
                            </span>
                        </div>
                        <div class="card-body">
                            <form id="taskForm">
                                <div class="form-group ">
                                    <div class="form-group row">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-lg-6 col-md-12">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Task Title<span class="text-danger">*</span></label>
                                                        <div class="col-sm-8">
                                                            <input id="task_title" class="form-control" placeholder="Task Of Title" value="<?php if(isset($_POST['title'])){echo $_POST['title'];}?>" />
                                                            <span class="text-danger"><?php if(isset($_SESSION['error']['title'])){echo $_SESSION['error']['title'];}?></span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row mt-4">
                                                        <label class="col-sm-4 col-form-label">Assigned To<span class="text-danger">*</span></label>
<!--                                                        --><?php //if(isset($_POST['assignedto']))
//                                                        {
//                                                            $split = str_split($_POST['assignedto'], 1);
//                                                            print_r($split);
//                                                            $query = $database->query("select id,stakeholder from project where id='" . $_POST['project_name'] . "' and stakeholder IN ('".$split."')");
//                                                        } ?>
                                                        <div class="col-sm-8">
                                                            <select tabindex="3" class="js-example-basic-multiple form-control text-capitalize" id="assignedto" multiple="multiple">
                                                                <option value="">Select</option>
                                                            <?php
                                                            if(isset($_POST['project_name'])) {
                                                                $query = $session->query("select id,stakeholder from project where id=:id");
                                                                $query->execute(array('id'=>$_POST['project_name']));
                                                                while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
                                                                    $stakeholder = explode(',', $row['stakeholder']);
                                                                    for ($x = 0; $x < count($stakeholder); $x++) { ?>
                                                                        <option value="<?php echo $stakeholder[$x] ?>"
                                                                        <?php
                                                                            if(isset($_POST['assignedto']))
                                                                            {
                                                                                $assigned = explode(',',$_POST['assignedto']);
                                                                                for($z=0;$z<count($assigned);$z++)
                                                                                {
                                                                                    if($assigned[$z] == $stakeholder[$x])
                                                                                    {
                                                                                        echo 'selected="selected"';
                                                                                    }
                                                                                }
                                                                            }
                                                                        ?>
                                                                        ><?php echo $database->get_name('employee', 'id', $stakeholder[$x], 'username') ?></option>
                                                                    <?php }
                                                                }
                                                            }?>
                                                            </select>
                                                            <span class="text-danger"><span class="text-danger"><?php if(isset($_SESSION['error']['assignedto'])){echo $_SESSION['error']['assignedto'];}?></span></span>
                                                        </div>
                                                        <script>
                                                            $(document).ready(function() {
                                                                $('.js-example-basic-multiple ').select2({
                                                                    placeholder: 'Start Entering a Name..',
                                                                    dropdownAutoWidth : true,
                                                                    // selectOnClose:true
                                                                });
                                                            });
                                                        </script>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Due Date<span class="text-danger">*</span></label>
                                                        <div class="col-sm-8">
                                                            <input class="form-control datepicker1" id="due_date" value="<?php if(isset($_POST['due_date'])){echo $_POST['due_date'] ;}?>" maxlength="10" autocomplete="off" tabindex="5">
                                                            <span class="text-danger"><span class="text-danger"><?php if(isset($_SESSION['error']['due_date'])){echo $_SESSION['error']['due_date'];}?></span></span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Ward<span class="text-danger">*</span></label>
                                                        <div class="col-sm-8">
                                                            <select class="form-control" id="ward">
                                                                <option value="">Select Ward</option>
                                                                <?php
                                                                if(isset($_POST['circle']))
                                                                {
                                                                    $query = $session->query("select * from ward where circle =:circle");
                                                                    $query->execute(array('circle'=>$_POST['circle']));
                                                                    while($row = $query->fetch(PDO::FETCH_ASSOC))
                                                                    { ?>
                                                                        <option value="<?php echo $row['id']?>"
                                                                            <?php
                                                                            if(isset($_POST['ward']))
                                                                            {
                                                                                if($_POST['ward'] == $row['id'])
                                                                                {
                                                                                    echo "selected";
                                                                                }
                                                                            }
                                                                            ?>
                                                                        ><?php echo $row['ward']?></option>
                                                                    <?php }
                                                                } ?>
                                                            </select>
                                                            <span class="text-danger"><?php if(isset($_SESSION['error']['ward'])){ echo $_SESSION['error']['ward'];}?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6 col-md-12">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Select Project<span class="text-danger">*</span></label>
                                                        <div class="col-sm-8">
                                                            <?php
                                                            $getProject = $session->query("select id,project_name from project");
                                                            $getProject->execute();
                                                            ?>
                                                            <select tabindex="2" class="form-control text-capitalize" id="sel_project" onchange="setState('addForm','<?php echo SECURE_PATH ?>createTask/process.php','addForm=1&title='+$('#task_title').val()+'&assignedto='+$('#assignedto').val()+'&project_name='+$('#sel_project').val()+'&assigned_date='+$('#assigned_date').val()+'&due_date='+$('#due_date').val()+'&circle='+$('#circle').val()+'&ward='+$('#ward').val())"<?php if(isset($_REQUEST['editform'])){echo "disabled";}?>>
                                                             <option value="">Select</option>
                                                             <?php
                                                                while($getProjectName = $getProject->fetch(PDO::FETCH_ASSOC))
                                                                { ?>
                                                                    <option value="<?php echo $getProjectName['id'] ?>"
                                                                    <?php
                                                                        if(isset($_POST['project_name']))
                                                                        {
                                                                            if($_POST['project_name'] == $getProjectName['id'])
                                                                            {
                                                                                echo "selected";
                                                                            }
                                                                        }
                                                                    ?>
                                                                    ><?php echo $getProjectName['project_name'] ?></option>
                                                                <?php }
                                                             ?>
                                                            </select>
                                                            <span class="text-danger"><?php if(isset($_SESSION['error']['project_name'])){echo $_SESSION['error']['project_name'];}?></span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Assigned Date<span class="text-danger">*</span></label>
                                                        <div class="col-sm-8">
                                                            <input tabindex="4" class="form-control datepicker1" id="assigned_date" value="<?php if(isset($_POST['assigned_date'])){echo $_POST['assigned_date'] ;}?>" maxlength="10" autocomplete="off" tabindex="1">
                                                            <span class="text-danger"><span class="text-danger"><?php if(isset($_SESSION['error']['assigned_date'])){echo $_SESSION['error']['assigned_date'];}?></span></span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Circle<span class="text-danger">*</span></label>
                                                        <div class="col-sm-8">
                                                            <select class="form-control" id="circle" onchange="setState('addForm','<?php echo SECURE_PATH ?>createTask/process.php','addForm=1&title='+$('#task_title').val()+'&assignedto='+$('#assignedto').val()+'&project_name=<?php echo $_POST['project_name']?>'+'&assigned_date='+$('#assigned_date').val()+'&due_date='+$('#due_date').val()+'&circle='+$(this).val()+'&ward='+$('#ward').val()+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform'];}?>' )">
                                                                <option value="">Select Circle</option>
                                                                <?php
                                                                $query = $session->query("select * from circle");
                                                                $query->execute();
                                                                while($row = $query->fetch(PDO::FETCH_ASSOC))
                                                                { ?>
                                                                    <option value="<?php echo $row['id']?>"
                                                                        <?php
                                                                        if(isset($_POST['circle']))
                                                                        {
                                                                            if($_POST['circle'] == $row['id'])
                                                                            {
                                                                                echo "selected";
                                                                            }
                                                                        }
                                                                        ?>
                                                                    ><?php echo $row['circle']?></option>
                                                                <?php }
                                                                ?>
                                                            </select>
                                                            <span class="text-danger"><?php if(isset($_SESSION['error']['circle'])){ echo $_SESSION['error']['circle'];}?></span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <?php
                                                        if(isset($_POST['editform']))
                                                        { ?>
                                                            <a class="ml-5 mt-2 radius-20 btn btn-primary text-white px-5" style="cursor: pointer;" onclick="setState('result','<?php echo SECURE_PATH ?>createTask/process.php','validateForm=1&title='+$('#task_title').val()+'&assignedto='+$('#assignedto').val()+'&project_name=<?php echo $_POST['project_name']?>'+'&assigned_date='+$('#assigned_date').val()+'&due_date='+$('#due_date').val()+'&circle='+$('#circle').val()+'&ward='+$('#ward').val()+'<?php if(isset($_POST['editform'])){echo '&editform='.$_POST['editform'];}?>' )">Update</a>
                                                        <?php }
                                                        else { ?>
                                                            <a class="ml-5 mt-2 radius-20 btn btn-success text-white px-5" style="cursor: pointer;" onclick="setState('result','<?php echo SECURE_PATH ?>createTask/process.php','validateForm=1&title='+$('#task_title').val()+'&assignedto='+$('#assignedto').val()+'&project_name='+$('#sel_project').val()+'&assigned_date='+$('#assigned_date').val()+'&due_date='+$('#due_date').val()+'&circle='+$('#circle').val()+'&ward='+$('#ward').val() )">Create</a>
                                                        <?php }
                                                        ?>
                                                        <a class="ml-2 mt-2 radius-20 btn btn-danger text-white px-5" style="cursor: pointer;" onclick="setState('addForm','<?php echo SECURE_PATH?>createTask/process.php','addForm=1')">Reset</a>
                                                    </div>
                                                    <div id="result" class="row mt-5 ml-5">

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <script type="text/javascript">
        $(document).ready(function() {
            $(function () {
                $('.datepicker1,.datepicker2,.datepicker3').datetimepicker({
                    format: 'DD-MM-YYYY'
                });
            })
        });
    </script>
    <?php
}
if(isset($_POST['validateForm']))
{
    $_SESSION['error'] = array();
    $field = 'title';
    if(!$_POST['title'] || strlen(trim($_POST['title'])) == 0)
    {
        $_SESSION['error'][$field] = "* Please Enter Task Title";
    }

    $field = 'assignedto';
    if(!$_POST['assignedto'] || strlen(trim($_POST['assignedto'])) == 0 || $_POST['assignedto'] == 'null')
    {
        $_SESSION['error'][$field] = "* Please Select Stakeholders";
    }

    $field = 'project_name';
    if(!$_POST['project_name'] || strlen(trim($_POST['project_name'])) == 0)
    {
        $_SESSION['error'][$field] = "* Please Select One Project";
    }

    $field = "circle";
    if(!$_POST['circle'] || strlen(trim($_POST['circle'])) == 0 )
    {
        $_SESSION['error'][$field] = "* Please Select a Circle";
    }

    $field = "ward";
    if(!$_POST['ward'] || strlen(trim($_POST['ward'])) == 0 )
    {
        $_SESSION['error'][$field] = "* Please Select a Ward";
    }

    $field = 'assigned_date';
    if ($_POST['assigned_date'] == "")
    {
        $_SESSION['error'][$field]  = "* Please Select Assigned Date";
    }
    $field = 'due_date';
    if ($_POST['due_date'] == "")
    {
        $_SESSION['error'][$field]  = "* Please Select Assigned Date";
    }

    if(count($_SESSION['error']) > 0)
    {
        ?>
        <script type="text/javascript">
            setState('addForm','<?php echo SECURE_PATH ?>createTask/process.php','addForm=1&title='+$('#task_title').val()+'&assignedto='+$('#assignedto').val()+'&project_name='+$('#sel_project').val()+'&assigned_date='+$('#assigned_date').val()+'&due_date='+$('#due_date').val()+'&circle='+$('#circle').val()+'&ward='+$('#ward').val() )
        </script>
        <?php

    }
    else
    {
        unset($_SESSION['error']);
        if(isset($_POST['editform']))
        {
            $up = $session->query("UPDATE task SET title='" . $_POST['title'] . "',assignedto='" . $_POST['assignedto'] . "',project_name='" . $_POST['project_name'] . "',assigned_date='" . $_POST['assigned_date'] . "',due_date='" . $_POST['due_date'] . "',circle='".$_POST['circle']."',ward='".$_POST['ward']."' WHERE id=:id");
            $up->execute(array('id'=>$_POST['editform']));
            if($up)
            {
                ?>
                <span class="alert alert-warning">Task Details Updated</span>
                <script>
                    setTimeout(function() {
                        setState('addForm', '<?php echo SECURE_PATH; ?>//createTask/process.php','addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>createTask/process.php','tableDisplay=1');
                   },3000)
                </script>
                <?php
            }
            else
            {
                ?>
                <div class="alert alert-danger"><?php echo mysqli_error($database->connection); ?></div>
                <script>
                    setTimeout(function() {
                        setState('addForm', '<?php echo SECURE_PATH; ?>createTask/process.php','addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>createTask/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
        }
        else
        {

            $desg='';
            $selmax=$session->query("SELECT MAX(task_idi) FROM task");
            $selmax->execute();
            $rowmax=$selmax->fetch(PDO::FETCH_ASSOC);

            $emaxid=$rowmax['MAX(project_idi)']+1;

            $xlen=strlen($emaxid);
            $xval=5-$xlen;
            for($x=1;$x<=$xval;$x++)
            {
                $desg .="0";
            }

            $empidD=$desg.$emaxid;
            $taskidi = "TK".$empidD;

            $insert = $session->query("INSERT INTO task values (:nu,:emaxid,:taskidi,:title,:assignedto,:username,:project_name,:assigned_date,:due_date,:nu1,:o,:nu2,:nu3,:circle,:ward,:susername,:ti ) ");

            $insert->execute(array('nu'=>NULL,'emaxid'=>$emaxid,'taskidi'=>$taskidi,'title'=>$_POST['title'],'assignedto'=>$_POST['assignedto'],'username'=>$session->username,'project_name'=>$_POST['project_name'],'assigned_date'=>$_POST['assigned_date'],'due_date'=>$_POST['due_date'],'nu1'=>NULL,'o'=>1,'nu2'=>NULL,'nu3'=>NULL,'circle'=>$_POST['circle'],'ward'=>$_POST['ward'],'susername'=>$session->username,'ti'=>time() ));

            if($insert)
            {
                ?>
                <span class="alert alert-success">Task Created Succesfully</span>
                <script>
                    setTimeout(function(){
                        setState('addForm','<?php echo SECURE_PATH; ?>createTask/process.php','addForm=1');
                        setState('tableDisplay','<?php echo SECURE_PATH; ?>createTask/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
            else
            {
                ?>
                <div class="alert alert-danger"><?php echo mysqli_error($database->connection); ?></div>
                <script>
                    setTimeout(function() {
                        setState('addForm', '<?php echo SECURE_PATH; ?>createTask/process.php','addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>createTask/process.php','tableDisplay=1');
                    },3000)
                </script>
                <?php
            }
        }
        ?>
        <?php
    }
}
if(isset($_POST['tableDisplay']))
{ ?>
    <script type="text/javascript">
        var tableToExcel = (function () {
            var uri = 'data:application/vnd.ms-excel;base64,'
                ,
                template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
                , base64 = function (s) {
                    return window.btoa(unescape(encodeURIComponent(s)))
                }
                , format = function (s, c) {
                    return s.replace(/{(\w+)}/g, function (m, p) {
                        return c[p];
                    })
                };
            return function (table, name) {
                if (!table.nodeType) table = document.getElementById(table)
                var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
                window.location.href = uri + base64(format(template, ctx))
            }
        })()
    </script>
    <?php
    $i=1;
    $uname = 'admin';
    $query = $session->query("select * from task");
    $query->execute();
    ?>
    <section class="content-area">
            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="card border-0 shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Tasks Created</h6>
                            <span class="float-right">
                                <button class="btn btn-success" onclick="tableToExcel('example', 'List of Circles')"><i class="fa fa-file-excel-o"></i> Download</button>
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="form-group ">
                                <div class="form-group row">
                                    <div class="card-body">
                                        <div class="row">
                                            <?php if($query->rowCount() >0){ ?>
                                                <table class="table table-bordered" id="example">
                                                    <thead class="thead-dark">
                                                    <tr>
                                                        <th>SNO</th>
                                                        <th>Title Of Task</th>
                                                        <th>Assigned To</th>
                                                        <th>Forwarded to</th>
                                                        <th>Project Name</th>
                                                        <th>Assigned Date</th>
                                                        <th>Due Date</th>
                                                        <th>Status</th>
                                                        <th>#</th>
                                                    </tr>
                                                    </thead>
                                                    <?php while($row = $query->fetch(PDO::FETCH_ASSOC))
                                                    { ?>
                                                        <tbody>
                                                        <tr>
                                                            <td><?php echo $i++; ?></td>
                                                            <td><?php echo $row['title'] ?></td>
                                                            <td class="text-capitalize"><?php
                                                                $assignedTo = explode(',',$row['assignedto']);
                                                                $employee = '';
                                                                for($x = 0 ; $x < count($assignedTo) ; $x++){
                                                                    $employee .= $database->get_name('employee','id',$assignedTo[$x],'username').",";
                                                                }
                                                                echo rtrim($employee,',');
                                                                ?></td>
                                                            <td class="text-capitalize"><?php
                                                                $forwardTo = explode(',',$row['forwardto']);
                                                                $employee = '';
                                                                for($x = 0 ; $x < count($forwardTo) ; $x++){
                                                                    $employee .= $database->get_name('employee','id',$forwardTo[$x],'username').",";
                                                                }
                                                                echo strlen($employee) == 0 || $employee == ',' ? "NA" : rtrim($employee,',')  ;
                                                                ?></td>
                                                            <td><?php echo $database->get_name('project','id',$row['project_name'],'project_name') ?></td>
                                                            <td><?php echo $row['assigned_date'] ?></td>
                                                            <td><?php echo $row['due_date'] ?></td>
                                                            <td><?php switch ($row['status'])
                                                                {
                                                                    case "5" :echo "<span class='badge badge-success'>Completed</span>";
                                                                        break;
                                                                    case "4" : echo "<span class='badge badge-danger'>Returned</span>";
                                                                    break;
                                                                    case "3" : echo "<span class='badge badge-warning'>Forwarded</span>";
                                                                        break;
                                                                    case "2" : echo "<span class='badge badge-info'>In Progress</span>";
                                                                        break;
                                                                    case "1" : echo "<span class='badge badge-info'>Open</span>";
                                                                        break;
                                                                } ?></td>
                                                            <?php if($row['status'] != '5'){ ?>
                                                                <td><a type="button" id="edit" class="btn btn-warning" value="" onclick="setState('addForm','<?php echo SECURE_PATH?>createTask/process.php','addForm=2&editform=<?php echo $row['id'] ?>')" ><i class="fa fa-edit"></i></a></td>
                                                            <?php }
                                                            else { ?>
                                                                <td>NA</td>
                                                            <?php }?>
                                                        </tr>
                                                        </tbody>
                                                    <?php } ?>
                                                </table>
                                            <?php }
                                            else {
                                                echo "Currently There are no Tasks. Click on <b>&nbsp;&nbsp;Create Task&nbsp;&nbsp;</b> To Create a Task";
                                            }?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php }
?>