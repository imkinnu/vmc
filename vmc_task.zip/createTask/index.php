<?php
include('../include/session.php');

unset($_SESSION['error']);

ini_set('display_errors', 'On');
error_reporting(E_ALL); ?>
<head>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
</head>
<?php if(!$session->logged_in)
{
	?>
	<script type="text/javascript">
	window.location = '<?php echo SECURE_PATH; ?>';
	</script>
	<?php
}
else
{
	?>
	<!-- Breadcrumbs-->
    <head>
        <style>
            .select2-search__field,.select2-selection--multiple
            {
                width:311px !important;
            }
            #example {
                white-space: nowrap !important;
            }
        </style>
    </head>
	<section class="breadcrumbs-area2 my-3">
		<div class="container-fluid">
			<div class="d-flex justify-content-between align-items-center">
				<div class="title">
					
				</div>
			</div>
        </div>
	</section>
    <!-- End Breadcrumbs-->
    <div class="content mb-4" id="loadButton">
        <script>
            setState('loadButton','<?php echo SECURE_PATH; ?>createTask/process.php','loadButton=1')
        </script>
    </div>
    <div class="content" id="addForm" style="display: none;">
        <script>
            setState('addForm','<?php echo SECURE_PATH; ?>createTask/process.php','addForm=1')
        </script>
    </div>

    <div class="content" id="tableDisplay">
        <script>
            setState('tableDisplay','<?php echo SECURE_PATH;?>createTask/process.php','tableDisplay=1');
        </script>
    </div>
    <?php

}
?>