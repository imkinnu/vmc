<?php
error_reporting(0);
ini_set('display_errors', 'On');
include('../include/session.php');
if (!$session->logged_in) {
    ?>
    <script type="text/javascript">
        setStateGet('main', '<?php echo SECURE_PATH;?>login_process.php', 'loginForm=1');
    </script>
    <?php
}

//Metircs Forms, Tables and Functions
//Display cadre form
if (isset($_POST['addForm'])) { ?>
    <script>
        $('#circle').focus();
    </script>
    <?php if ($_POST['addForm'] == 2 && isset($_POST['editform'])) { ?>
        <script>
            $('#addForm').slideDown();
        </script>
        <?php $data_sel = $session->query("SELECT * FROM circle WHERE id = :id");
        $data_sel->execute(array('id' => $_POST['editform']));
        $data = $data_sel->fetch(PDO::FETCH_ASSOC);
        $flag = 1;
        $_POST = array_merge($data, $_POST);
    }
    ?>
    <section class="content-area">
        <div class="row">
            <div class="col-xl-12 col-lg-12">
                <div class="card border-0 shadow mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Add New Department</h6>
                        <span class="float-right">
                                <a role="button"
                                   onclick="setState('addForm','<?php echo SECURE_PATH ?>addCircle/process.php','addForm=1 ')"><i
                                            class="fa fa-refresh text-primary text-lg-right"></i> Refresh</a>
                            </span>
                    </div>
                    <div class="card-body">
                        <form id="taskForm">
                            <div class="form-group ">
                                <div class="form-group row">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6 col-md-12">
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Circle Name<span
                                                                style="color:red;">*</span></label>
                                                    <div class="col-sm-8">
                                                        <input id="circle" class="form-control" autocomplete="off"
                                                               placeholder="Enter Circle"
                                                               value="<?php if (isset($_POST['circle'])) {
                                                                   echo $_POST['circle'];
                                                               } ?>"/>
                                                        <span class="text-danger"><?php if (isset($_SESSION['error']['circle'])) {
                                                                echo $_SESSION['error']['circle'];
                                                            } ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-md-12">
                                                <div class="form-group row">
                                                    <div class="col-sm-8">
                                                        <?php
                                                        if (isset($_POST['editform'])) { ?>
                                                            <input class="btn btn-primary btn-block" type="button"
                                                                   value="Update"
                                                                   onclick="setState('result','<?php echo SECURE_PATH ?>addCircle/process.php','validateForm=1&circle='+$('#circle').val()+'<?php if (isset($_POST['editform'])) {
                                                                       echo '&editform=' . $_POST['editform'];
                                                                   } ?>' )"/>
                                                        <?php } else {
                                                            ?>
                                                            <input class="btn btn-primary btn-block" type="button"
                                                                   value="Add"
                                                                   onclick="setState('result','<?php echo SECURE_PATH ?>addCircle/process.php','validateForm=1&circle='+$('#circle').val())"/>
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 col-md-12">
                                                <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Circle Name<span
                                                                style="color:red;">*</span></label>
                                                    <div class="col-sm-8">
                                                        <input id="search" class="form-control" autocomplete="off"
                                                               placeholder="Search Circle"
                                                               value="<?php if (isset($_POST['circle'])) {
                                                                   echo $_POST['circle'];
                                                               } ?>"/>
                                                        <span class="text-danger"><?php if (isset($_SESSION['error']['circle'])) {
                                                                echo $_SESSION['error']['circle'];
                                                            } ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-md-12">
                                                <div class="form-group row">
                                                    <div class="col-sm-8">
                                                        <input class="btn btn-success btn-block" type="button"
                                                               value="Search"
                                                               onclick="setState('tableDisplay','<?php echo SECURE_PATH; ?>addCircle/process.php','tableDisplay=1&circle='+$('#search').val())"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-2">
                                            <div class="col-lg-6">

                                            </div>
                                            <div class="col-lg-6" id="result">

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php }
if (isset($_REQUEST['validateForm'])) {
    $_SESSION['error'] = array();
    $field = 'circle';
    if (!$_POST['circle'] || strlen(trim($_POST['circle'])) == 0) {
        $_SESSION['error'][$field] = "* Please Enter Circle Name";
    }
    if (count($_SESSION['error']) > 0) {
        ?>
        <script type="text/javascript">
            setState('addForm', '<?php echo SECURE_PATH ?>addCircle/process.php', 'addForm=1&circle=<?php $_POST['circle']?>')
        </script>
        <?php
    } else {
        unset($_SESSION['error']);
        if (isset($_POST['editform'])) {
            $up = $session->query("UPDATE circle SET circle='" . $_POST['circle'] . "' WHERE id=:id");
            $up->execute(array('id' => $_POST['editform']));
            if ($up) {
                ?>
                <span class="alert alert-warning">Circle Details Updated</span>
                <script>
                    setTimeout(function () {
                        setState('addForm', '<?php echo SECURE_PATH; ?>addCircle/process.php', 'addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>addCircle/process.php', 'tableDisplay=1');
                    }, 3000)
                </script>
                <?php
            } else {
                ?>
                <div class="alert alert-danger"><?php echo $database->connection->errorInfo(); ?></div>
                <script>
                    setTimeout(function () {
                        setState('addForm', '<?php echo SECURE_PATH; ?>addCircle/process.php', 'addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>addCircle/process.php', 'tableDisplay=1');
                    }, 3000)
                </script>
                <?php
            }
        } else {
            $insert = $session->query("INSERT INTO circle values (:nu,:circle )");
            $insert->execute(array('nu' => NULL, 'circle' => $_POST['circle']));
            if ($insert) {
                ?>
                <span class="alert alert-success">Circle Created Succesfully!</span>
                <script>
                    setTimeout(function () {
                        setState('addForm', '<?php echo SECURE_PATH; ?>/addCircle/process.php', 'addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>/addCircle/process.php', 'tableDisplay=1');
                    }, 3000)
                </script>
                <?php
            } else {
                ?>
                <div class="alert alert-danger"><?php echo $database->connection->errorInfo(); ?></div>
                <script>
                    setTimeout(function () {
                        setState('addForm', '<?php echo SECURE_PATH; ?>addCircle/process.php', 'addForm=1');
                        setState('tableDisplay', '<?php echo SECURE_PATH; ?>addCircle/process.php', 'tableDisplay=1');
                    }, 3000)
                </script>
                <?php
            }
        }
    }

}
if (isset($_REQUEST['tableDisplay'])) { ?>
    <script type="text/javascript">
        var tableToExcel = (function () {
            var uri = 'data:application/vnd.ms-excel;base64,'
                ,
                template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
                , base64 = function (s) {
                    return window.btoa(unescape(encodeURIComponent(s)))
                }
                , format = function (s, c) {
                    return s.replace(/{(\w+)}/g, function (m, p) {
                        return c[p];
                    })
                };
            return function (table, name) {
                if (!table.nodeType) table = document.getElementById(table)
                var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
                window.location.href = uri + base64(format(template, ctx))
            }
        })()
    </script>
    <?php
    $u = 1;
    $array = [];
    if (isset($_POST['circle'])) {
        $con = " where circle LIKE :circle";
        $array['circle'] = "%" . $_POST['circle'] . "%";
    }

    $query = $database->connection->prepare("select * from circle $con");
    $query->execute($array);
    ?>
    <section class="content-area">
        <div class="row">
            <div class="col-xl-12 col-lg-12">
                <div class="card border-0 shadow mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">List Of Circles</h6>
                        <button class="btn btn-success" onclick="tableToExcel('table', 'List of Circles')"><i
                                    class="fa fa-file-excel-o"></i> Download</button>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php if ($query->rowCount() > 0){ ?>
                            <table class="table table-hover table-bordered" id="table">
                                <thead class="thead-dark">
                                <th>SNO</th>
                                <th>Circle</th>
                                <th>#</th>
                                </thead>
                                <?php
                                while ($row = $query->fetch(PDO::FETCH_ASSOC))
                                { ?>
                                <tbody>
                                <td><?php echo $u++ ?></td>
                                <td><?php echo $row['circle'] ?></td>
                                <td><a type="button" id="edit" class="btn btn-warning"
                                       onclick="setState('addForm','<?php echo SECURE_PATH ?>addCircle/process.php','addForm=2&editform=<?php echo $row['id'] ?>')"><i
                                                class="fa fa-edit"></i></a></td>
                                <?php }
                                }
                                else {
                                    echo "No Results To Display!";
                                } ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php }
?>
