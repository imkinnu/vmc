<?php
 
include("database.php");
//include("mailer.php");
include("form.php");
date_default_timezone_set('Asia/Kolkata');
class Session
{
   var $username;     //Username given on sign-up
   var $userid;       //Random value generated on current login
   var $userlevel;    //The level to which the user pertains
   var $time;         //Time user was last active (page loaded)
   var $logged_in;    //True if user is logged in, false otherwise
   var $userinfo = array();  //The array holding all user info
   var $url;          //The page url current being viewed
   var $referrer;     //Last recorded site page viewed
   var $peoples_rep1 = array(1=>'Zilla Parishad Chairman',
                             2=>'Member of Parliament',
                             3=>'MLA',
                             4=>'ZPTC',
                             5=>'Mandal Parishad President',
                             6=>'MPTC',
                             7=>'Sarpanch',
                             8=>'Ward Member');
							 
      var $new_committee = array(1=>'Sanitation',
                             2=>'Drinking Water',
                             3=>'Infrastructure',
                             4=>'Women & Chid Development',
                             );							 
							 
							
   var $peoples_rep = array(1=>'ZP Chairman',
                             2=>'MP',
                             3=>'MLA',
                             4=>'ZPTC',
                             5=>'MPP',
                             6=>'MPTC-1',
                             7=>'MPTC-2',

                             8=>'Sarpanch',
							 9=>'Upa Sarpanch',
                             10=>'Ward Member - 1',
							 11=>'Ward Member - 2',
							 12=>'Ward Member - 3',
							 13=>'Ward Member - 4',
							 14=>'Ward Member - 5',
							 15=>'Ward Member - 6',
							 16=>'Ward Member - 7',
							 17=>'Ward Member - 8',
							 18=>'Ward Member - 9',
							 19=>'Ward Member - 10',
							 20=>'Ward Member - 11',
							 21=>'Ward Member - 12',
							 22=>'Ward Member - 13',
							 23=>'Ward Member - 14',
							 24=>'Ward Member - 15',
							 25=>'Ward Member - 16',
							 26=>'Ward Member - 17',
							 27=>'Ward Member - 18',
							 28=>'Ward Member - 19',
							 29=>'Ward Member - 20',
							 30=>'Ward Member - 21',
							 31=>'Ward Member - 22',
							 32=>'Ward Member - 23',
							 33=>'Ward Member - 24',
							 34=>'Ward Member - 25',
							 35=>'Ward Member - 26',
							 36=>'Ward Member - 27',
							 37=>'Ward Member - 28',
							 38=>'Ward Member - 29',
							 39=>'Ward Member - 30',
							 40=>'Ward Member - 31'
							 );
	
 
 



   var $nonpanchayat_staff = array(1=>'Filed Assistant',
                             2=>'Sr.Mate',
                             3=>'Mrp',
                             4=>'MPEO',
                             5=>'MPHA',
                             6=>'Asha Worker',
                             7=>'Anganwadi Worker',
                             8=>'VRO',
							  9=>'VRA',
                             10=>'CO',
                             11=>'CA');							 

 var $public_servants1 = array(1=>'District Collector',
                             2=>'District Panchayat Officer',
                             3=>'Divisional Panchayat Officer',
                             4=>'Extension officer (PR & RD)',
                             5=>'GRAMAPANCHAYATS RELATED STAFF',
                             6=>'Panchayat Secretary ',
                             7=>'Junior assistant ',
							 8=>'Computer Operator',
                             9=>'Sanitary inspector ',
                             10=>'Junior assistant & Bill collector  ',
                             11=>'Bill collector',
                             12=>'Sanitary mestri',
                             13=>'Record assistant ',
                             14=>'Office subordinate ',
                             15=>'Electrician  ',
                             16=>'Pipe fitter',
                             17=>'Tank watcher',
                             18=>'Sweeper',
							 
                             19=>'Others'
                             );	

 var $public_servants = array(1=>'District Collector',
                             2=>'DPO',
                             3=>'DLPO',
							 4=>'MPDO',
							 5=>'EO(PR&RD)',
							 6=>'Panchayat Secretary ',
                             7=>'Sanitary inspector ',
							 8=>'Junior assistant ',
							 9=>'Junior assistant & Bill collector  ',
                             10=>'Computer Operator',
                             11=>'Sanitary mestri',
                             12=>'Office subordinate ',
                             13=>'Electrician  ',
                             14=>'Pipe fitter',
                             15=>'Tank watcher',
                             16=>'Sweeper',
							 
                             17=>'Others'
                             );	
				
				
 var $taxes = array( 1=> 'House Tax',
                     2=> 'Water Tax',
                     3=> 'Lighting Tax',
                     4=> 'Drainage Tax',
                     5=> 'Library Cess',
                     6=> 'Advertisement Tax',
                     7=> 'Kolagaram',
                     8=> 'Fruit Bearing Trees',
                     9=> 'Fishing Rights',
                     10=> 'Market Auctions',
                     11=> 'Grass Auctions',
                     12=> 'Kabela',
                     13=> 'Parking Stand',
                     14=> 'Shopping Complex',
                     15=> 'Old Items',
                     16=> 'Other (Sales)',
                     17=> 'Private Tap Fee',
                     18=> 'Licence Fee',
                     19=> 'Building Permissions Fees',
                     20=> 'Layout Permissions Fees',
                     21=> 'Other (Fees)',
                     22=> 'Private Tap Deposits',
                     23=> 'Non-Refundable Deposits',
                     24=> 'Refundable Deposits',
                     25=> 'Others (Deposits)',
                     26=> 'Penalties',
                     27=> 'Interests',
                     28=> 'Donations',
                     29=> 'Advance Recoveries',
                     30=> 'Salary Recoveries',
                     31=> 'Bhanduladodhi',
                     32=> 'Others (Others)',
                     33=> 'Professional Tax',
                     34=> 'Entertainment Tax',
                     35=> 'Mines & Minerals',
                     36=> 'Irrigation Cess',
                     37=> 'Surcharge on Stamp Duties',
                     38=> 'Others (Assigned Revenues)',
                     39=> 'Sarpanch Honararium',
                     40=> 'Population Grant',
                     41=> 'SFC Grants',
                     42=> 'Drinking water Grants',
                     43=> '14th Finance Grants',
                     44=> 'Other (Grants)',
                   );	
				   
				   

   var $vehicles = array(1=>'Bullock Cart',
                             2=>'TriCycle',
                             3=>'Tractor',
                              4=>'E-Vehicle',
                              5=>'Auto(Three Wheeler)',
                              6=>'Auto(Four wheeler)');		
							//, 2=>'10 AM - 2 AM' 
	 var $timeslots = array(1=>'6 AM - 10 AM',
                             3=>'2 PM - 6 PM');							 
				   						 						 
   /**
    * Note: referrer should really only be considered the actual
    * page referrer in process.php, any other time it may be
    * inaccurate.
    */

   /* Class constructor */
   function Session(){
      $this->time = time();
      $this->startSession();
   }

   /**
    * startSession - Performs all the actions necessary to 
    * initialize this session object. Tries to determine if the
    * the user has logged in already, and sets the variables 
    * accordingly. Also takes advantage of this page load to
    * update the active visitors tables.
    */
   function startSession(){
      global $database;  //The database connection
      session_start();   //Tell PHP to start the session

      /* Determine if user is logged in */
      $this->logged_in = $this->checkLogin();

      /**
       * Set guest value to users not logged in, and update
       * active guests table accordingly.
       */
      if(!$this->logged_in){
         $this->username = $_SESSION['username'] = GUEST_NAME;
         $this->userlevel = GUEST_LEVEL;
         $database->addActiveGuest($_SERVER['REMOTE_ADDR'], $this->time);
      }
      /* Update users last active timestamp */
      else{
         $database->addActiveUser($this->username, $this->time);
      }
      
      /* Remove inactive visitors from database */
      $database->removeInactiveUsers();
      $database->removeInactiveGuests();
      
      /* Set referrer page */
      if(isset($_SESSION['url'])){
         $this->referrer = $_SESSION['url'];
      }else{
         $this->referrer = "/";
      }

      /* Set current url */
      $this->url = $_SESSION['url'] = $_SERVER['PHP_SELF'];
   }

   /**
    * checkLogin - Checks if the user has already previously
    * logged in, and a session with the user has already been
    * established. Also checks to see if user has been remembered.
    * If so, the database is queried to make sure of the user's 
    * authenticity. Returns true if the user has logged in.
    */
   function checkLogin(){
      global $database;  //The database connection
      /* Check if user has been remembered */
      if(isset($_COOKIE['cookname']) && isset($_COOKIE['cookid'])){
         $this->username = $_SESSION['username'] = $_COOKIE['cookname'];
         $this->userid   = $_SESSION['userid']   = $_COOKIE['cookid'];
      }

      /* Username and userid have been set and not guest */
      if(isset($_SESSION['username']) && isset($_SESSION['userid']) &&
         $_SESSION['username'] != GUEST_NAME){
         /* Confirm that username and userid are valid */
         if($database->confirmUserID($_SESSION['username'], $_SESSION['userid']) != 0){
            /* Variables are incorrect, user not logged in */
            unset($_SESSION['username']);
            unset($_SESSION['userid']);
            return false;
         }

         /* User is logged in, set class variables */
         $this->userinfo  = $database->getUserInfo($_SESSION['username']);
         $this->username  = $this->userinfo['username'];
         $this->userid    = $this->userinfo['userid'];
         $this->userlevel = $this->userinfo['userlevel'];
         
         /* auto login hash expires in three days */
         if($this->userinfo['hash_generated'] < (time() - (60*60*24*3))){
         	/* Update the hash */
	         $database->updateUserField($this->userinfo['username'], 'hash', $this->generateRandID());
	         $database->updateUserField($this->userinfo['username'], 'hash_generated', time());
         }
         
         return true;
      }
      /* User not logged in */
      else{
         return false;
      }
   }

   /**
    * login - The user has submitted his username and password
    * through the login form, this function checks the authenticity
    * of that information in the database and creates the session.
    * Effectively logging in the user if all goes well.
    */
   function login($subuser, $subpass, $subremember){
      global $database, $form;  //The database and form object

      /* Username error checking */
      $field = "user";  //Use field name for username
	  $q = "SELECT valid FROM ".TBL_USERS." WHERE username='$subuser'";
	  $valid = $database->query($q);
	  $valid = mysqli_fetch_array($valid);
	  	      
      if(!$subuser || strlen($subuser = trim($subuser)) == 0){
         $form->setError($field, "* Username not entered");
      }
      else{
         /* Check if username is not alphanumeric */
         if(!ctype_alnum($subuser)){
            $form->setError($field, "* Username not alphanumeric");
         }
      }	  

      /* Password error checking */
      $field = "pass";  //Use field name for password
      if(!$subpass){
         $form->setError($field, "* Password not entered");
      }
      
      /* Return if form errors exist */
      if($form->num_errors > 0){
         return false;
      }

      /* Checks that username is in database and password is correct */
      $subuser = stripslashes($subuser);
      $result = $database->confirmUserPass($subuser, $subpass);

      /* Check error codes */
      if($result == 1){
         $field = "user";
         $form->setError($field, "* Username not found");
      }
      else if($result == 2){
         $field = "pass";
         $form->setError($field, "* Invalid password");
      }
      
      /* Return if form errors exist */
      if($form->num_errors > 0){
         return false;
      }

      
      if(EMAIL_WELCOME){
      	if($valid['valid'] == 0){
      		$form->setError($field, "* User's account has not yet been confirmed.");
      	}
      }
                  
      /* Return if form errors exist */
      if($form->num_errors > 0){
         return false;
      }
      


      /* Username and password correct, register session variables */
      $this->userinfo  = $database->getUserInfo($subuser);
      $this->username  = $_SESSION['username'] = $this->userinfo['username'];
      $this->userid    = $_SESSION['userid']   = $this->generateRandID();
      $this->userlevel = $this->userinfo['userlevel'];
      
      /* Insert userid into database and update active users table */
      $database->updateUserField($this->username, "userid", $this->userid);
      $database->addActiveUser($this->username, $this->time);
      $database->removeActiveGuest($_SERVER['REMOTE_ADDR']);

      /**
       * This is the cool part: the user has requested that we remember that
       * he's logged in, so we set two cookies. One to hold his username,
       * and one to hold his random value userid. It expires by the time
       * specified in constants.php. Now, next time he comes to our site, we will
       * log him in automatically, but only if he didn't log out before he left.
       */
      if($subremember){
         setcookie("cookname", $this->username, time()+COOKIE_EXPIRE, COOKIE_PATH);
         setcookie("cookid",   $this->userid,   time()+COOKIE_EXPIRE, COOKIE_PATH);
      }

      /* Login completed successfully */
      return true;
   }

   /**
    * logout - Gets called when the user wants to be logged out of the
    * website. It deletes any cookies that were stored on the users
    * computer as a result of him wanting to be remembered, and also
    * unsets session variables and demotes his user level to guest.
    */
   function logout(){
      global $database;  //The database connection
      /**
       * Delete cookies - the time must be in the past,
       * so just negate what you added when creating the
       * cookie.
       */
      if(isset($_COOKIE['cookname']) && isset($_COOKIE['cookid'])){
         setcookie("cookname", "", time()-COOKIE_EXPIRE, COOKIE_PATH);
         setcookie("cookid",   "", time()-COOKIE_EXPIRE, COOKIE_PATH);
      }

      /* Unset PHP session variables */
      unset($_SESSION['username']);
      unset($_SESSION['userid']);

      /* Reflect fact that user has logged out */
      $this->logged_in = false;
      
      /**
       * Remove from active users table and add to
       * active guests tables.
       */
      $database->removeActiveUser($this->username);
      $database->addActiveGuest($_SERVER['REMOTE_ADDR'], $this->time);
      
      /* Set user level to guest */
      $this->username  = GUEST_NAME;
      $this->userlevel = GUEST_LEVEL;
   }

   /**
    * register - Gets called when the user has just submitted the
    * registration form. Determines if there were any errors with
    * the entry fields, if so, it records the errors and returns
    * 1. If no errors were found, it registers the new user and
    * returns 0. Returns 2 if registration failed.
    */
   function register($subuser, $subpass, $subemail, $subname){
   
      global $database, $form, $mailer;  //The database, form and mailer object
      
      /* Username error checking */
      $field = "user";  //Use field name for username
      if(!$subuser || strlen($subuser = trim($subuser)) == 0){
         $form->setError($field, "* Username not entered");
      }
      else{
         /* Spruce up username, check length */
         $subuser = stripslashes($subuser);
         if(strlen($subuser) < 5){
            $form->setError($field, "* Username below 5 characters");
         }
         else if(strlen($subuser) > 30){
            $form->setError($field, "* Username above 30 characters");
         }
         /* Check if username is not alphanumeric */
         else if(!ctype_alnum($subuser)){
            $form->setError($field, "* Username not alphanumeric");
         }
         /* Check if username is reserved */
         else if(strcasecmp($subuser, GUEST_NAME) == 0){
            $form->setError($field, "* Username reserved word");
         }
         /* Check if username is already in use */
         else if($database->usernameTaken($subuser)){
            $form->setError($field, "* Username already in use");
         }
         /* Check if username is banned */
         else if($database->usernameBanned($subuser)){
            $form->setError($field, "* Username banned");
         }
      }

      /* Password error checking */
      $field = "pass";  //Use field name for password
      if(!$subpass){
         $form->setError($field, "* Password not entered");
      }
      else{
         /* Spruce up password and check length*/
         $subpass = stripslashes($subpass);
         if(strlen($subpass) < 4){
            $form->setError($field, "* Password too short");
         }
         /* Check if password is not alphanumeric */
         else if(!ctype_alnum(($subpass = trim($subpass)))){
            $form->setError($field, "* Password not alphanumeric");
         }
         /**
          * Note: I trimmed the password only after I checked the length
          * because if you fill the password field up with spaces
          * it looks like a lot more characters than 4, so it looks
          * kind of stupid to report "password too short".
          */
      }
      
      /* Email error checking */
      $field = "email";  //Use field name for email
      if(!$subemail || strlen($subemail = trim($subemail)) == 0){
         $form->setError($field, "* Email not entered");
      }
      else{
         /* Check if valid email address */
         if(filter_var($subemail, FILTER_VALIDATE_EMAIL) == FALSE){
            $form->setError($field, "* Email invalid");
         }
         /* Check if email is already in use */
         if($database->emailTaken($subemail)){
            $form->setError($field, "* Email already in use");
         }

         $subemail = stripslashes($subemail);
      }
      
      /* Name error checking */
	  $field = "name";
	  if(!$subname || strlen($subname = trim($subname)) == 0){
	     $form->setError($field, "* Name not entered");
	  } else {
	     $subname = stripslashes($subname);
	  }
      
      $randid = $this->generateRandID();
      
      /* Errors exist, have user correct them */
      if($form->num_errors > 0){
         return 1;  //Errors with form
      }
      /* No errors, add the new account to the */
      else{
         if($database->addNewUser($subuser, md5($subpass), $subemail, $randid, $subname)){
            if(EMAIL_WELCOME){               
               $mailer->sendWelcome($subuser,$subemail,$subpass,$randid);
            }
            return 0;  //New user added succesfully
         }else{
            return 2;  //Registration attempt failed
         }
      }
   }
   
   /**
    * editAccount - Attempts to edit the user's account information
    * including the password, which it first makes sure is correct
    * if entered, if so and the new password is in the right
    * format, the change is made. All other fields are changed
    * automatically.
    */
   function editAccount($subcurpass, $subnewpass, $subemail, $subname){
      global $database, $form;  //The database and form object
      /* New password entered */
      if($subnewpass){
         /* Current Password error checking */
         $field = "curpass";  //Use field name for current password
         if(!$subcurpass){
            $form->setError($field, "* Current Password not entered");
         }
         else{
            /* Check if password too short or is not alphanumeric */
            $subcurpass = stripslashes($subcurpass);
            if(strlen($subcurpass) < 4 ||
               !preg_match("^([0-9a-z])+$", ($subcurpass = trim($subcurpass)))){
               $form->setError($field, "* Current Password incorrect");
            }
            /* Password entered is incorrect */
            if($database->confirmUserPass($this->username,md5($subcurpass)) != 0){
               $form->setError($field, "* Current Password incorrect");
            }
         }
         
         /* New Password error checking */
         $field = "newpass";  //Use field name for new password
         /* Spruce up password and check length*/
         $subpass = stripslashes($subnewpass);
         if(strlen($subnewpass) < 4){
            $form->setError($field, "* New Password too short");
         }
         /* Check if password is not alphanumeric */
         else if(!preg_match("^([0-9a-z])+$", ($subnewpass = trim($subnewpass)))){
            $form->setError($field, "* New Password not alphanumeric");
         }
      }
      /* Change password attempted */
      else if($subcurpass){
         /* New Password error reporting */
         $field = "newpass";  //Use field name for new password
         $form->setError($field, "* New Password not entered");
      }
      
      /* Email error checking */
      $field = "email";  //Use field name for email
      if($subemail && strlen($subemail = trim($subemail)) > 0){
         /* Check if valid email address */
         if(filter_var($subemail, FILTER_VALIDATE_EMAIL) == FALSE){
            $form->setError($field, "* Email invalid");
         }
         $subemail = stripslashes($subemail);
      }
      
      /* Name error checking */
	  $field = "name";
	  if(!$subname || strlen($subname = trim($subname)) == 0){
	     $form->setError($field, "* Name not entered");
	  } else {

	     $subname = stripslashes($subname);
	  }
      
      /* Errors exist, have user correct them */
      if($form->num_errors > 0){
         return false;  //Errors with form
      }
      
      /* Update password since there were no errors */
      if($subcurpass && $subnewpass){
         $database->updateUserField($this->username,"password",md5($subnewpass));
      }
      
      /* Change Email */
      if($subemail){
         $database->updateUserField($this->username,"email",$subemail);
      }
      
      /* Change Name */
      if($subname){
         $database->updateUserField($this->username,"name",$subname);
      }
      
      /* Success! */
      return true;
   }
   
   /**
    * isAdmin - Returns true if currently logged in user is
    * an administrator, false otherwise.
    */
   function isAdmin(){
      return ($this->userlevel == ADMIN_LEVEL ||
              $this->username  == ADMIN_NAME);
   }
   
   /**
    * isAuthor - Returns true if currently logged in user is
    * an author or an administrator, false otherwise.
    */
   function isAuthor(){
      return ($this->userlevel == AUTHOR_LEVEL ||
              $this->userlevel == ADMIN_LEVEL);
   }
   
   /**
    * generateRandID - Generates a string made up of randomized
    * letters (lower and upper case) and digits and returns
    * the md5 hash of it to be used as a userid.
    */
   function generateRandID(){
      return md5($this->generateRandStr(16));
   }
   
   /**
    * generateRandStr - Generates a string made up of randomized
    * letters (lower and upper case) and digits, the length
    * is a specified parameter.
    */
   function generateRandStr($length){
      $randstr = "";
      for($i=0; $i<$length; $i++){
         $randnum = mt_rand(0,61);
         if($randnum < 10){
            $randstr .= chr($randnum+48);
         }else if($randnum < 36){
            $randstr .= chr($randnum+55);
         }else{
            $randstr .= chr($randnum+61);
         }
      }
      return $randstr;
   }
   
   function cleanInput($post = array()) {
       foreach($post as $k => $v){
            $post[$k] = trim(htmlspecialchars($v));
         }
         return $post;
   }
   
   
   
 
/*Pagination code*/
	 function showPagination($pagename,$tbl_name,$start,$limit,$page,$condition){
		 
		$database = new MySQLDB;
        //your table name
    // How many adjacent pages should be shown on each side?
    $adjacents = 3;
   

   
   
    /*
       First get total number of rows in data table.
       If you have a WHERE clause in your query, make sure you mirror it here.
    */
	//echo "SELECT COUNT(*) as num FROM $tbl_name $condition ";
    $query = "SELECT COUNT(*) as num FROM $tbl_name $condition ";
    $total_pages = mysqli_fetch_array($database->query($query));
    $total_pages = $total_pages['num'];
   

   
    /* Setup vars for query. */
    $targetpage = $pagename;     //your file name  (the name of this file)
                                //how many items to show per page
   


   
    /* Setup page vars for display. */
    if ($page == 0) $page = 1;                    //if no page var is given, default to 1.
    $prev = $page - 1;                            //previous page is page - 1
    $next = $page + 1;                            //next page is page + 1
    $lastpage = ceil($total_pages/$limit);        //lastpage is = total pages / items per page, rounded up.
    $lpm1 = $lastpage - 1;                        //last page minus 1
   
    /*
        Now we apply our rules and draw the pagination object.
        We're actually saving the code to a variable in case we want to draw it more than once.
    */
    $pagination = "";
    if($lastpage > 1)
    {   
        $pagination .= "<div class=\"pagination\">";
        //previous button
        if ($page > 1){
         
		    $pagination.= "<a onclick=\"setStateGet('adminTable','".$targetpage."','page=".$prev."')\">&laquo; previous</a>";
		}
        else{
            $pagination.= "<span class=\"disabled\">&laquo; previous</span>";   
		}
        //pages   
        if ($lastpage < 7 + ($adjacents * 2))    //not enough pages to bother breaking it up
        {   
            for ($counter = 1; $counter <= $lastpage; $counter++)
            {
                if ($counter == $page)
                    $pagination.= "<span class=\"current\">$counter</span>";
                else
                    $pagination.= "<a  onclick=\"setStateGet('adminTable','".$targetpage."','page=".$counter."')\">$counter</a>";                   
            }
        }
        elseif($lastpage > 5 + ($adjacents * 2))    //enough pages to hide some
        {
            //close to beginning; only hide later pages
            if($page < 1 + ($adjacents * 2))       
            {
                for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"current\">$counter</span>";
                    else
                        $pagination.= "<a   onclick=\"setStateGet('adminTable','".$targetpage."','page=".$counter."')\">$counter</a>";                   
                }
                $pagination.= "...";
                $pagination.= "<a onclick=\"setStateGet('adminTable','".$targetpage."','page=".$lpm1."')\">$lpm1</a>";
                $pagination.= "<a  onclick=\"setStateGet('adminTable','".$targetpage."','page=".$lastpage."')\">$lastpage</a>";       
            }
            //in middle; hide some front and some back
            elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
            {
                $pagination.= "<a  onclick=\"setStateGet('adminTable','".$targetpage."','page=1')\">1</a>";
                $pagination.= "<a onclick=\"setStateGet('adminTable','".$targetpage."','page=2')\">2</a>";
                $pagination.= "...";
                for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"current\">$counter</span>";
                    else
                        $pagination.= "<a onclick=\"setStateGet('adminTable','".$targetpage."','page=".$counter."')\">$counter</a>";                   
                }
                $pagination.= "...";
                $pagination.= "<a >$lpm1</a>";
                $pagination.= "<a onclick=\"setStateGet('adminTable','".$targetpage."','page=".$lastpage."')\">$lastpage</a>";       
            }
            //close to end; only hide early pages
            else
            {
                $pagination.= "<a onclick=\"setStateGet('adminTable','".$targetpage."','page=1')\">1</a>";
                $pagination.= "<a  onclick=\"setStateGet('adminTable','".$targetpage."','page=2')\">2</a>";
                $pagination.= "...";
                for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"current\">$counter</span>";
                    else
                        $pagination.= "<a  onclick=\"setStateGet('adminTable','".$targetpage."','page=".$counter."')\">$counter</a>";                   
                }
            }
        }
       
        //next button
        if ($page < $counter - 1)
            $pagination.= "<a  onclick=\"setStateGet('adminTable','".$targetpage."','page=".$next."')\">next &raquo;</a>";
        else
            $pagination.= "<span class=\"disabled\">next  &raquo;</span>";
        $pagination.= "</div>\n";       
    }   
   
   
    return $pagination;
   

}

	 function showPagination99($pagename,$tbl_name,$start,$limit,$page,$condition){
		 
		$database = new MySQLDB;
        //your table name
    // How many adjacent pages should be shown on each side?
    $adjacents = 3;
   

   
   
    /*
       First get total number of rows in data table.
       If you have a WHERE clause in your query, make sure you mirror it here.
    */
	//echo "SELECT COUNT(*) as num FROM $tbl_name $condition ";
    $query = "SELECT COUNT(*) as num FROM $tbl_name $condition ";
    $total_pages = mysqli_fetch_array($database->query($query));
    $total_pages = $total_pages['num'];
   

   
    /* Setup vars for query. */
    $targetpage = $pagename;     //your file name  (the name of this file)
                                //how many items to show per page
   


   
    /* Setup page vars for display. */
    if ($page == 0) $page = 1;                    //if no page var is given, default to 1.
    $prev = $page - 1;                            //previous page is page - 1
    $next = $page + 1;                            //next page is page + 1
    $lastpage = ceil($total_pages/$limit);        //lastpage is = total pages / items per page, rounded up.
    $lpm1 = $lastpage - 1;                        //last page minus 1
   
    /*
        Now we apply our rules and draw the pagination object.
        We're actually saving the code to a variable in case we want to draw it more than once.
    */
    $pagination = "";
    if($lastpage > 1)
    {   
        $pagination .= "<div class=\"pagination\">";
        //previous button
        if ($page > 1){
         
		    $pagination.= "<a onclick=\"setStateGet('adminTable5','".$targetpage."','page=".$prev."')\">&laquo; previous</a>";
		}
        else{
            $pagination.= "<span class=\"disabled\">&laquo; previous</span>";   
		}
        //pages   
        if ($lastpage < 7 + ($adjacents * 2))    //not enough pages to bother breaking it up
        {   
            for ($counter = 1; $counter <= $lastpage; $counter++)
            {
                if ($counter == $page)
                    $pagination.= "<span class=\"current\">$counter</span>";
                else
                    $pagination.= "<a  onclick=\"setStateGet('adminTable5','".$targetpage."','page=".$counter."')\">$counter</a>";                   
            }
        }
        elseif($lastpage > 5 + ($adjacents * 2))    //enough pages to hide some
        {
            //close to beginning; only hide later pages
            if($page < 1 + ($adjacents * 2))       
            {
                for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"current\">$counter</span>";
                    else
                        $pagination.= "<a   onclick=\"setStateGet('adminTable5','".$targetpage."','page=".$counter."')\">$counter</a>";                   
                }
                $pagination.= "...";
                $pagination.= "<a onclick=\"setStateGet('adminTable5','".$targetpage."','page=".$lpm1."')\">$lpm1</a>";
                $pagination.= "<a  onclick=\"setStateGet('adminTable5','".$targetpage."','page=".$lastpage."')\">$lastpage</a>";       
            }
            //in middle; hide some front and some back
            elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
            {
                $pagination.= "<a  onclick=\"setStateGet('adminTable5','".$targetpage."','page=1')\">1</a>";
                $pagination.= "<a onclick=\"setStateGet('adminTable5','".$targetpage."','page=2')\">2</a>";
                $pagination.= "...";
                for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"current\">$counter</span>";
                    else
                        $pagination.= "<a onclick=\"setStateGet('adminTable5','".$targetpage."','page=".$counter."')\">$counter</a>";                   
                }
                $pagination.= "...";
                $pagination.= "<a >$lpm1</a>";
                $pagination.= "<a onclick=\"setStateGet('adminTable5','".$targetpage."','page=".$lastpage."')\">$lastpage</a>";       
            }
            //close to end; only hide early pages
            else
            {
                $pagination.= "<a onclick=\"setStateGet('adminTable5','".$targetpage."','page=1')\">1</a>";
                $pagination.= "<a  onclick=\"setStateGet('adminTable5','".$targetpage."','page=2')\">2</a>";
                $pagination.= "...";
                for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"current\">$counter</span>";
                    else
                        $pagination.= "<a  onclick=\"setStateGet('adminTable5','".$targetpage."','page=".$counter."')\">$counter</a>";                   
                }
            }
        }
       
        //next button
        if ($page < $counter - 1)
            $pagination.= "<a  onclick=\"setStateGet('adminTable5','".$targetpage."','page=".$next."')\">next &raquo;</a>";
        else
            $pagination.= "<span class=\"disabled\">next  &raquo;</span>";
        $pagination.= "</div>\n";       
    }   
   
   
    return $pagination;
   

}

/*Pagination code*/
	 function showPagination2($pagename,$tbl_name,$start,$limit,$page,$condition){
		 
		$database = new MySQLDB;
        //your table name
    // How many adjacent pages should be shown on each side?
    $adjacents = 3;
   

   
   
    /*
       First get total number of rows in data table.
       If you have a WHERE clause in your query, make sure you mirror it here.
    */
    $query = "SELECT COUNT(*) as num FROM $tbl_name $condition ";
    $total_pages = mysqli_fetch_array($database->query($query));
    $total_pages = $total_pages['num'];
   

   
    /* Setup vars for query. */
    $targetpage = $pagename;     //your file name  (the name of this file)
                                //how many items to show per page
   


   
    /* Setup page vars for display. */
    if ($page == 0) $page = 1;                    //if no page var is given, default to 1.
    $prev = $page - 1;                            //previous page is page - 1
    $next = $page + 1;                            //next page is page + 1
    $lastpage = ceil($total_pages/$limit);        //lastpage is = total pages / items per page, rounded up.
    $lpm1 = $lastpage - 1;                        //last page minus 1
   
    /*
        Now we apply our rules and draw the pagination object.
        We're actually saving the code to a variable in case we want to draw it more than once.
    */
    $pagination = "";
    if($lastpage > 1)
    {   
        $pagination .= "<div class=\"pagination\">";
        //previous button
        if ($page > 1){
         
		    $pagination.= "<a onclick=\"setStateGet('adminTable2','".$targetpage."','page=".$prev."')\">&laquo; previous</a>";
		}
        else{
            $pagination.= "<span class=\"disabled\">&laquo; previous</span>";   
		}
        //pages   
        if ($lastpage < 7 + ($adjacents * 2))    //not enough pages to bother breaking it up
        {   
            for ($counter = 1; $counter <= $lastpage; $counter++)
            {
                if ($counter == $page)
                    $pagination.= "<span class=\"current\">$counter</span>";
                else
                    $pagination.= "<a  onclick=\"setStateGet('adminTable2','".$targetpage."','page=".$counter."')\">$counter</a>";                   
            }
        }
        elseif($lastpage > 5 + ($adjacents * 2))    //enough pages to hide some
        {
            //close to beginning; only hide later pages
            if($page < 1 + ($adjacents * 2))       
            {
                for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"current\">$counter</span>";
                    else
                        $pagination.= "<a   onclick=\"setStateGet('adminTable2','".$targetpage."','page=".$counter."')\">$counter</a>";                   
                }
                $pagination.= "...";
                $pagination.= "<a onclick=\"setStateGet('adminTable2','".$targetpage."','page=".$lpm1."')\">$lpm1</a>";
                $pagination.= "<a  onclick=\"setStateGet('adminTable2','".$targetpage."','page=".$lastpage."')\">$lastpage</a>";       
            }
            //in middle; hide some front and some back
            elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
            {
                $pagination.= "<a  onclick=\"setStateGet('adminTable2','".$targetpage."','page=1')\">1</a>";
                $pagination.= "<a onclick=\"setStateGet('adminTable2','".$targetpage."','page=2')\">2</a>";
                $pagination.= "...";
                for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"current\">$counter</span>";
                    else
                        $pagination.= "<a onclick=\"setStateGet('adminTable2','".$targetpage."','page=".$counter."')\">$counter</a>";                   
                }
                $pagination.= "...";
                $pagination.= "<a >$lpm1</a>";
                $pagination.= "<a onclick=\"setStateGet('adminTable2','".$targetpage."','page=".$lastpage."')\">$lastpage</a>";       
            }
            //close to end; only hide early pages
            else
            {
                $pagination.= "<a onclick=\"setStateGet('adminTable2','".$targetpage."','page=1')\">1</a>";
                $pagination.= "<a  onclick=\"setStateGet('adminTable2','".$targetpage."','page=2')\">2</a>";
                $pagination.= "...";
                for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"current\">$counter</span>";
                    else
                        $pagination.= "<a  onclick=\"setStateGet('adminTable2','".$targetpage."','page=".$counter."')\">$counter</a>";                   
                }
            }
        }
       
        //next button
        if ($page < $counter - 1)
            $pagination.= "<a  onclick=\"setStateGet('adminTable2','".$targetpage."','page=".$next."')\">next &raquo;</a>";
        else
            $pagination.= "<span class=\"disabled\">next  &raquo;</span>";
        $pagination.= "</div>\n";       
    }   
   
   
    return $pagination;
   
}



/*End Pagination*/

function sendsms($user,$pass,$msg,$sender,$mobile){

  global $database;

 


	$mobile = substr($mobile,-10);

	// Textlocal account details
	$username = 'entrolabsindia@gmail.com';
	$hash = $pass;
	
	// Message details
	$numbers = array($mobile);
	$sender = urlencode($sender);
	$message = rawurlencode($msg);
 
	$numbers = implode(',', $numbers);
 
	// Prepare data for POST request
  	$data = array('username' => $username, 'apiKey' => 'ftlb3cldZs4-TIkUEBnUpgbwQHD7xFlr4wGX7iMXMB', 'numbers' => $numbers, "sender" => $sender, "message" => $message);
 
    
	// Send the POST request with cURL
	$ch = curl_init('https://api.textlocal.in/send/');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$response = curl_exec($ch);
	curl_close($ch);
	

// $database->query("INSERT INTO mlog VALUES(NULL, 'TEST SMS: ".$msg." - ".$mobile."' , '".$response."', '".time()."')");	


	// Process your response here
	return $response;

}



  /*imageResize - Resizes images of all types to the specified dimentions.
  Preserves image alpha channel information also*/
  
  function image_resize($src, $dst, $width, $height, $crop=0){

  if(!list($w, $h) = getimagesize($src)) return "Unsupported picture type!";

  $type = strtolower(substr(strrchr($src,"."),1));
  if($type == 'jpeg') $type = 'jpg';
  switch($type){
    case 'bmp': $img = imagecreatefromwbmp($src); break;
    case 'gif': $img = imagecreatefromgif($src); break;
    case 'jpg': $img = imagecreatefromjpeg($src); break;
    case 'png': $img = imagecreatefrompng($src); break;
    default : return "Unsupported picture type!";
  }

  // resize
  if(is_array($crop)){
	 // $_SESSION['crop'] = 'Is here.. reading crop array';
	   $ratio = max($width/$w, $height/$h);
	   
   if($w < $width or $h < $height){
	//$_SESSION['crop'].= "Picture is too small!".$ratio;
      
   }
   
    $h = $crop['height'];
    $x = $crop['x'];
    $w = $crop['width'];
	$y= $crop['y'];
	
  }
  else{
    if($w < $width and $h < $height) return "Picture is too small!";
    $ratio = min($width/$w, $height/$h);
    $width = $w * $ratio;
    $height = $h * $ratio;
    $x = 0;
	$y=0;
  }

  $new = imagecreatetruecolor($width, $height);

  // preserve transparency
  if($type == "gif" or $type == "png"){
    imagecolortransparent($new, imagecolorallocatealpha($new, 0, 0, 0, 127));
    imagealphablending($new, false);
    imagesavealpha($new, true);
  }

// $_SESSION['crop'].= "x:".$x."--y:".$y."--W:".$w."--H:".$h."--Width:".$width."--Height:".$height;
  imagecopyresampled($new, $img, 0, 0, $x, $y, $width, $height, $w, $h);

  switch($type){
    case 'bmp': imagewbmp($new, $dst); break;
    case 'gif': imagegif($new, $dst); break;
    case 'jpg': imagejpeg($new, $dst); break;
    case 'png': imagepng($new, $dst); break;
  }
  return true;
}


 //Functions for all Includes 
 
 function commonAdminJS(){
	 ?>
    <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
      <script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/modernizr.min.js"></script>
   
 <script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/nprogress.js"></script>  
<script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/ajaxfunction.js"></script> 
 

   <?php
 }
 
 function commonJS(){
   ?>
     <!-- js placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/jquery.js"></script>
   <!-- <script type="text/javascript" src="<?php echo SECURE_PATH;?>assets1/js/bootstrap.js"></script>-->
<script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/nprogress.js"></script>  
<script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/ajaxfunction.js"></script> 

<!-- Google Analytics -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-73552792-1', 'auto');
ga('send', 'pageview');
</script>
<!-- End Google Analytics -->  
<!--<script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/jquery-ui-1.10.1.custom.min.js"></script>-->
   <?php
 }
 
 
 function commonFooterAdminJS(){
	 
 ?>
<!-- Google Analytics -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-73552792-1', 'auto');
ga('send', 'pageview');
</script>

<script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
          <script src="<?php echo SECURE_PATH;?>assets/js/detect.js"></script>
        <script src="<?php echo SECURE_PATH;?>assets/js/fastclick.js"></script>
        <script src="<?php echo SECURE_PATH;?>assets/js/jquery.slimscroll.js"></script>
        <script src="<?php echo SECURE_PATH;?>assets/js/jquery.blockUI.js"></script>
        <script src="<?php echo SECURE_PATH;?>assets/js/waves.js"></script>
        <script src="<?php echo SECURE_PATH;?>assets/js/wow.min.js"></script>
        <script src="<?php echo SECURE_PATH;?>assets/js/jquery.nicescroll.js"></script>
        <script src="<?php echo SECURE_PATH;?>assets/js/jquery.scrollTo.min.js"></script>

<!-- <script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/jquery-ui-1.9.2.custom.min.js"></script>
--><script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/upload/fileuploader.js"></script>
<script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/jquery-blink.js"></script>

    <script src="<?php echo SECURE_PATH;?>assets/autoSuggestv14/jquery.autoSuggest.minified.js"></script>
 
    <script src="<?php echo SECURE_PATH;?>assets/js/jquery.newsTicker.min.js"></script>

 <script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/jquery-ui-1.9.2.custom.min.js"></script>   <!-- sliders, filters, carousels -->
    <script src='<?php echo SECURE_PATH;?>assets/js/jquery.flexslider-min.js'></script>
  <script src='<?php echo SECURE_PATH;?>assets/js/jquery.ticker.js'></script>

  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBs3KbsLRIv_XDbz4N4o0SzMW_-mOAE8Ro&libraries=drawing,places"
        ></script>

<script src='<?php echo SECURE_PATH;?>assets/summernote/dist/summernote.min.js'></script>


        <script src="<?php echo SECURE_PATH;?>assets/js/jquery.core.js"></script>
        <script src="<?php echo SECURE_PATH;?>assets/js/jquery.app.js"></script>
  
 <?php
 
 }
 
 function commonFooterJS(){
 ?>

 
<script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/upload/fileuploader.js"></script>
<script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/jquery-ui-1.9.2.custom.min.js"></script>
<script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/jquery-blink.js"></script>

    <script src="<?php echo SECURE_PATH;?>theme/js/jquery.scrollTo.min.js"></script>
    <script src="<?php echo SECURE_PATH;?>theme/js/jquery.nicescroll.js" type="text/javascript"></script>
  
    <script src="<?php echo SECURE_PATH;?>theme/js/autoSuggestv14/jquery.autoSuggest.minified.js"></script>

    <script src="<?php echo SECURE_PATH;?>theme/js/jquery-migrate-1.2.1.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo SECURE_PATH;?>theme/js/respond.min.js" ></script>
 <!--right slidebar-->
    <script src="<?php echo SECURE_PATH;?>theme/js/jquery.newsTicker.min.js"></script>

    <!--right slidebar-->
    <script src="<?php echo SECURE_PATH;?>theme/js/slidebars.min.js"></script>
    
    
    <!-- sliders, filters, carousels -->
    <script src='<?php echo SECURE_PATH;?>theme/js/jquery.flexslider-min.js'></script>
  <script src='<?php echo SECURE_PATH;?>theme/js/jquery.ticker.js'></script>

  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBs3KbsLRIv_XDbz4N4o0SzMW_-mOAE8Ro&libraries=drawing,places"
        ></script>

     <!--common script for all pages-->
    <script src="<?php echo SECURE_PATH;?>theme/js/common-scripts.js"></script>
 <?php
 }
 
 
 
 
 function commonAdminCSS(){
	 
?>

  <link href="<?php echo SECURE_PATH;?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SECURE_PATH;?>assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SECURE_PATH;?>assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SECURE_PATH;?>assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SECURE_PATH;?>assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SECURE_PATH;?>assets/css/responsive.css" rel="stylesheet" type="text/css" />

     <!--external css--> 
 <link href="<?php echo SECURE_PATH;?>assets/autoSuggestv14/autoSuggest.css" rel="stylesheet" />
  <link type="text/css" rel="stylesheet" href="<?php echo SECURE_PATH;?>assets/css/nprogress.css" />  
    
    <!-- Custom styles for this template -->
   
<link type="text/css" rel="stylesheet" href="<?php echo SECURE_PATH;?>assets/js/upload/fileuploader.css" />

  <link href="<?php echo SECURE_PATH;?>assets/css/yamm.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo SECURE_PATH;?>assets/css/flexslider.css" type="text/css">
 <link rel="stylesheet" href="<?php echo SECURE_PATH;?>assets/css/ticker-style.css" type="text/css">
		<link rel="stylesheet" type="text/css" href="<?php echo SECURE_PATH;?>theme/css/flick/jquery-ui-1.8.16.custom.css" />
<link type="text/css" rel="stylesheet" href="<?php echo SECURE_PATH;?>assets/summernote/dist/summernote.css" />
 
<?php

 }
 
 
 function commonCSS(){
?>

 <!-- Bootstrap core CSS -->
    <link href="<?php echo SECURE_PATH;?>theme/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo SECURE_PATH;?>theme/css/bootstrap-reset.css" rel="stylesheet">
      <link href="<?php echo SECURE_PATH;?>theme/fonts/fontello/css/fontello.css" rel="stylesheet" type="text/css" media="all"/>
     <link href="<?php echo SECURE_PATH;?>theme/assets/yamm/yamm.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo SECURE_PATH;?>theme/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
 <link href="<?php echo SECURE_PATH;?>theme/js/autoSuggestv14/autoSuggest.css" rel="stylesheet" />
  <link type="text/css" rel="stylesheet" href="<?php echo SECURE_PATH;?>theme/css/nprogress.css" />  
    
      <!--right slidebar-->
      <link href="<?php echo SECURE_PATH;?>theme/css/slidebars.css" rel="stylesheet">

    
    <!-- Custom styles for this template -->
    <link href="<?php echo SECURE_PATH;?>theme/css/style.css" rel="stylesheet">
    <link href="<?php echo SECURE_PATH;?>theme/css/style-responsive.css" rel="stylesheet" />

<link rel="stylesheet" type="text/css" href="<?php echo SECURE_PATH;?>theme/css/flick/jquery-ui-1.10.1.custom.css" />
<link type="text/css" rel="stylesheet" href="<?php echo SECURE_PATH;?>theme/js/upload/fileuploader.css" />


    <link rel="stylesheet" href="<?php echo SECURE_PATH;?>theme/css/flexslider.css" type="text/css">
 <link rel="stylesheet" href="<?php echo SECURE_PATH;?>theme/css/ticker-style.css" type="text/css">

 
 <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
<?php
}

function commonUserCSS(){
?>

 <!-- Royal Preloader CSS -->
	<link rel="stylesheet" type="text/css" href="<?php echo USER_PATH;?>css/royal_preloader.css">

	<!-- jQuery Files -->
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

	<!-- Royal Preloader -->
	<script type="text/javascript" src="<?php echo USER_PATH;?>js/royal_preloader.min.js"></script>

	<!-- Revolution Slider CSS -->
	<link rel="stylesheet" type="text/css" href="<?php echo USER_PATH;?>revolution/css/settings.css">
	<link rel="stylesheet" type="text/css" href="<?php echo USER_PATH;?>revolution/css/layers.css">
		
	<!-- Revolution Slider Navigation CSS -->
	<link rel="stylesheet" type="text/css" href="<?php echo USER_PATH;?>revolution/css/navigation.css">

	<!-- Stylesheets -->
	<link href="<?php echo USER_PATH;?>css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo USER_PATH;?>css/style.css" rel="stylesheet" title="main-css">
	<link href="<?php echo USER_PATH;?>css/bootstrap-social.css" rel="stylesheet">
	<link href="<?php echo USER_PATH;?>css/animate.min.css" rel="stylesheet">
	<link href="<?php echo USER_PATH;?>css/owl.carousel.css" rel="stylesheet" >
	<link href="<?php echo USER_PATH;?>css/jquery.snippet.css" rel="stylesheet">
	<link href="<?php echo USER_PATH;?>css/buttons.css" rel="stylesheet">
    
     <link rel="alternate stylesheet" type="text/css" href="<?php echo USER_PATH;?>css/colors/green.css" title="green">
	 <link rel="alternate stylesheet" type="text/css" href="<?php echo USER_PATH;?>css/width-boxed.css" title="width-boxed">

	<!-- Icon Fonts -->
	<link href='<?php echo USER_PATH;?>css/ionicons.min.css' rel='stylesheet' type='text/css'>
	<link href='<?php echo USER_PATH;?>css/font-awesome.css' rel='stylesheet' type='text/css'>

	<!-- Magnific Popup -->
	<link href='<?php echo USER_PATH;?>css/magnific-popup.css' rel='stylesheet' type='text/css'>
<?php

}
  


function uiCSS(){
?>
       <link rel="stylesheet" type="text/css" href="<?php echo SECURE_PATH;?>assets/vendor/owl-slider.css"/>
        <link rel="stylesheet" type="text/css" href="<?php echo SECURE_PATH;?>assets/vendor/settings.css"/>
        <link rel="stylesheet" type="text/css" href="<?php echo SECURE_PATH;?>assets/css/bootstrap.css"/>
        <link rel="stylesheet" type="text/css" href="<?php echo SECURE_PATH;?>assets/css/style.css"/>
        <link rel="shortcut icon" href="<?php echo SECURE_PATH;?>assets/images/favicon.png" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.0/jquery-ui.css"/>


    <style>
        /* Click the image one by one to see the different layout */

/* Owl Carousel */

.owl-prev {
  background: url('https://res.cloudinary.com/milairagny/image/upload/v1487938188/left-arrow_rlxamy.png') left center no-repeat;
  height: 54px;
  position: absolute;
  top: 50%;
  width: 27px;
  z-index: 1000;
  left: 2%;
  cursor: pointer;
  color: transparent;
  margin-top: -27px;
}

.owl-next {
  background: url('https://res.cloudinary.com/milairagny/image/upload/v1487938220/right-arrow_zwe9sf.png') right center no-repeat;
  height: 54px;
  position: absolute;
  top: 50%;
  width: 27px;
  z-index: 1000;
  right: 2%;
  cursor: pointer;
  color: transparent;
  margin-top: -27px;
}

.owl-prev:hover,
.owl-next:hover {
  opacity: 0.5;
}


/* Owl Carousel */


/* Popup Text */

.white-popup-block {
  background: #FFF;
  padding: 20px 30px;
  text-align: left;
  max-width: 650px;
  margin: 40px auto;
  position: relative;
}

.popuptext {
  display: table;
}

.popuptext p {
  margin-bottom: 10px;
}

.popuptext span {
  font-weight: bold;
  float: right;
}

.btn{
  height:32px;	
}

.modal.fade .modal-dialog{
 top:14%;	
}
/* Popup Text */

    </style>
<?php	
}



function uiJS(){
?>
    <script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/jquery.themepunch.revolution.min.js"></script>
    <script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/jquery.themepunch.plugins.min.js"></script>
    <script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/engo-plugins.js"></script>
   <!-- <script type="text/javascript" src="//maps.googleapis.com/maps/api/js"></script>-->
      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBs3KbsLRIv_XDbz4N4o0SzMW_-mOAE8Ro&libraries=drawing,places"
        ></script>
    <script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/map-icons.js"></script>    
    <script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/store.js"></script>
<script src="//code.jquery.com/ui/1.11.0/jquery-ui.js"></script>




<script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/nprogress.js"></script>  
<script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/ajaxfunction.js"></script> 



<!-- Google Analytics -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-73552792-1', 'auto');
ga('send', 'pageview');
</script>


<?php	
}

function villageNav($panchayat){
	
?>

<div class="container" id="textDiv">
                    <div class="box float-left">
                        
<div class="col-sm-2 col-xs-2 text_center auto_img">
                <span class="helper"></span>
                 <img src="theme/img/panchayat_wlogo.png"   />
                 </div>
                        

                        <!--- mega menu -->
                        
                        <nav class="mega-menu">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <ul class="nav navbar-nav right" id="navbar">
                                <!--<li class="level1 active hover-menu">-->
                                <li class="level1  hover-menu">
                                    <a  href="home.php?panchayat=<?php echo $panchayat;?>" title="Home">Home</a>                                   
                                </li>
                                <li class="level1  hover-menu">
                                    <a   href="about.php?panchayat=<?php echo $panchayat;?>" title="Village">Village</a>
                                </li>
                                <li class="level1 hover-menu">
                                    <a href="#" title="E-Services">E-Services</a>
									
									
									 <ul class="menu-level-1 list-menu">
                            <li class="level2"><a href="pay_tax.php?panchayat=<?php echo $_REQUEST['panchayat'];?>&taxtype=1">Taxes &amp; Non-Taxes</a>
                                
                            </li>
                            <li class="level2"><a href="property_certificate.php?panchayat=<?php echo $_REQUEST['panchayat'];?>">Certificates</a>
                 
                            </li> 
							  <li class="level2"><a href="private_tap.php?panchayat=<?php echo $_REQUEST['panchayat'];?>">Applications</a>
                                
                            </li> 
                        </ul>	
                                </li>
                                <li class="level1 hover-menu">
                                    <a href="#" title="Directory">Directory</a>																		    
									<ul class="menu-level-1 list-menu">
                           <li class="level2"><a href="peoples_representatives.php?panchayat=<?php echo $_REQUEST['panchayat'];?>">Elected Wing</a></li>
                           <li class="level2"><a href="functional_committee.php?panchayat=<?php echo $_REQUEST['panchayat'];?>">Functional Committee</a></li>
                            <li class="level2"><a href="public_servants.php?panchayat=<?php echo $_REQUEST['panchayat'];?>">Panchayat Staff</a></li>
                            <li class="level2"><a href="nonpanchayat.php?panchayat=<?php echo $_REQUEST['panchayat'];?>">Non-Panchayat Staff</a></li>
                            <li class="level2"><a href="yellow_pages.php?panchayat=<?php echo $_REQUEST['panchayat'];?>">Yellow Pages</a></li>
                        </ul>

                                </li>
                                <li class="level1 hover-menu">
                                    <a href="gallery.php?panchayat=<?php echo $_REQUEST['panchayat'];?>" title="Gallery">Gallery</a>
                                </li>
                                <li class="level1 hover-menu">
                                    <a href="faq.php?panchayat=<?php echo $_REQUEST['panchayat'];?>" title="FAQ's">FAQ's</a>
                                </li>
                                <li class="level1 hover-menu">
                                    <a href="contact.php?panchayat=<?php echo $_REQUEST['panchayat'];?>" title="Contact Us">Contact Us</a>
                                </li>  
							</ul>								
                        </nav>
                        <!-- mega menu end -->
                    </div>                
                    </div>





<?php	
	
	
	
	
}



function taxServices($active,$panchayat,$taxtype){
?>
<ul class="nav nav-pills nav-stacked">
  <li <?php if($active == 1){?>class="active" <?php }?>><a href="pay_tax.php?panchayat=<?php echo $panchayat;?>&taxtype=<?php echo $taxtype;?>"><i class="fa fa-hand-o-right"></i> 
  
  <?php
    if($taxtype == 1 || $taxtype == 2 || $taxtype == 3){
  ?>
  Pay Your Tax
 <?php
	}
	else    if($taxtype == 4 || $taxtype == 6){

	?>
      Pay Your Fee
    <?php	
	}
	else    if($taxtype == 5){

	?>
      Pay Your Deposit
    <?php	
	}

 ?>  
  
  </a></li>
  
  <li <?php if($active == 2){?>class="active" <?php }?>><a href="tax_dues.php?panchayat=<?php echo $panchayat;?>&taxtype=<?php echo $taxtype;?>"><i class="fa fa-hand-o-right"></i> 
  
  
  <?php
    if($taxtype == 1 || $taxtype == 2 || $taxtype == 3){
  ?>
  Know Your Tax Due
 <?php
	}
	else    if($taxtype == 4 || $taxtype == 6){

	?>
       Know Your Fee Due
    <?php	
	}
	else    if($taxtype == 5){

	?>
      Know Your  Due
    <?php	
	}

 ?>  
 
  
  
  </a></li>
  <li <?php if($active == 3){?>class="active" <?php }?>><a  href="tax_list.php?panchayat=<?php echo $panchayat;?>&taxtype=<?php echo $taxtype;?>"><i class="fa fa-hand-o-right"></i> 
  <?php
    if($taxtype == 1 ){
  ?>
  Know Your Property Tax
 <?php
	}
	else if($taxtype == 2 || $taxtype == 3){
?>
  Know Your Tax
 <?php
		
	}
	else    if($taxtype == 4 || $taxtype == 6){

	?>
      Know Your Fee Details
    <?php	
	}
	else    if($taxtype == 5){

	?>
      Know Your  Due Details
    <?php	
	}

 ?>  
 
  </a></li>
  <?php
     if($taxtype != 5 && $taxtype != 6){  
  ?>
  <li <?php if($active == 4){?>class="active" <?php }?>><a  href="tax_calculator.php?panchayat=<?php echo $panchayat;?>&taxtype=<?php echo $taxtype;?>"><i class="fa fa-hand-o-right"></i> Tax Calculator</a></li>
  <?php
	 }
  ?>
   <li <?php if($active == 5){?>class="active" <?php }?>><a href="dcb.php?panchayat=<?php echo $panchayat;?>&taxtype=<?php echo $taxtype;?>"><i class="fa fa-hand-o-right"></i> DCB</a></li>
</ul>
<?php	
	
}


//check trough id
function checkId($trough,$panchayat)
{
global $database;
    $t=$database->query("select id from swm_troughs where panchayat='".$panchayat."' and trough_id='".$trough."'");
if(mysqli_num_rows($t)>0)
{
  $new_trough=$trough++;
return $this->checkId($new_trough,$panchayat);
}
return $trough;
    }

//function to get valid time
function getValidTime($district)
{
    global $database;
    $r=$database->query("select valid_time from valid_times where district='".$district."' and year='".date('Y')."'");
    if(mysqli_num_rows($r)>0)
    {
    $row=mysqli_fetch_array($r);
    return $row['valid_time'];
    }
}


function villageFooter($panchayat){
	?>
    
    <div class="container">
                <div class="row" id="textDiv">
                    <div class="col-md-3">
                        <a class="logo-footer space-30" href="#" title="logo"><img src="assets/images/logo-footer.png" width="115" alt="Logo-footer"></a>
                        <p class="space-30">Step towards Smart Andhra Pradesh initiative focuses on improved resource-use efficiency, empowered local self-governance, access to assured basic amenities and responsible individual and community behavior to build a vibrant and happy society..</p>
                        <!--<div class="widget footer-info">
                            <h3 class="widget-title">main office</h3>
                            <ul>
                                <li><i class="fa fa-home"></i> 121 King Street, Melbourne Victoria 3000 Australia</li>
                                <li><i class="fa fa-phone-square"></i> 070-7782-9137</li>
                                <li><i class="fa fa-fax"></i> 070-7782-9137</li>
                                <li><i class="fa fa-envelope"></i> <a href="mailto:" title="link">contact@dailyplus.com</a></li>
                            </ul>
                        </div>-->
                        <!-- End widget -->
                        <div class="social">
                            <a href="#" title="title"><i class="fa fa-facebook"></i></a>
                            <a href="#" title="title"><i class="fa fa-twitter"></i></a>
                            <a href="#" title="title"><i class="fa fa-google-plus"></i></a>
                            <a href="#" title="title"><i class="fa fa-rss"></i></a>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="widget recent-posts">
                            <h3 class="widget-title">App Links</h3>
                            <!--<ul>
                                <li class="item-private ">
                                    <div class="images">
                                        <a href="#" title="images"><img class="img-responsive" src="assets/images/footer/recent/1.png" alt="images"></a>
                                    </div>
                                    <div class="text">
                                        <h3 class="title"><a href="#" title="title">Smart Village-Smart Ward, towards Smart AP</a></h3>
                                        <div class="tags">
                                            <p class="date"><i class="fa fa-clock-o"></i>Feb 06,2017</p>
                                            <a class="comment" href="#" title="comment"><i class="fa fa-comments"></i>10</a>
                                        </div>
                                    </div>
                                  
                                </li>
                                <li class="item-private ">
                                    <div class="images">
                                        <a href="#" title="images"><img class="img-responsive" src="assets/images/footer/recent/2.png" alt="images"></a>
                                    </div>
                                    <div class="text">
                                        <h3 class="title"><a href="#" title="title">AP Govt focus on enhancing the Quality of Life</a></h3>
                                        <div class="tags">
                                            <p class="date"><i class="fa fa-clock-o"></i>Jan 06,2017</p>
                                            <a class="comment" href="#" title="comment"><i class="fa fa-comments"></i>10</a>
                                        </div>
                                    </div>
                                 
                                </li>
                                
                            </ul>-->
                            <div class="box">
							<p><a href="https://play.google.com/store/apps/details?id=com.pris.citizenapp" title="social" target="_blank"><img src="<?php echo SECURE_PATH; ?>assets/images/playstore.png" style="width:48px; height:48px;"  /><span style="padding-left:5px; color:#FFF;"> Download From Playstore</span></a></p>
                        <br/>
							<p ><a onClick="$('#iosModel').modal('show');"  title="social" ><img src="<?php echo SECURE_PATH; ?>assets/images/ios.png" style="width:48px; height:48px;"  /><span style="padding-left:5px; color:#FFF;"> Download From Appstore</span></a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="widget categories">
                            <h3 class="widget-title">QUICK LINKS</h3>
                            <ul>

                               <!-- <li><a href="#" title="social">Online Services</a></li>
                                <li><a href="#" title="Business">Recruitment</a></li>
                                <li><a href="#" title="Gaming">Tenders</a></li>
                                <li><a href="#" title="Technology">Town Planning</a></li>
                                <li><a href="#" title="Sports">Budget</a></li>
                                <li><a href="#" title="fashion">Elected Wing</a></li>
                                <li><a href="#" title="Music">Employee Details</a></li>--> 
                                
                                <li><a href="dcb.php?panchayat=<?php echo $_REQUEST['panchayat'];?>&taxtype=1" title="DCB">DCB</a></li>
                                <li><a href="grievance.php?panchayat=<?php echo $_REQUEST['panchayat'];?>" title="Register a Complaint">Register a Complaint</a></li>
                                <li><a href="property_certificate.php?panchayat=<?php echo $_REQUEST['panchayat'];?>" title="House Valuation Certificate">House Valuation Certificate</a></li>
                                <li><a href="#" title="Marriage Certificate">Marriage Certificate</a></li>
                                <li><a href="#" title="Building Plan">Building Plan</a></li>
                                <li><a href="private_tap.php?panchayat=<?php echo $_REQUEST['panchayat'];?>" title="Private Tap">Private Tap</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="widget flick-photo">
                            <h3 class="widget-title">For Support Contact</h3>
                            <div class="box">
							<h3>Command Control Centre</h3>
							<p>Department of Panchayat Raj & Rural Development</p>
							<p><i class="fa fa-mobile"></i> +91-9573-199-199</p>
                            <p><i class="fa fa-envelope"></i> cio-prrd@ap.gov.in</p>
							<!--<p><i class="fa fa-mobile"></i> +91-9493742440</p>
							<p><i class="fa fa-phone"></i> +91-08818-277242</p>-->
                               <!--  <li><a href="#" title="flickr photo"><img class="img-responsive" src="assets/images/footer/flick/1.jpg" alt="images"></a></li>
                                <li><a href="#" title="flickr photo"><img class="img-responsive" src="assets/images/footer/flick/2.jpg" alt="images"></a></li>
                                <li><a href="#" title="flickr photo"><img class="img-responsive" src="assets/images/footer/flick/3.jpg" alt="images"></a></li>
                                <li><a href="#" title="flickr photo"><img class="img-responsive" src="assets/images/footer/flick/4.jpg" alt="images"></a></li>
                                <li><a href="#" title="flickr photo"><img class="img-responsive" src="assets/images/footer/flick/5.jpg" alt="images"></a></li>
                                <li><a href="#" title="flickr photo"><img class="img-responsive" src="assets/images/footer/flick/6.jpg" alt="images"></a></li>
                                <li><a href="#" title="flickr photo"><img class="img-responsive" src="assets/images/footer/flick/7.jpg" alt="images"></a></li>
                                <li><a href="#" title="flickr photo"><img class="img-responsive" src="assets/images/footer/flick/8.jpg" alt="images"></a></li>
                                <li><a href="#" title="flickr photo"><img class="img-responsive" src="assets/images/footer/flick/9.jpg" alt="images"></a></li> -->
                            </div>                           
                        </div>
                    </div>
                </div>
                <!-- End row -->
            </div>
            <!-- End container -->
            <div class="footer-bottom" id="textDiv">
                <div class="container">
                    <!-- <p class="float-left">Copyright &copy; 2017 <a href="#" title="EngoTheme">AP Panchayat Raj</a> - All rights reserved.</p> -->
					<p class="float-left">2017 &copy; PRIS.AP.GOV.IN Technology Partner <a href="index.html" title="Panchayat Raj">Entro Labs®</a></p>
                    <div class="float-right align-right">
                        <ul class="menu-footer">
                            <li><a href="terms.php" title="Term">Term</a></li>
                            <li><a href="privacy.php" title="Privacy">Privacy</a></li>
                            <li><a href="grievance_status.php?panchayat=<?php echo $_REQUEST['panchayat'];?>" title="Complaint">Complaint</a></li>                          
                            <li><a href="contact.php?panchayat=<?php echo $_REQUEST['panchayat'];?>" title="Contact">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>


<div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="iosModel" class="modal fade">
              <div class="modal-dialog">
                  <div class="modal-content">
                      <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                          <h4 class="modal-title">Coming Soon</h4>
                      </div>
                      <div class="modal-body" id="modal_body">
                      
                      
                      
                          
                          <br />
                      </div>
                  </div>
              </div>
          </div>

<?php
}

function panchayatSelection(){
	
	global $database;
	
	if(isset($_REQUEST['panchayat'])){
			
	$p_sel = $database->query("SELECT * FROM global_panchayats WHERE panchayat_id = '".$_REQUEST['panchayat']."'");


$panchayat = mysqli_fetch_array($p_sel);
	}
?>

<div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="panchayatModel" class="modal fade">
              <div class="modal-dialog">
                  <div class="modal-content">
                      <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                          <h4 class="modal-title">Select Panchayat</h4>
                      </div>
                      <div class="modal-body" id="modal_body">
                      
                      
                      <form role="form">
                         <div class="row">
                         <div class="col-sm-4 form-group">
                                
                                <label for="district">District</label><br />
                                <select name="district" class="form-control" id="district"    
    onchange="setStateGet('mandal','<?php echo SECURE_PATH;?>login_process.php','filterMandal=1&district='+$(this).val());setStateGet('panchayat','<?php echo SECURE_PATH;?>login_process.php','filterPanchayat=1&district='+$(this).val());"   >
<option value="0">Select District</option>
<?php
  $data_sel = $database->query("SELECT * FROM global_districts");
  
  if(mysqli_num_rows($data_sel)){
	 while($data = mysqli_fetch_array($data_sel)) {
		  echo '<option value="'.$data['uid'].'" ';
		   if(isset($_REQUEST['panchayat'])){
			   
			   if($panchayat['district'] == $data['uid']){
				  echo ' selected="selected"';   
			   }
			   
		   }
		  echo '>'.ucwords($data['district']).'</option>'; 
	 }
  }
?>

 
</select>
                            </div>
                            
                            
                            <div class="col-sm-4 form-group">
                                
                                <label for="mandal">Mandal</label><br />
                                <select name="mandal" class="form-control" id="mandal"    
    onchange="setStateGet('panchayat','<?php echo SECURE_PATH;?>login_process.php','filterPanchayat=1&mandal='+$(this).val()); "   >
<option value="0">Select Mandal</option>
<?php
  $data_sel = $database->query("SELECT * FROM global_mandals");
  
  if(mysqli_num_rows($data_sel)){
	 while($data = mysqli_fetch_array($data_sel)) {
		  echo '<option value="'.$data['uid'].'" ';
		   if(isset($_REQUEST['panchayat'])){
			   
			   if($panchayat['mandal'] == $data['uid']){
				  echo ' selected="selected"';   
			   }
			   
		   }
		  echo '>'.ucwords($data['mandal']).'</option>'; 
	 }
  }
?>

 
</select>
                            </div>
                            <div class="col-sm-4 form-group">
                             <label for="panchayat">Panchayat</label>
<br />
   <select name="panchayat" class="form-control" id="panchayat"    onchange="window.location = 'home.php?panchayat='+$(this).val();">
 <option value="">Select Panchayat</option> 
<?php
  $data_sel = $database->query("SELECT * FROM global_panchayats");
  
  if(mysqli_num_rows($data_sel)){
	 while($data = mysqli_fetch_array($data_sel)) {
		  echo '<option value="'.$data['panchayat_id'].'" ';
		    if(isset($_REQUEST['panchayat'])){
			   
			   if($_REQUEST['panchayat'] == $data['panchayat_id']){
				  echo ' selected="selected"';   
			   }
			   
		   }
		  echo '>'.ucwords($data['panchayat']).'</option>'; 
	 }
  }
?>

 
</select>
                            
                            </div> 
                            </div>
                           
                          </form>
                          
                          <br />
                      </div>
                  </div>
              </div>
          </div>

<?php	
	
}


function topWrapper(){
	global $database;
	$p_sel = $database->query("SELECT * FROM global_panchayats WHERE panchayat_id = '".$_REQUEST['panchayat']."'");


$panchayat = mysqli_fetch_array($p_sel);



$admin_sel = $database->query("SELECT * FROM admin_links");

$admin_link  = mysqli_fetch_array($admin_sel);


$social_sel = $database->query("SELECT * FROM social_links WHERE panchayat = '".$_REQUEST['panchayat']."'");

if(mysqli_num_rows($social_sel) > 0){
$social_link  = mysqli_fetch_array($social_sel);
}


?>
<div class="header-row space-20" style="min-height:40px;" id="textDiv">
                    <div class="container ">

                   <div class="col-md-2 col-sm-2 col-xs-8 social_links text-left">         
                            <?php
			  if(mysqli_num_rows($social_sel) > 0){
				if(strlen($social_link['facebook'])>0) 
				{ ?>
				
				              <a href="<?php echo $social_link['facebook'];?>" target="_blank"><i class="fa fa-facebook"></i></a>

				<?php }else {
			  } if(strlen($social_link['twitter'])>0)  { ?>
				                <a href="<?php echo $social_link['twitter'];?>" target="_blank"><i class="fa fa-twitter"></i></a>

				  
				 <?php  } else {  } ?>
              <?php
			  }
			  ?>
              <?php
              if(strlen($admin_link['youtube'])>0) {  ?>
              <a href="<?php echo $admin_link['youtube'];?>" target="_blank"><i class="fa fa-youtube"></i></a>
             <?php } else { }
             if(strlen($admin_link['android'])>0) {  ?>
              <a href="<?php echo $admin_link['android'];?>" target="_blank"><i class="fa fa-android"></i></a>
              <?php } else { }
			  if(strlen($admin_link['ios'])>0) {  ?>
              <a href="<?php echo $admin_link['ios'];?>" target="_blank"><i class="fa fa-apple"></i></a> 
              <?php } else { } ?>      
                       </div>

                        <div class="col-md-2 col-sm-2 col-xs-4">
                           
                            <div class="content sec-footerlist-cnt">
                                <a href="javascript:;" class="changer" id="text_resize_decrease" target="_self"><sup>-</sup>A</a>
                                <a href="javascript:;" class="changer active" id="text_resize_reset" target="_self">A</a>
                                <a href="javascript:;" class="changer" id="text_resize_increase" target="_self"><sup>+</sup>A</a>                               
                            </div>
                        </div>
                        <div class="col-md-4 head-text col-sm-4 col-xs-12">
						<a href="#" onClick="$('#panchayatModel').modal('show');"><img src="assets/images/location-trade.png" width="18">
							<h3> <?php echo ucwords($panchayat['panchayat']); ?> Grama  Panchayat</h3></a>
						</div>
              <div class="col-md-4 col-sm-4 col-xs-12 links text-right">                            
								 <form class="search-form col-md-9 col-sm-6 col-xs-6" action="#" method="post" accept-charset="utf-8">
                                <!--<input type="text" class="" title="Sign up for our newsletter" id="newsletter" name="email">
                                <button class="button" title="Subscribe" type="submit"><i class="fa fa-search"></i></button>-->
                            </form>
                                <div class="login-div">                                    
                                    <a href="<?php echo SECURE_PATH; ?>admin/">Login &nbsp;&nbsp;<img src="assets/images/user-icon.png" style="width:18px;"></a>
                                     
                                                 
                                </div>
             </div>
                </div>

 </div>          
            
              
      

<?php	
	
	
	

}




function villageHeader(){
	
	global $database;
	$p_sel = $database->query("SELECT * FROM global_panchayats WHERE panchayat_id = '".$_REQUEST['panchayat']."'");


$panchayat = mysqli_fetch_array($p_sel);
?>
                   
             
                 
    
                 
             
             
            <?php $this->villageNav($panchayat['panchayat_id']);?>
             
             

<?php	
	
	
	
}



function floorToFraction($number, $denominator = 1)
{
    $x = $number * $denominator;
    $x = floor($x);
    $x = $x / $denominator;
    return $x;
}

function ceilToFraction($number, $denominator = 1)
{
    $original  = $x = $number * $denominator;
    
	$x = ceil($x);
	
    $x = $x / $denominator;
	
	if(($x-$original) >= 0.25){
	  $x = $this->floorToFraction($number,$denominator);
	}
	
    return $x;
}


function findUniqueItem($food,$used,$index){

     if(in_array($food[$index]['id'],$used)){
		 $index++;
		 
		if($index >= count($food)){
		  return 0;
		}
		else{
	   	  return $this->findUniqueItem($food,$used,$index);
		}
	 }
	 else{
	 
	   return $index;
	 }
	 
	 
}


function checkHid($hid){
  global $database;
  
   $new_hid = $hid;
   
  $check_sel = $database->query("SELECT hid FROM house_tax WHERE hid = '".$hid."'");
  
  if(mysqli_num_rows($check_sel) > 0){
	    $new_hid = $hid.rand(111,999);
		$this->checkHid($new_hid);
  }
	
	return $new_hid;
}


function checkMutation($hid,$panchayat){
  global $database;
  
   $new_hid = $hid;
   
   $mutation = 'M'.$panchayat.sprintf('%04d',$hid);
	
	
  $check_sel = $database->query("SELECT mutation_id FROM mutation_applications WHERE mutation_id = '".$mutation."'");
  
  if(mysqli_num_rows($check_sel) > 0){
	    $hid++;
		return $this->checkMutation($new_hid,$panchayat);
  }
   
	return $mutation;
}



function checkGrievance($hid,$panchayat){
  global $database;
  
   $new_hid = $hid;
   
   $mutation = 'G'.$panchayat.sprintf('%04d',$hid);
	
	
  $check_sel = $database->query("SELECT issue_id FROM `grievances`  WHERE issue_id = '".$mutation."'");
  
  if(mysqli_num_rows($check_sel) > 0){
	    $hid++;
		return $this->checkGrievance($new_hid,$panchayat);
  }
   
	return $mutation;
}


function checkRti($hid,$panchayat){
  global $database;
  
   $new_hid = $hid;
   
   $mutation = 'RTI'.$panchayat.sprintf('%04d',$hid);
	
	
  $check_sel = $database->query("SELECT rti_id FROM `rti_applications`  WHERE rti_id = '".$mutation."'");
  
  if(mysqli_num_rows($check_sel) > 0){
	    $hid++;
		return $this->checkRti($new_hid,$panchayat);
  }
   
	return $mutation;
}


function activity($log,$user,$display){
   global $database;
   
   $database->query("INSERT INTO log VALUES(NULL,'".$log." - IP:".$_SERVER['REMOTE_ADDR']."','".$user."','".time()."',".$display.",0)");	
	
}




function number_to_words($number){
	
 
    $no = round($number);
   $point = round($number - $no, 2) * 100;
   $hundred = null;
   $digits_1 = strlen($no);
   $i = 0;
   $str = array();
   $words = array('0' => '', '1' => 'one', '2' => 'two',
    '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six',
    '7' => 'seven', '8' => 'eight', '9' => 'nine',
    '10' => 'ten', '11' => 'eleven', '12' => 'twelve',
    '13' => 'thirteen', '14' => 'fourteen',
    '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
    '18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty',
    '30' => 'thirty', '40' => 'forty', '50' => 'fifty',
    '60' => 'sixty', '70' => 'seventy',
    '80' => 'eighty', '90' => 'ninety');
   $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
   while ($i < $digits_1) {
     $divider = ($i == 2) ? 10 : 100;
     $number = floor($no % $divider);
     $no = floor($no / $divider);
     $i += ($divider == 10) ? 1 : 2;
     if ($number) {
        
		$counter = count($str);
		$plural = null;//(($counter = count($str)) && $number > 9) ? 's' : null;
		
		
        $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
        $str [] = ($number < 21) ? $words[$number] .
            " " . $digits[$counter] . $plural . " " . $hundred
            :
            $words[floor($number / 10) * 10]
            . " " . $words[$number % 10] . " "
            . $digits[$counter] . $plural . " " . $hundred;
     } else $str[] = null;
  }
  $str = array_reverse($str);
  $result = implode('', $str);
  $points = ($point) ?
    "." . $words[$point / 10] . " " . 
          $words[$point = $point % 10] : '';
  return $result  ;
 	
}







function validateAadhar($aadhar){
	
	$aadharArray = array();
	
	
	
	for($i=0;$i < strlen($aadhar); $i++){
	   $aadharArray[$i] = substr($aadhar,$i,1);	
	}
	
	if(!$this->CheckArrayByVerhoeffAlogirithm($aadharArray))
	return false;
	
	else if($aadharArray[0] == 1 || $aadharArray[0] == 0)	
	return false;
	 
    elseif($aadhar == '222222222222' || $aadhar == '333333333333' || $aadhar == '444444444444' || $aadhar == '555555555555' || $aadhar == '666666666666' || $aadhar == '777777777777' || $aadhar == '888888888888' || $aadhar == '999999999999')	 
	return false;
	
	else{
	     $part1 = substr($aadhar,0,4);
		 $part2 = substr($aadhar,4,4);
		 $part3 = substr($aadhar,8,4);
		  
		 if($part1 == $part2 || $part1 == $part3 || $part2 == $part3)
		 return false; 	
		
	}
	 
	return true;
}

 

function CheckArrayByVerhoeffAlogirithm($aadharArray){
	
	
            $op = array();
            $op[0] =  array( 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 );
            $op[1] =    array(  1, 2, 3, 4, 0, 6, 7, 8, 9, 5 );
            $op[2] =    array(  2, 3, 4, 0, 1, 7, 8, 9, 5, 6 );
            $op[3] =   array(  3, 4, 0, 1, 2, 8, 9, 5, 6, 7 );
            $op[4] =    array(  4, 0, 1, 2, 3, 9, 5, 6, 7, 8 );
            $op[5] =    array(  5, 9, 8, 7, 6, 0, 4, 3, 2, 1 );
            $op[6] =    array(  6, 5, 9, 8, 7, 1, 0, 4, 3, 2 );
           $op[7] =    array(  7, 6, 5, 9, 8, 2, 1, 0, 4, 3 );
            $op[8] =    array(  8, 7, 6, 5, 9, 3, 2, 1, 0, 4 );
            $op[9] =    array(  9, 8, 7, 6, 5, 4, 3, 2, 1, 0 );

            $F = array();
            $F[0] =   array(  0, 1, 2, 3, 4, 5, 6, 7, 8, 9 );
            $F[1] =    array(  1, 5, 7, 6, 2, 8, 3, 0, 9, 4 );
            for ($i = 2; $i < 8; $i++)
            { 
                for (  $j = 0; $j < 10; $j++)
                    $F[$i][$j] = $F[$i - 1][$F[1][$j]];
            }

	
	

            // First we need to reverse the order of the input digits
            $reversedInput = array();
            for ($i = 0; $i < count($aadharArray); $i++)
                $reversedInput[$i] = $aadharArray[count($aadharArray) - ($i + 1)];

            $check = 0;
            for ($i = 0; $i < count($reversedInput); $i++)
                $check = $op[$check][$F[$i % 8][$reversedInput[$i]]];
				//echo $check;

            return ($check == 0);

	
	
	
	
}


function getAadharInfo($aadhar){
	global $database;
	 $soap_request  = '<soapenv:Envelope   xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://srdhuidinfoservices/ecentric/com/xsd"><soapenv:Header /><soapenv:Body><xsd:getAadhaarInfo><xsd:UID>'.$aadhar.'</xsd:UID><xsd:EID>?</xsd:EID></xsd:getAadhaarInfo></soapenv:Body></soapenv:Envelope>';
 
  $header = array(
    "Content-type: text/xml;charset=\"utf-8\"",
    "Accept: text/xml",
    "Cache-Control: no-cache",
    "Pragma: no-cache",
     
    "Content-length: ".strlen($soap_request),
  );
 
  $soap_do = curl_init();
  curl_setopt($soap_do, CURLOPT_URL, "http://aadharinfo.ap.gov.in/SRDHAadhaarService/services/Services?wsdl" );
  curl_setopt($soap_do, CURLOPT_CONNECTTIMEOUT, 10);
  curl_setopt($soap_do, CURLOPT_TIMEOUT,        10);
  curl_setopt($soap_do, CURLOPT_RETURNTRANSFER, true );
  curl_setopt($soap_do, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($soap_do, CURLOPT_SSL_VERIFYHOST, false);
  curl_setopt($soap_do, CURLOPT_POST,           true );
  curl_setopt($soap_do, CURLOPT_POSTFIELDS,     $soap_request);
  curl_setopt($soap_do, CURLOPT_HTTPHEADER,     $header);
 
 
 $output = curl_exec($soap_do);
 
  
 $p1 = explode('<ns:return>',$output);
 
 if(count($p1) > 1){
 $p2 = explode('</ns:return>',$p1[1]);

  $xml_data =  htmlspecialchars_decode($p2[0]); 

 
 $aadhardata = $this->xml2array($xml_data);
 return ($aadhardata[0]);
	
}
else{
	
	 $check_aadhar = $database->query("SELECT * FROM citizens WHERE aadhar = '".$aadhar."'");
			   if(mysqli_num_rows($check_aadhar) > 0){
				   $c_data = mysqli_fetch_assoc($check_aadhar);
				  $aadhardata[10][0]['value'] = $c_data['full_name'];
				  $aadhardata[2][0]['value'] = $c_data['father_name'];
				  $aadhardata[11][0]['value'] = $c_data['mobile'];
				  
				  if($c_data['gender'] == 1)
				    $aadhardata[7][0]['value'] = 'M';
				  else if($c_data['gender'] == 0)
				    $aadhardata[7][0]['value'] = 'F';
					
					
				  return $aadhardata;
			   }
	
	else return array();
}
}



//Send app notioficcations
function send_notifications($reg_ids, $message) {
       
   define("GOOGLE_API_KEY", "AIzaSyARRLCDdbRdOXCAlMogX78WT-GczH0VCkg");

 
        // Set POST variables
        $url = 'https://gcm-http.googleapis.com/gcm/send';
  
        $fields = array(
            'registration_ids' => ($reg_ids),
            'data' => ($message),
        );
 
        $headers = array(
            'Authorization: key=' . GOOGLE_API_KEY,
            'Content-Type: application/json'
        );

        // Open connection
        $ch = curl_init();
 
        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 
        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
 
        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) 
		{
            die('Curl failed: ' . curl_error($ch));
        }
		
 
        // Close connection
        curl_close($ch);
		
		return $result;
       
    }




function xml2array($xml){
    $opened = array();
    $opened[1] = 0;
    $xml_parser = xml_parser_create();
    xml_parse_into_struct($xml_parser, $xml, $xmlarray);
    $array = array_shift($xmlarray);
    unset($array["level"]);
    unset($array["type"]);
    $arrsize = sizeof($xmlarray);
    for($j=0;$j<$arrsize;$j++){
        $val = $xmlarray[$j];
        switch($val["type"]){
            case "open":
                $opened[$val["level"]]=0;
            case "complete":
                $index = "";
                for($i = 1; $i < ($val["level"]); $i++)
                    $index .= "[" . $opened[$i] . "]";
                $path = explode('][', substr($index, 1, -1));
                $value = &$array;
                foreach($path as $segment)
                    $value = &$value[$segment];
                $value = $val;
                unset($value["level"]);
                unset($value["type"]);
                if($val["type"] == "complete")
                    $opened[$val["level"]-1]++;
            break;
            case "close":
			   if(isset($opened[$val["level"]-1])){
                $opened[$val["level"]-1]++;
			   }
                unset($opened[$val["level"]]);
            break;
        }
    }
    return $array;
} 

function displayAadhar($aadhar){
    
	$a4 = substr($aadhar,0,4);
	
	$a2 = substr($aadhar,-1,2);
	
	return $a4.'XXXXXX'.$a2;	
	
}

function displayMobile($mobile){
    
	$a4 = substr($mobile,0,4);
	
	$a2 = substr($mobile,-1,2);
	
	return $a4.'XXXXX'.$a2;	
	
}


};


/**
 * Initialize session object - This must be initialized before
 * the form object because the form uses session variables,
 * which cannot be accessed unless the session has started.
 */
$session = new Session;

/* Initialize form object */
$form = new Form;

?>