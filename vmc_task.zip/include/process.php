<?php
include('../include/session.php');
header("access-control-allow-origin: *");

//Metircs Forms, Tables and Functions
//Display house_tax form
 //Metircs Forms, Tables and Functions
//Display house_tax form
if(isset($_REQUEST['addForm'])){

	?>
<script type="text/javascript">
$('#adminForm').slideDown();
</script>

    <script type="text/javascript">

        function change_map1() {
            var district = $('#district').val();
            setStateGet('adminForm','<?php echo SECURE_PATH;?>trough/process.php','addForm=1&search=true&district='+district);

            if(district == ''){
                setStateGet('statistics','<?php echo SECURE_PATH;?>trough/process.php','dashBoard=1&districtStats=true');

            }else{
                setStateGet('statistics','<?php echo SECURE_PATH;?>trough/process.php','dashBoard=1&divisionStats=true&district='+$('#district').val());

            }


    }

        function change_map2() {
            var district = $('#district').val();
            var division = $('#division').val();
            setStateGet('adminForm','<?php echo SECURE_PATH;?>trough/process.php','addForm=1&search=true&district='+district+'&division='+division);

            if(division == ''){
                setStateGet('statistics','<?php echo SECURE_PATH;?>trough/process.php','dashBoard=1&divisionStats=true&district='+$('#district').val());
            }else{
                setStateGet('statistics','<?php echo SECURE_PATH;?>trough/process.php','dashBoard=1&mandalStats=true&division='+$('#division').val());
            }

        }

        function change_map3() {
            var district = $('#district').val();
            var division = $('#division').val();
            var mandal = $('#mandal').val();
            setStateGet('adminForm','<?php echo SECURE_PATH;?>trough/process.php','addForm=1&search=true&district='+district+'&division='+division+'&mandal='+mandal);

            if(mandal == ''){
                setStateGet('statistics','<?php echo SECURE_PATH;?>trough/process.php','dashBoard=1&mandalStats=true&division='+$('#division').val());
            }else{
                setStateGet('statistics','<?php echo SECURE_PATH;?>trough/process.php','dashBoard=1&panchayatStats=true&mandal='+$('#mandal').val());
            }

          }

        function change_map4() {
            var district = $('#district').val();
            var division = $('#division').val();
            var mandal = $('#mandal').val();
            var pan = $('#pan').val();

            setStateGet('adminForm','<?php echo SECURE_PATH;?>trough/process.php','tableDisplay1=1&addForm=1&search=true&district='+district+'&division='+division+'&mandal='+mandal+'&pan='+pan);
			
			
			
			


            if(pan == ''){
                setStateGet('statistics','<?php echo SECURE_PATH;?>trough/process.php','dashBoard=1&panchayatStats=true&mandal='+$('#mandal').val());
            }else{
				
				 
                setStateGet('statistics','<?php echo SECURE_PATH;?>trough/process.php','dashBoard=1&select_panchayatStats=true&panchayat_id='+$('#pan').val());
            }
        }
		
		
		  function change_map5() {
		
            var district = $('#district').val();
            var division = $('#division').val();
            var mandal = $('#mandal').val();
            var pan = $('#pan').val();
            var block = $('#block').val();
			

            setStateGet('adminForm','<?php echo SECURE_PATH;?>trough/process.php','tableDisplay2=1&addForm=1&search=true&district='+district+'&division='+division+'&mandal='+mandal+'&pan='+pan+'&block='+block);
			 $("#block").show();
		$("#divmap").show();
		  }
		
		function viewblock()
		{		
		setStateGet('viewmapdetail','<?php echo SECURE_PATH;?>trough/test1.php','iconval=4');
		
		}
		
		$("#mapicon").click(function(){
    $("#sel_block").show();
});

		
    </script>







<form class="form-inline">
 <fieldset>
 <legend>Solid Waste Management Dash Board</legend>

     <div class="col-sm-2">
         <div class="form-group">
             <label for="state">Select State</label>
             <select name="state" id="state"class="form-control" disabled="disabled">
                 <option value="">Select State</option>
                 <?php
                 $qu = $database->query("SELECT * FROM `global_states` ");
                 if (mysqli_num_rows($qu) > 0) {
                     while ($category = mysqli_fetch_array($qu)) {
                         ?>
                         <option value="<?php echo $category['id'] ?>"
                                 <?php
                                 if ($category['id']==1) {
                                     echo "selected=selected";
                                 }

                             ?>>
                             <?php echo ucwords($category['state']) ?>
                         </option>
                         <?php
                     }
                 } ?>
             </select>
         </div>
     </div>


  <div class="col-sm-2">
      <div class="form-group">
          <label for="district">Select District</label>
          <select name="district" id="district"class="form-control"
                  onchange="change_map1()">
              <option value="">Select District</option>
              <?php
              $qu = $database->query("SELECT * FROM `global_districts` ");
              if (mysqli_num_rows($qu) > 0) {
                  while ($category = mysqli_fetch_array($qu)) {
                      ?>
                      <option value="<?php echo $category['uid'] ?>"
                          <?php if (isset($_GET['district'])) {
                              if ($_GET['district'] == $category['uid']) {
                                  echo "selected=selected";
                              }
                          }
                          ?>>
                          <?php echo ucwords($category['district']) ?>
                      </option>
                      <?php
                  }
              } ?>
          </select>
      </div>
  </div>

     <div class="col-md-2">
         <div class="form-group">
             <label for="division">Select Division</label>
             <select name="division" id="division" class="form-control"
                     onchange="change_map2()">
                 <option value="">Select Division</option>
                 <?php
                 $q = $database->query("SELECT * FROM `global_divisions` WHERE district='" . $_GET['district'] . "'");
                 if ($data_rows = mysqli_num_rows($q) > 0) {
                     while ($data = mysqli_fetch_array($q)) {
                         ?>
                         <option value="<?php echo $data['id'] ?>"
                             <?php if (isset($_GET['division'])) {
                                 if ($_GET['division'] == $data['id']) {
                                     echo "selected=selected";
                                 }
                             }
                             ?>>
                             <?php echo ucwords($data['division']) ?>
                         </option>
                         <?php
                     }
                 } ?>
             </select>
         </div>
     </div>

     <div class="col-md-2">
         <div class="form-group">
             <label for="mandal">Select Mandal</label>
             <select name="mandal" id="mandal"  class="form-control"
                     onchange="change_map3()">
                 <option value="">Select Mandal</option>
                 <?php
                 $q = $database->query("SELECT * FROM `global_mandals` WHERE division='".$_GET['division']."'");
                 if ($data_rows = mysqli_num_rows($q) > 0) {
                     while ($data = mysqli_fetch_array($q)) {
                         ?>
                         <option value="<?php echo $data['uid'] ?>"
                             <?php if (isset($_GET['mandal'])) {
                                 if ($_GET['mandal'] == $data['uid']) {
                                     echo "selected=selected";
                                 }
                             }
                             ?>>
                             <?php echo ucwords($data['mandal']) ?>
                         </option>
                         <?php
                     }
                 } ?>
             </select>
         </div>
     </div>


     <div class="col-md-2">
         <div class="form-group">
             <label for="pan">Select Panchayat</label>
             <select name="pan" id="pan"  class="form-control"
                     onchange="change_map4()">
                 <option value="">Select Panchayat</option>
                 <?php
                 $q = $database->query("SELECT * FROM `global_panchayats` WHERE mandal='".$_GET['mandal']."'");
                 if (mysqli_num_rows($q) > 0) {
					 $countno=1;
                     while ($data = mysqli_fetch_array($q)) {
                         ?>
                         <option value="<?php echo $data['panchayat_id'] ?>"
                             <?php if (isset($_GET['pan'])) {
                                 if ($_GET['pan'] == $data['panchayat_id']) {
                                     echo "selected=selected";
                                 }
                             }
                             ?>>
                             <?php echo ucwords($data['panchayat']) ?>
                         </option>
                         <?php
                     }
                 } ?>
             </select>
           
       </div>
        
     </div>


     <div class="col-md-1">
     </div>
     <div class="col-md-1">
         <div class="form-group">
         <?php if (isset($_GET['pan'])) {
			
			
			 ?>
          <center> 
          
          <img title="View Map" onclick='viewblock()' style="cursor:pointer;float:right"  src="location_icon.png" height="50" id="mapicon" width="65" alt="View Map"/><br />
          View Map
           </center>
            <?php
		
		 }
		 ?>
       </div>
        
     </div>
<?php
error_reporting(0);

$condition2 = '';
if(isset($_REQUEST['tableDisplay1'])) {

    $tableName = 'rfid_tags';
    $tableName2 = 'global_panchayats';
    $numres = 0;
    if (isset($_GET['search'])) {
        if (strlen($_GET['district']) > 0) {
		    $condition2 = " global_panchayats.district=".$_GET['district'];
			//echo $condition2;

            if(strlen($_GET['division']) > 0){
                $condition2 = $condition2." and global_panchayats.division=".$_GET['division'];
            }

            if(strlen($_GET['mandal']) > 0){
                $condition2 = $condition2." and global_panchayats.mandal=".$_GET['mandal'];
            }

            if(strlen($_GET['pan']) > 0){
                $condition2 = $condition2." and global_panchayats.panchayat_id=".$_GET['pan'];
            }

            if(strlen($_GET['block']) > 0){
                $condition2 = $condition2." and rfid_tags.block_no=".$_GET['block'];
            }

            $condition2 = $condition2." and global_panchayats.panchayat_id = rfid_tags.panchayat";
        }

    } 


	?>
   
<div class="col-md-4"><br /></div>
  <div class="col-md-8" id="sel_block" style="display:none" >
                <div class="form-group">
                    <label for="block">Select Block</label>
                    <select name="block" id="block"  class="form-control"
                            onchange="change_map5()">
                        <option value="">Select Block</option>
                        <?php
                        if($_GET['pan']!=0){
                        $q = $database->query("SELECT * FROM `swm_blocks` WHERE panchayat='".$_GET['pan']."'");
                        }
                        if ($data_rows = mysqli_num_rows($q) > 0) {
                            while ($data = mysqli_fetch_array($q)) {
                                ?>
                                <option value="<?php echo $data['block_no'] ?>"
                                    <?php if (isset($_GET['block'])) {
                                        if ($_GET['block'] == $data['block_no']) {
                                            echo "selected=selected";
                                        }
                                    }
                                    ?>>
                                    <?php echo ucwords($data['block_name']) ?>
                                </option>
                                <?php
                            }
                        } ?>
                    </select>
                </div>
            </div>
              
              
<div class="md-col-12"  id="divmap">
<div id="viewmapdetail">
     
     
     </div>

<div id="mapView">

 </div>
 
 
</div>


<?php

    $tableName = 'rfid_tags';
    $tableName2 = 'global_panchayats';


    if (strlen($condition2) > 0) {
        $condition2 = "where" . $condition2;
       $q = "SELECT $tableName.* FROM $tableName,$tableName2 $condition2 and $tableName.lat>0 and $tableName.longd>0";
		$result_sel = $database->query($q);

        $numres = mysqli_num_rows($result_sel);
	
		
    }
   
    if ($numres > 0) {
        $i=0;
        $lat =0;
        $lng =0;
  $geo=array();
        while ($data=mysqli_fetch_array($result_sel)){
            $geo[$i]['lat'] = $data['lat'];
            $geo[$i]['lng'] = $data['longd'];
            $geo[$i]['id'] = $data['id'];

            $lat += $data['lat'];
            $lng += $data['longd'];


            $i++;
        }

        $avg_lat = $lat/$i;
        $avg_lng = $lng/$i;

        $_SESSION['avg_lat'] = $avg_lat;
        $_SESSION['avg_lng'] = $avg_lng;



        $_SESSION['geo'] = $geo;
		
		        ?>
        <script type="text/javascript">
		
            setState('mapView', '<?php  echo SECURE_PATH;?>trough/test.php', 'mapView=true&avg_lat=<?php echo $avg_lat;?>&avg_lng=<?php echo $avg_lng;?>&geo=<?php echo json_encode($geo);?>&count=<?php echo $i;?>');
        </script>
        <?php
    }
    else{?>
        <script type="text/javascript">
            setState('mapView', '<?php  echo SECURE_PATH;?>trough/test.php', 'mapView2=true');
        </script>
        <?php
    }
	
}
?>


<?php
$condition2 = '';
if(isset($_REQUEST['tableDisplay2'])) {

    $tableName = 'rfid_tags';
    $tableName2 = 'global_panchayats';
    $numres = 0;
    if (isset($_GET['search'])) {
        if (strlen($_GET['district']) > 0) {
		    $condition2 = " global_panchayats.district=".$_GET['district'];
			//echo $condition2;

            if(strlen($_GET['division']) > 0){
                $condition2 = $condition2." and global_panchayats.division=".$_GET['division'];
            }

            if(strlen($_GET['mandal']) > 0){
                $condition2 = $condition2." and global_panchayats.mandal=".$_GET['mandal'];
            }

            if(strlen($_GET['pan']) > 0){
                $condition2 = $condition2." and global_panchayats.panchayat_id=".$_GET['pan'];
            }

            if(strlen($_GET['block']) > 0){
                $condition2 = $condition2." and rfid_tags.block_no=".$_GET['block'];
            }

            $condition2 = $condition2." and global_panchayats.panchayat_id = rfid_tags.panchayat";
        }

    } 


	?>
              
  
<div class="col-md-4"><br /></div>
  <div class="col-md-8" id="sel_block"  >
                <div class="form-group">
                    <label for="block">Select Block</label>
                    <select name="block" id="block"  class="form-control"
                            onchange="change_map5()">
                        <option value="">Select Block</option>
                        <?php
                        if($_GET['pan']!=0){
                        $q = $database->query("SELECT * FROM `swm_blocks` WHERE panchayat='".$_GET['pan']."'");
                        }
                        if ($data_rows = mysqli_num_rows($q) > 0) {
                            while ($data = mysqli_fetch_array($q)) {
                                ?>
                                <option value="<?php echo $data['block_no'] ?>"
                                    <?php if (isset($_GET['block'])) {
                                        if ($_GET['block'] == $data['block_no']) {
                                            echo "selected=selected";
                                        }
                                    }
                                    ?>>
                                    <?php echo ucwords($data['block_name']) ?>
                                </option>
                                <?php
                            }
                        } ?>
                    </select>
                </div>
            </div>
              
              
<div class="md-col-12"  id="divmap">
<div id="viewmapdetail">
     
     
     </div>

<div id="mapView">

 </div>
 
 
</div>


<?php

    $tableName = 'rfid_tags';
    $tableName2 = 'global_panchayats';


    if (strlen($condition2) > 0) {
        $condition2 = "where" . $condition2;
       $q = "SELECT $tableName.* FROM $tableName,$tableName2 $condition2 and $tableName.lat>0 and $tableName.longd>0";
		$result_sel = $database->query($q);

        $numres = mysqli_num_rows($result_sel);
	
		
    }
   
    if ($numres > 0) {
        $i=0;
        $lat =0;
        $lng =0;
  $geo=array();
        while ($data=mysqli_fetch_array($result_sel)){
            $geo[$i]['lat'] = $data['lat'];
            $geo[$i]['lng'] = $data['longd'];
            $geo[$i]['id'] = $data['id'];

            $lat += $data['lat'];
            $lng += $data['longd'];


            $i++;
        }

        $avg_lat = $lat/$i;
        $avg_lng = $lng/$i;

        $_SESSION['avg_lat'] = $avg_lat;
        $_SESSION['avg_lng'] = $avg_lng;



        $_SESSION['geo'] = $geo;
		
		        ?>
        <script type="text/javascript">
		
            setState('mapBlock', '<?php  echo SECURE_PATH;?>trough/test2.php', 'mapView=true&avg_lat=<?php echo $avg_lat;?>&avg_lng=<?php echo $avg_lng;?>&geo=<?php echo json_encode($geo);?>&count=<?php echo $i;?>');
        </script>
        <?php
    }
    else{?>
        <script type="text/javascript">
            setState('mapBlock', '<?php  echo SECURE_PATH;?>trough/test2.php', 'mapView2=true');
        </script>
        <?php
    }
	
}
?>




  <div style="clear:both"></div>
   <div id="mapBlock">

 </div>
   </fieldset>

</form>
<br />




 <script type="text/javascript">

$( ".datePicker" ).datepicker({
			changeMonth: true,
			changeYear: true,
			dateFormat: "d-m-yy",
			yearRange: "2017:2025",
			maxDate: 0

		});
</script>




<?php

	unset($_SESSION['error']);
}


if(isset($_GET['dashBoard'])){



	   if(isset($_GET['districtStats'])){

		  $district = $_GET['districtStats'];

		  $district_sel = $database->query("SELECT * FROM global_districts");



			 ?>

             <table class="table table-condensed table-bordered">

               <tr>

                   <th rowspan="2" valign="middle" style="text-align:center">SL.No</th>
                  <th rowspan="2" valign="middle" style="text-align:center">NAME OF DISTRICT</th>
                   <th rowspan="2" valign="middle" style="text-align:center">NO.OF ASMNTS</th>
                   <th rowspan="2" valign="middle" style="text-align:center">NO.OF BLOCKS</th>

                  <th colspan="2"  valign="middle" style="text-align:center">MAN POWER</th>
               <th colspan="3" valign="middle" style="text-align:center">TRANSPORTATION </th>
               <th colspan="2" valign="middle" style="text-align:center">INFRASTRUCTURE</th>
               <th colspan="6" valign="middle" style="text-align:center">DAILY COLLECTION (TONS)</th>
                   <th colspan="3" valign="middle" style="text-align:center">COMPOST</th>
                   <th colspan="3" valign="middle" style="text-align:center">VERMI COMPOST</th>
                   <th colspan="5" valign="middle" style="text-align:center">VERMI STOCK</th>
                   <th colspan="3" valign="middle" style="text-align:center">SALE</th>
               </tr>

               <tr>

                  <th>GP</th>
                  <th>MNREGS</th>

                  <th>TRACTORS</th>
                  <th>AUTOS</th>
                  <th>TRYCYCLE</th>

                  <th>SWPC</th>
                  <th></th>


                  <th>NO.OF HOUSES</th>
                  <th>QNTY</th>
                  <th>FARMER</th>
                  <th>QNTY</th>
                  <th>TOTAL(H+F)</th>
                  <th>TOTAL QNTY</th>

                  <th>NO.OFNADEP</th>
                  <th>TODAY QTY</th>
                  <th>TOTAL QTY</th>

                  <th>NO.OF VERMI</th>
                   <th>TODAY QTY</th>
                   <th>TOTAL QTY</th>

                   <th>NO.OF BATCHS</th>
                   <th>5 KG</th>
                   <th>10 KG</th>
                   <th>25 KG</th>
                   <th>TOTAL</th>

                   <th></th>
                   <th></th>
                   <th></th>

               </tr>

             <?php

             $total_assessments = 0;
             $total_blocks = 0;
             $total_gp = 0;
             $total_tractors=0;
             $total_autos= 0;
             $total_tricycle=0;
             $total_houses=0;
             $total_qty1 = 0;
             $total_farmer=0;
             $total_qty2=0;
             $total_qty=0;
             $total_nadep=0;
             $total_today_nadep=0;
             $total_qty3=0;
             $total_vermi=0;
             $total_today_vermi=0;
             $total_qty4=0;
             $total_batch=0;
             $total_qty5=0;
             $total_qty6=0;
             $total_qty7=0;
             $total_compost_qty=0;
             $total_hf=0;

             $fromdate=strtotime(date('d-m-Y'));
             $todate=strtotime(date('d-m-Y'). ' 23:59:59');

             $slno=0;

			 while($district = mysqli_fetch_array($district_sel)){

                 $slno++;
                 
				  ?>
                  <tr>
                      <td><?php echo $slno;?></td>
                      <td><a onclick="setStateGet('statistics','<?php echo SECURE_PATH;?>trough/process.php','dashBoard=1&divisionStats=true&district=<?php echo $district['uid'];?>');"><?php echo ucwords($district['district']);?></a></td>
                      <td>
                          <?php
                          $no_assessments = $database->query("SELECT rfid_tags.* FROM rfid_tags,global_panchayats where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = rfid_tags.panchayat ");
                          echo mysqli_num_rows($no_assessments);
                          $total_assessments += mysqli_num_rows($no_assessments);
                          ?>
                      </td>

                      <td>
                          <?php
                          $no_blocks = $database->query("SELECT swm_blocks.block_no FROM swm_blocks,global_panchayats where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_blocks.panchayat");
                          echo mysqli_num_rows($no_blocks);
                          $total_blocks += mysqli_num_rows($no_blocks);
                          ?>
                      </td>

                      <td>
                          <?php
                          $gp = $database->query("SELECT swm_blocks.mobile FROM swm_blocks,global_panchayats where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_blocks.panchayat group by swm_blocks.mobile");
                          echo mysqli_num_rows($gp);
                          $total_gp += mysqli_num_rows($gp);
                          ?>
                      </td>

                      <td>NA</td>

                      <td>
                          <?php
                          $tractor = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=3");
                          echo mysqli_num_rows($tractor);
                          $total_tractors += mysqli_num_rows($tractor);
                          ?>
                      </td>

                      <td>
                          <?php
                          $autos = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=1");
                          echo mysqli_num_rows($autos);
                          $total_autos += mysqli_num_rows($autos);
                          ?>
                      </td>

                      <td>
                          <?php
                          $tricycle = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=2");
                          echo mysqli_num_rows($tricycle);
                          $total_tricycle += mysqli_num_rows($tricycle);
                          ?>
                      </td>

                      <td>NA</td>
                      <td>NA</td>

                      <td>
                          <?php
                          $houses = $database->query("SELECT swm_trough_filling.* FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source IN (1,2,3,4,5 ) and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                          echo mysqli_num_rows($houses);
                          $h = mysqli_num_rows($houses);
                          $total_houses += mysqli_num_rows($houses);
                          ?>
                      </td>

                      <td>
                          <?php
                          $qty1=0;
                          $q = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source IN (1,2,3,4,5 ) and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                          if(mysqli_num_rows($q)){
                              while($house_qty=mysqli_fetch_array($q)){
                                  $qty1 += $house_qty['quantity'];
                              }
                          }
                          echo $qty1;
                          $total_qty1 += $qty1;
                          ?>
                      </td>

                      <td>
                          <?php
                          $farmers = $database->query("SELECT swm_trough_filling.* FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source=6 and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                          echo mysqli_num_rows($farmers);
                          $f = mysqli_num_rows($farmers);
                          $total_farmer += mysqli_num_rows($farmers);
                          ?>
                      </td>


                      <td>
                          <?php
                          $qty2=0;
                          $query = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source=6 and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                          if(mysqli_num_rows($query)){
                              while($farmer_qty=mysqli_fetch_array($query)){
                                  $qty2 += $farmer_qty['quantity'];
                              }
                          }
                          echo $qty2;
                          $total_qty2 += $qty2;
                          ?>
                      </td>

                      <td><?php $hf = $h+$f;
                                echo $hf;
                                $total_hf += $hf;
                          ?></td>

                      <td><?php echo $qty1+$qty2;
                            $total_qty += $qty1+$qty2;
                          ?>
                      </td>


                      <td>
                          <?php
                          $no_nadep = $database->query("SELECT swm_troughs.trough_id FROM global_panchayats,swm_troughs where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2");
                          echo mysqli_num_rows($no_nadep);
                          $total_nadep += mysqli_num_rows($no_nadep);
                          ?>
                      </td>

                      <td>
                          <?php
                          $ntoday_qty=0;
                          $query = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."' and swm_trough_filling.trough_id in (select trough_id from swm_trough_log where close_time>='".$fromdate."' and close_time<='".$todate."')");
                          if(mysqli_num_rows($query)){
                              while($nadep_today=mysqli_fetch_array($query)){
                                  $ntoday_qty += $nadep_today['quantity'];
                              }
                          }
                          echo $ntoday_qty;
                          $total_today_nadep += $ntoday_qty;
                          ?>
                      </td>

                      <td>
                          <?php
                          $qty3=0;
                          $query = $database->query("SELECT swm_trough_log.qty FROM swm_trough_log,global_panchayats,swm_troughs where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_log.trough_id and open_time in (select max(open_time) from swm_trough_log WHERE LENGTH(close_time)>0 group by trough_id)");
                          if(mysqli_num_rows($query)){
                              while($nadep_qty=mysqli_fetch_array($query)){
                                  $qty3 += $nadep_qty['qty'];
                              }
                          }
                          echo $qty3;
                          $total_qty3 += $qty3;
                          ?>
                      </td>

                      <td>
                          <?php
                          $no_vermi = $database->query("SELECT swm_troughs.trough_id FROM global_panchayats,swm_troughs where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2");
                          echo mysqli_num_rows($no_vermi);
                          $total_vermi += mysqli_num_rows($no_vermi);
                          ?>
                      </td>

                      <td>
                          <?php
                          $vtoday_qty=0;
                          $query = $database->query("SELECT swm_vermi_filling.qty FROM swm_vermi_filling,global_panchayats,swm_troughs where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2 and swm_troughs.status=1 and swm_troughs.trough_id=swm_vermi_filling.vermi_trough and swm_vermi_filling.timestamp>='".$fromdate."' and swm_vermi_filling.timestamp<='".$todate."'");
                          if(mysqli_num_rows($query)){
                              while($vermi_today=mysqli_fetch_array($query)){
                                  $vtoday_qty += $vermi_today['qty'];
                              }
                          }
                          echo $vtoday_qty;
                          $total_today_vermi += $vtoday_qty;
                          ?>
                      </td>

                      <td>
                          <?php
                          $qty4=0;
                          $query = $database->query("SELECT swm_trough_log.qty FROM swm_trough_log,global_panchayats,swm_troughs where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_log.trough_id and open_time in (select max(open_time) from swm_trough_log WHERE LENGTH(close_time)>0 group by trough_id)");
                          if(mysqli_num_rows($query)){
                              while($vermi_qty=mysqli_fetch_array($query)){
                                  $qty4 += $vermi_qty['qty'];
                              }
                          }
                          echo $qty4;
                          $total_qty4 += $qty4;
                          ?>
                      </td>

                      <td>
                          <?php
                          $no_batch = $database->query("SELECT compost.batch_no FROM global_panchayats,compost where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = compost.panchayat");
                          echo mysqli_num_rows($no_batch);
                          $total_batch += mysqli_num_rows($no_batch);
                          ?>
                      </td>

                      <td>
                          <?php
                          $qty5=0;
                          $query = $database->query("SELECT compost.5kg_bags FROM global_panchayats,compost where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = compost.panchayat");
                          if(mysqli_num_rows($query)){
                              while($vermi_qty=mysqli_fetch_array($query)){
                                  $qty5 += $vermi_qty['5kg_bags'];
                              }
                          }
                          echo $qty5;
                          $total_qty5 += $qty5;
                          ?>
                      </td>

                      <td>
                          <?php
                          $qty6=0;
                          $query = $database->query("SELECT compost.10kg_bags FROM global_panchayats,compost where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = compost.panchayat");
                          if(mysqli_num_rows($query)){
                              while($vermi_qty=mysqli_fetch_array($query)){
                                  $qty6 += $vermi_qty['10kg_bags'];
                              }
                          }
                          echo $qty6;
                          $total_qty6 += $qty6;
                          ?>
                      </td>
                      <td>
                          <?php
                          $qty7=0;
                          $query = $database->query("SELECT compost.25kg_bags FROM global_panchayats,compost where global_panchayats.district='".$district['uid']."' and global_panchayats.panchayat_id = compost.panchayat");
                          if(mysqli_num_rows($query)){
                              while($vermi_qty=mysqli_fetch_array($query)){
                                  $qty7 += $vermi_qty['25kg_bags'];
                              }
                          }
                          echo $qty7;
                          $total_qty7 += $qty7;
                          ?>
                      </td>
                      <td><?php
                          echo $qty5+$qty6+$qty7;
                          $total_compost_qty +=  $qty5+$qty6+$qty7;
                          ?>
                      </td>
                      <td>NA</td>
                      <td>NA</td>
                      <td>NA</td>

                           </tr>
                  <?php

			 }
		   ?>

           <tr>
               <th></th>
             <th>Total</th>
             <th><?php echo $total_assessments;?></th>
             <th><?php echo $total_blocks;?></th>
             <th><?php echo $total_gp;?></th>
               <th></th>

             <th><?php echo $total_tractors;?></th>
             <th><?php echo $total_autos;?></th>
             <th><?php echo $total_tricycle;?></th>

               <th></th>
               <th></th>

             <th><?php echo $total_houses;?></th>
             <th><?php echo $total_qty1;?></th>
             <th><?php echo $total_farmer;?></th>
             <th><?php echo $total_qty2;?></th>
               <th><?php echo $total_hf;?></th>
             <th><?php echo $total_qty;?></th>

             <th><?php echo $total_nadep;?></th>
               <th><?php echo $total_today_nadep;?></th>
             <th><?php echo $total_qty3;?></th>

               <th><?php echo $total_vermi;?></th>
               <th><?php echo $total_today_vermi;?></th>
               <th><?php echo $total_qty4;?></th>

               <td><?php echo $total_batch;?></td>
               <td><?php echo $total_qty5;?></td>
               <td><?php echo $total_qty6;?></td>
               <td><?php echo $total_qty7;?></td>
               <td><?php echo $total_compost_qty;?></td>
               <td></td>
               <td></td>
               <td></td>


           </tr>
           </table>
           <?php
	   }


	  else  if(isset($_GET['divisionStats'])){

          $division_sel = $database->query("SELECT * FROM global_divisions WHERE district='".$_GET['district']."'");



          ?>

          <table class="table table-condensed table-bordered">

              <tr>

                  <th rowspan="2" valign="middle" style="text-align:center">SL.No</th>
                  <th rowspan="2" valign="middle" style="text-align:center">NAME OF DIVISION</th>
                  <th rowspan="2" valign="middle" style="text-align:center">NO.OF ASMNTS</th>
                  <th rowspan="2" valign="middle" style="text-align:center">NO.OF BLOCKS</th>

                  <th colspan="2"  valign="middle" style="text-align:center">MAN POWER</th>
                  <th colspan="3" valign="middle" style="text-align:center">TRANSPORTATION </th>
                  <th colspan="2" valign="middle" style="text-align:center">INFRASTRUCTURE</th>
                  <th colspan="6" valign="middle" style="text-align:center">DAILY COLLECTION (TONS)</th>
                  <th colspan="3" valign="middle" style="text-align:center">COMPOST</th>
                  <th colspan="3" valign="middle" style="text-align:center">VERMI COMPOST</th>
                  <th colspan="5" valign="middle" style="text-align:center">VERMI STOCK</th>
                  <th colspan="3" valign="middle" style="text-align:center">SALE</th>
              </tr>

              <tr>

                  <th>GP</th>
                  <th>MNREGS</th>

                  <th>TRACTORS</th>
                  <th>AUTOS</th>
                  <th>TRYCYCLE</th>

                  <th>SWPC</th>
                  <th></th>


                  <th>NO.OF HOUSES</th>
                  <th>QNTY</th>
                  <th>FARMER</th>
                  <th>QNTY</th>
                  <th>TOTAL(H+F)</th>
                  <th>TOTAL QNTY</th>

                  <th>NO.OFNADEP</th>
                  <th>TODAY QTY</th>
                  <th>TOTAL QTY</th>

                  <th>NO.OF VERMI</th>
                  <th>TODAY QTY</th>
                  <th>TOTAL QTY</th>

                  <th>NO.OF BATCHS</th>
                  <th>5 KG</th>
                  <th>10 KG</th>
                  <th>25 KG</th>
                  <th>TOTAL</th>

                  <th></th>
                  <th></th>
                  <th></th>

              </tr>

              <?php

              $total_assessments = 0;
              $total_blocks = 0;
              $total_gp = 0;
              $total_tractors=0;
              $total_autos= 0;
              $total_tricycle=0;
              $total_houses=0;
              $total_qty1 = 0;
              $total_farmer=0;
              $total_qty2=0;
              $total_qty=0;
              $total_nadep=0;
              $total_today_nadep=0;
              $total_qty3=0;
              $total_vermi=0;
              $total_today_vermi=0;
              $total_qty4=0;
              $total_batch=0;
              $total_qty5=0;
              $total_qty6=0;
              $total_qty7=0;
              $total_compost_qty=0;
              $total_hf=0;
              $fromdate=strtotime(date('d-m-Y'));
              $todate=strtotime(date('d-m-Y'). ' 23:59:59');


              $slno=0;

              while($division = mysqli_fetch_array($division_sel)){

                  $slno++;

                  ?>
                  <tr>
                      <td><?php echo $slno;?></td>
                      <td><a onclick="setStateGet('statistics','<?php echo SECURE_PATH;?>trough/process.php','dashBoard=1&mandalStats=true&division=<?php echo $division['id'];?>');"><?php echo ucwords($division['division']);?></a></td>
                      <td>
                          <?php
                          $no_assessments = $database->query("SELECT rfid_tags.* FROM rfid_tags,global_panchayats where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = rfid_tags.panchayat ");
                          echo mysqli_num_rows($no_assessments);
                          $total_assessments += mysqli_num_rows($no_assessments);
                          ?>
                      </td>

                      <td>
                          <?php
                          $no_blocks = $database->query("SELECT swm_blocks.block_no FROM swm_blocks,global_panchayats where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_blocks.panchayat");
                          echo mysqli_num_rows($no_blocks);
                          $total_blocks += mysqli_num_rows($no_blocks);
                          ?>
                      </td>

                      <td>
                          <?php
                          $gp = $database->query("SELECT swm_blocks.mobile FROM swm_blocks,global_panchayats where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_blocks.panchayat group by swm_blocks.mobile");
                          echo mysqli_num_rows($gp);
                          $total_gp += mysqli_num_rows($gp);
                          ?>
                      </td>

                      <td></td>

                      <td>
                          <?php
                          $tractor = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=3");
                          echo mysqli_num_rows($tractor);
                          $total_tractors += mysqli_num_rows($tractor);
                          ?>
                      </td>

                      <td>
                          <?php
                          $autos = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=1");
                          echo mysqli_num_rows($autos);
                          $total_autos += mysqli_num_rows($autos);
                          ?>
                      </td>

                      <td>
                          <?php
                          $tricycle = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=2");
                          echo mysqli_num_rows($tricycle);
                          $total_tricycle += mysqli_num_rows($tricycle);
                          ?>
                      </td>

                      <td>NA</td>
                      <td>NA</td>

                      <td>
                          <?php
                          $houses = $database->query("SELECT swm_trough_filling.* FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source IN (1,2,3,4,5) and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                          echo mysqli_num_rows($houses);
                          $h = mysqli_num_rows($houses);
                          $total_houses += mysqli_num_rows($houses);
                          ?>
                      </td>

                      <td>
                          <?php
                          $qty1=0;
                          $q = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source IN (1,2,3,4,5 ) and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                          if(mysqli_num_rows($q)){
                              while($house_qty=mysqli_fetch_array($q)){
                                  $qty1 += $house_qty['quantity'];
                              }
                          }
                          echo $qty1;
                          $total_qty1 += $qty1;
                          ?>
                      </td>

                      <td>
                          <?php
                          $farmers = $database->query("SELECT swm_trough_filling.* FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source=6 and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                          echo mysqli_num_rows($farmers);
                          $f = mysqli_num_rows($farmers);
                          $total_farmer += mysqli_num_rows($farmers);
                          ?>
                      </td>


                      <td>
                          <?php
                          $qty2=0;
                          $query = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source=6 and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                          if(mysqli_num_rows($query)){
                              while($farmer_qty=mysqli_fetch_array($query)){
                                  $qty2 += $farmer_qty['quantity'];
                              }
                          }
                          echo $qty2;
                          $total_qty2 += $qty2;
                          ?>
                      </td>

                      <td><?php $hf = $h+$f;
                          echo $hf;
                          $total_hf += $hf;
                          ?></td>

                      <td><?php echo $qty1+$qty2;
                          $total_qty += $qty1+$qty2;
                          ?>
                      </td>


                      <td>
                          <?php
                          $no_nadep = $database->query("SELECT swm_troughs.trough_id FROM global_panchayats,swm_troughs where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2");
                          echo mysqli_num_rows($no_nadep);
                          $total_nadep += mysqli_num_rows($no_nadep);
                          ?>
                      </td>

                      <td>
                          <?php
                          $ntoday_qty=0;
                          $query = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."' and swm_trough_filling.trough_id in (select trough_id from swm_trough_log where close_time>='".$fromdate."' and close_time<='".$todate."')");
                          if(mysqli_num_rows($query)){
                              while($nadep_today=mysqli_fetch_array($query)){
                                  $ntoday_qty += $nadep_today['quantity'];
                              }
                          }
                          echo $ntoday_qty;
                          $total_today_nadep += $ntoday_qty;
                          ?>
                      </td>

                      <td>
                          <?php
                          $qty3=0;
                          $query = $database->query("SELECT swm_trough_log.qty FROM swm_trough_log,global_panchayats,swm_troughs where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_log.trough_id and open_time in (select max(open_time) from swm_trough_log WHERE LENGTH(close_time)>0 group by trough_id)");
                          if(mysqli_num_rows($query)){
                              while($nadep_qty=mysqli_fetch_array($query)){
                                  $qty3 += $nadep_qty['qty'];
                              }
                          }
                          echo $qty3;
                          $total_qty3 += $qty3;
                          ?>
                      </td>

                      <td>
                          <?php
                          $no_vermi = $database->query("SELECT swm_troughs.trough_id FROM global_panchayats,swm_troughs where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2");
                          echo mysqli_num_rows($no_vermi);
                          $total_vermi += mysqli_num_rows($no_vermi);
                          ?>
                      </td>

                      <td>
                          <?php
                          $vtoday_qty=0;
                          $query = $database->query("SELECT swm_vermi_filling.qty FROM swm_vermi_filling,global_panchayats,swm_troughs where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2 and swm_troughs.status=1 and swm_troughs.trough_id=swm_vermi_filling.vermi_trough and swm_vermi_filling.timestamp>='".$fromdate."' and swm_vermi_filling.timestamp<='".$todate."'");
                          if(mysqli_num_rows($query)){
                              while($vermi_today=mysqli_fetch_array($query)){
                                  $vtoday_qty += $vermi_today['qty'];
                              }
                          }
                          echo $vtoday_qty;
                          $total_today_vermi += $vtoday_qty;
                          ?>
                      </td>

                      <td>
                          <?php
                          $qty4=0;
                          $query = $database->query("SELECT swm_trough_log.qty FROM swm_trough_log,global_panchayats,swm_troughs where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_log.trough_id and open_time in (select max(open_time) from swm_trough_log WHERE LENGTH(close_time)>0 group by trough_id)");
                          if(mysqli_num_rows($query)){
                              while($vermi_qty=mysqli_fetch_array($query)){
                                  $qty4 += $vermi_qty['qty'];
                              }
                          }
                          echo $qty4;
                          $total_qty4 += $qty4;
                          ?>
                      </td>


                      <td>
                          <?php
                          $no_batch = $database->query("SELECT compost.batch_no FROM global_panchayats,compost where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = compost.panchayat");
                          echo mysqli_num_rows($no_batch);
                          $total_batch += mysqli_num_rows($no_batch);
                          ?>
                      </td>

                      <td>
                          <?php
                          $qty5=0;
                          $query = $database->query("SELECT compost.5kg_bags FROM global_panchayats,compost where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = compost.panchayat");
                          if(mysqli_num_rows($query)){
                              while($vermi_qty=mysqli_fetch_array($query)){
                                  $qty5 += $vermi_qty['5kg_bags'];
                              }
                          }
                          echo $qty5;
                          $total_qty5 += $qty5;
                          ?>
                      </td>

                      <td>
                          <?php
                          $qty6=0;
                          $query = $database->query("SELECT compost.10kg_bags FROM global_panchayats,compost where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = compost.panchayat");
                          if(mysqli_num_rows($query)){
                              while($vermi_qty=mysqli_fetch_array($query)){
                                  $qty6 += $vermi_qty['10kg_bags'];
                              }
                          }
                          echo $qty6;
                          $total_qty6 += $qty6;
                          ?>
                      </td>
                      <td>
                          <?php
                          $qty7=0;
                          $query = $database->query("SELECT compost.25kg_bags FROM global_panchayats,compost where global_panchayats.division='".$division['id']."' and global_panchayats.panchayat_id = compost.panchayat");
                          if(mysqli_num_rows($query)){
                              while($vermi_qty=mysqli_fetch_array($query)){
                                  $qty7 += $vermi_qty['25kg_bags'];
                              }
                          }
                          echo $qty7;
                          $total_qty7 += $qty7;
                          ?>
                      </td>
                      <td><?php
                          echo $qty5+$qty6+$qty7;
                          $total_compost_qty +=  $qty5+$qty6+$qty7;
                          ?>
                      </td>
                      <td>NA</td>
                      <td>NA</td>
                      <td>NA</td>

                  </tr>
                  <?php

              }
              ?>

              <tr>
                  <th></th>
                  <th>Total</th>
                  <th><?php echo $total_assessments;?></th>
                  <th><?php echo $total_blocks;?></th>
                  <th><?php echo $total_gp;?></th>
                  <th></th>

                  <th><?php echo $total_tractors;?></th>
                  <th><?php echo $total_autos;?></th>
                  <th><?php echo $total_tricycle;?></th>

                  <th></th>
                  <th></th>

                  <th><?php echo $total_houses;?></th>
                  <th><?php echo $total_qty1;?></th>
                  <th><?php echo $total_farmer;?></th>
                  <th><?php echo $total_qty2;?></th>
                  <th><?php echo $total_hf;?></th>
                  <th><?php echo $total_qty;?></th>

                  <th><?php echo $total_nadep;?></th>
                  <th><?php echo $total_today_nadep;?></th>
                  <th><?php echo $total_qty3;?></th>

                  <th><?php echo $total_vermi;?></th>
                  <th><?php echo $total_today_vermi;?></th>
                  <th><?php echo $total_qty4;?></th>

                  <td><?php echo $total_batch;?></td>
                  <td><?php echo $total_qty5;?></td>
                  <td><?php echo $total_qty6;?></td>
                  <td><?php echo $total_qty7;?></td>
                  <td><?php echo $total_compost_qty;?></td>
                  <td></td>
                  <td></td>
                  <td></td>



              </tr>
          </table>
          <?php
      }


	 else  if(isset($_GET['mandalStats'])){


         $mandal_sel = $database->query("SELECT * FROM global_mandals where division='".$_GET['division']."'");



         ?>

         <table class="table table-condensed table-bordered">

             <tr>

                 <th rowspan="2" valign="middle" style="text-align:center">SL.No</th>
                 <th rowspan="2" valign="middle" style="text-align:center">NAME OF MANDAL</th>
                 <th rowspan="2" valign="middle" style="text-align:center">NO.OF ASMNTS</th>
                 <th rowspan="2" valign="middle" style="text-align:center">NO.OF BLOCKS</th>

                 <th colspan="2"  valign="middle" style="text-align:center">MAN POWER</th>
                 <th colspan="3" valign="middle" style="text-align:center">TRANSPORTATION </th>
                 <th colspan="2" valign="middle" style="text-align:center">INFRASTRUCTURE</th>
                 <th colspan="6" valign="middle" style="text-align:center">DAILY COLLECTION (TONS)</th>
                 <th colspan="3" valign="middle" style="text-align:center">COMPOST</th>
                 <th colspan="3" valign="middle" style="text-align:center">VERMI COMPOST</th>
                 <th colspan="5" valign="middle" style="text-align:center">VERMI STOCK</th>
                 <th colspan="3" valign="middle" style="text-align:center">SALE</th>
             </tr>

             <tr>

                 <th>GP</th>
                 <th>MNREGS</th>

                 <th>TRACTORS</th>
                 <th>AUTOS</th>
                 <th>TRYCYCLE</th>

                 <th>SWPC</th>
                 <th></th>


                 <th>NO.OF HOUSES</th>
                 <th>QNTY</th>
                 <th>FARMER</th>
                 <th>QNTY</th>
                 <th>TOTAL(H+F)</th>
                 <th>TOTAL QNTY</th>

                 <th>NO.OFNADEP</th>
                 <th>TODAY QTY</th>
                 <th>TOTAL QTY</th>

                 <th>NO.OF VERMI</th>
                 <th>TODAY QTY</th>
                 <th>TOTAL QTY</th>

                 <th>NO.OF BATCHS</th>
                 <th>5 KG</th>
                 <th>10 KG</th>
                 <th>25 KG</th>
                 <th>TOTAL</th>

                 <th></th>
                 <th></th>
                 <th></th>

             </tr>

             <?php

             $total_assessments = 0;
             $total_blocks = 0;
             $total_gp = 0;
             $total_tractors=0;
             $total_autos= 0;
             $total_tricycle=0;
             $total_houses=0;
             $total_qty1 = 0;
             $total_farmer=0;
             $total_qty2=0;
             $total_qty=0;
             $total_nadep=0;
             $total_today_nadep=0;
             $total_qty3=0;
             $total_vermi=0;
             $total_today_vermi=0;
             $total_qty4=0;
             $total_batch=0;
             $total_qty5=0;
             $total_qty6=0;
             $total_qty7=0;
             $total_compost_qty=0;
             $total_hf=0;
             $fromdate=strtotime(date('d-m-Y'));
             $todate=strtotime(date('d-m-Y'). ' 23:59:59');


             $slno=0;

             while($mandal = mysqli_fetch_array($mandal_sel)){

                 $slno++;

                 ?>
                 <tr>
                     <td><?php echo $slno;?></td>
                     <td><a onclick="setStateGet('statistics','<?php echo SECURE_PATH;?>trough/process.php','dashBoard=1&panchayatStats=true&mandal=<?php echo $mandal['uid'];?>');"><?php echo ucwords($mandal['mandal']);?></a></td>
                     <td>
                         <?php
                         $no_assessments = $database->query("SELECT rfid_tags.* FROM rfid_tags,global_panchayats where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = rfid_tags.panchayat ");
                         echo mysqli_num_rows($no_assessments);
                         $total_assessments += mysqli_num_rows($no_assessments);
                         ?>
                     </td>

                     <td>
                         <?php
                         $no_blocks = $database->query("SELECT swm_blocks.block_no FROM swm_blocks,global_panchayats where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_blocks.panchayat");
                         echo mysqli_num_rows($no_blocks);
                         $total_blocks += mysqli_num_rows($no_blocks);
                         ?>
                     </td>

                     <td>
                         <?php
                         $gp = $database->query("SELECT swm_blocks.mobile FROM swm_blocks,global_panchayats where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_blocks.panchayat group by swm_blocks.mobile");
                         echo mysqli_num_rows($gp);
                         $total_gp += mysqli_num_rows($gp);
                         ?>
                     </td>

                     <td>NA</td>

                     <td>
                         <?php
                         $tractor = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=3");
                         echo mysqli_num_rows($tractor);
                         $total_tractors += mysqli_num_rows($tractor);
                         ?>
                     </td>

                     <td>
                         <?php
                         $autos = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=1");
                         echo mysqli_num_rows($autos);
                         $total_autos += mysqli_num_rows($autos);
                         ?>
                     </td>

                     <td>
                         <?php
                         $tricycle = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=2");
                         echo mysqli_num_rows($tricycle);
                         $total_tricycle += mysqli_num_rows($tricycle);
                         ?>
                     </td>

                     <td>NA</td>
                     <td>NA</td>

                     <td>
                         <?php
                         $houses = $database->query("SELECT swm_trough_filling.* FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source IN (1,2,3,4,5) and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                         echo mysqli_num_rows($houses);
                         $h = mysqli_num_rows($houses);
                         $total_houses += mysqli_num_rows($houses);
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty1=0;
                         $q = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source IN (1,2,3,4,5 ) and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                         if(mysqli_num_rows($q)){
                             while($house_qty=mysqli_fetch_array($q)){
                                 $qty1 += $house_qty['quantity'];
                             }
                         }
                         echo $qty1;
                         $total_qty1 += $qty1;
                         ?>
                     </td>

                     <td>
                         <?php
                         $farmers = $database->query("SELECT swm_trough_filling.* FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source=6 and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                         echo mysqli_num_rows($farmers);
                         $f = mysqli_num_rows($farmers);
                         $total_farmer += mysqli_num_rows($farmers);
                         ?>
                     </td>


                     <td>
                         <?php
                         $qty2=0;
                         $query = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source=6 and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                         if(mysqli_num_rows($query)){
                             while($farmer_qty=mysqli_fetch_array($query)){
                                 $qty2 += $farmer_qty['quantity'];
                             }
                         }
                         echo $qty2;
                         $total_qty2 += $qty2;
                         ?>
                     </td>

                     <td><?php $hf = $h+$f;
                         echo $hf;
                         $total_hf += $hf;
                         ?></td>

                     <td><?php echo $qty1+$qty2;
                         $total_qty += $qty1+$qty2;
                         ?>
                     </td>


                     <td>
                         <?php
                         $no_nadep = $database->query("SELECT swm_troughs.trough_id FROM global_panchayats,swm_troughs where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2");
                         echo mysqli_num_rows($no_nadep);
                         $total_nadep += mysqli_num_rows($no_nadep);
                         ?>
                     </td>

                     <td>
                         <?php
                         $ntoday_qty=0;
                         $query = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."' and swm_trough_filling.trough_id in (select trough_id from swm_trough_log where close_time>='".$fromdate."' and close_time<='".$todate."')");
                         if(mysqli_num_rows($query)){
                             while($nadep_today=mysqli_fetch_array($query)){
                                 $ntoday_qty += $nadep_today['quantity'];
                             }
                         }
                         echo $ntoday_qty;
                         $total_today_nadep += $ntoday_qty;
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty3=0;
                         $query = $database->query("SELECT swm_trough_log.qty FROM swm_trough_log,global_panchayats,swm_troughs where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_log.trough_id and open_time in (select max(open_time) from swm_trough_log WHERE LENGTH(close_time)>0 group by trough_id)");
                         if(mysqli_num_rows($query)){
                             while($nadep_qty=mysqli_fetch_array($query)){
                                 $qty3 += $nadep_qty['qty'];
                             }
                         }
                         echo $qty3;
                         $total_qty3 += $qty3;
                         ?>
                     </td>

                     <td>
                         <?php
                         $no_vermi = $database->query("SELECT swm_troughs.trough_id FROM global_panchayats,swm_troughs where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2");
                         echo mysqli_num_rows($no_vermi);
                         $total_vermi += mysqli_num_rows($no_vermi);
                         ?>
                     </td>

                     <td>
                         <?php
                         $vtoday_qty=0;
                         $query = $database->query("SELECT swm_vermi_filling.qty FROM swm_vermi_filling,global_panchayats,swm_troughs where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2 and swm_troughs.status=1 and swm_troughs.trough_id=swm_vermi_filling.vermi_trough and swm_vermi_filling.timestamp>='".$fromdate."' and swm_vermi_filling.timestamp<='".$todate."'");
                         if(mysqli_num_rows($query)){
                             while($vermi_today=mysqli_fetch_array($query)){
                                 $vtoday_qty += $vermi_today['qty'];
                             }
                         }
                         echo $vtoday_qty;
                         $total_today_vermi += $vtoday_qty;
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty4=0;
                         $query = $database->query("SELECT swm_trough_log.qty FROM swm_trough_log,global_panchayats,swm_troughs where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_log.trough_id and open_time in (select max(open_time) from swm_trough_log WHERE LENGTH(close_time)>0 group by trough_id)");
                         if(mysqli_num_rows($query)){
                             while($vermi_qty=mysqli_fetch_array($query)){
                                 $qty4 += $vermi_qty['qty'];
                             }
                         }
                         echo $qty4;
                         $total_qty4 += $qty4;
                         ?>
                     </td>


                     <td>
                         <?php
                         $no_batch = $database->query("SELECT compost.batch_no FROM global_panchayats,compost where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = compost.panchayat");
                         echo mysqli_num_rows($no_batch);
                         $total_batch += mysqli_num_rows($no_batch);
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty5=0;
                         $query = $database->query("SELECT compost.5kg_bags FROM global_panchayats,compost where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = compost.panchayat");
                         if(mysqli_num_rows($query)){
                             while($vermi_qty=mysqli_fetch_array($query)){
                                 $qty5 += $vermi_qty['5kg_bags'];
                             }
                         }
                         echo $qty5;
                         $total_qty5 += $qty5;
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty6=0;
                         $query = $database->query("SELECT compost.10kg_bags FROM global_panchayats,compost where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = compost.panchayat");
                         if(mysqli_num_rows($query)){
                             while($vermi_qty=mysqli_fetch_array($query)){
                                 $qty6 += $vermi_qty['10kg_bags'];
                             }
                         }
                         echo $qty6;
                         $total_qty6 += $qty6;
                         ?>
                     </td>
                     <td>
                         <?php
                         $qty7=0;
                         $query = $database->query("SELECT compost.25kg_bags FROM global_panchayats,compost where global_panchayats.mandal='".$mandal['uid']."' and global_panchayats.panchayat_id = compost.panchayat");
                         if(mysqli_num_rows($query)){
                             while($vermi_qty=mysqli_fetch_array($query)){
                                 $qty7 += $vermi_qty['25kg_bags'];
                             }
                         }
                         echo $qty7;
                         $total_qty7 += $qty7;
                         ?>
                     </td>
                     <td><?php
                         echo $qty5+$qty6+$qty7;
                         $total_compost_qty +=  $qty5+$qty6+$qty7;
                         ?>
                     </td>
                     <td>NA</td>
                     <td>NA</td>
                     <td>NA</td>

                 </tr>
                 <?php

             }
             ?>

             <tr>
                 <th></th>
                 <th>Total</th>
                 <th><?php echo $total_assessments;?></th>
                 <th><?php echo $total_blocks;?></th>
                 <th><?php echo $total_gp;?></th>
                 <th></th>

                 <th><?php echo $total_tractors;?></th>
                 <th><?php echo $total_autos;?></th>
                 <th><?php echo $total_tricycle;?></th>

                 <th></th>
                 <th></th>

                 <th><?php echo $total_houses;?></th>
                 <th><?php echo $total_qty1;?></th>
                 <th><?php echo $total_farmer;?></th>
                 <th><?php echo $total_qty2;?></th>
                 <th><?php echo $total_hf;?></th>
                 <th><?php echo $total_qty;?></th>

                 <th><?php echo $total_nadep;?></th>
                 <th><?php echo $total_today_nadep;?></th>
                 <th><?php echo $total_qty3;?></th>

                 <th><?php echo $total_vermi;?></th>
                 <th><?php echo $total_today_vermi;?></th>
                 <th><?php echo $total_qty4;?></th>

                 <td><?php echo $total_batch;?></td>
                 <td><?php echo $total_qty5;?></td>
                 <td><?php echo $total_qty6;?></td>
                 <td><?php echo $total_qty7;?></td>
                 <td><?php echo $total_compost_qty;?></td>
                 <td></td>
                 <td></td>
                 <td></td>



             </tr>
         </table>
         <?php
     }


	 else if(isset($_GET['panchayatStats'])){

         $panchayat_sel = $database->query("SELECT * FROM global_panchayats WHERE mandal='".$_GET['mandal']."'");



         ?>

         <table class="table table-condensed table-bordered">

             <tr>

                 <th rowspan="2" valign="middle" style="text-align:center">SL.No</th>
                 <th rowspan="2" valign="middle" style="text-align:center">NAME OF PANCHAYAT</th>
                 <th rowspan="2" valign="middle" style="text-align:center">NO.OF ASMNTS</th>
                 <th rowspan="2" valign="middle" style="text-align:center">NO.OF BLOCKS</th>

                 <th colspan="2"  valign="middle" style="text-align:center">MAN POWER</th>
                 <th colspan="3" valign="middle" style="text-align:center">TRANSPORTATION </th>
                 <th colspan="2" valign="middle" style="text-align:center">INFRASTRUCTURE</th>
                 <th colspan="6" valign="middle" style="text-align:center">DAILY COLLECTION (TONS)</th>
                 <th colspan="3" valign="middle" style="text-align:center">COMPOST</th>
                 <th colspan="3" valign="middle" style="text-align:center">VERMI COMPOST</th>
                 <th colspan="5" valign="middle" style="text-align:center">VERMI STOCK</th>
                 <th colspan="3" valign="middle" style="text-align:center">SALE</th>
             </tr>

             <tr>

                 <th>GP</th>
                 <th>MNREGS</th>

                 <th>TRACTORS</th>
                 <th>AUTOS</th>
                 <th>TRYCYCLE</th>

                 <th>SWPC</th>
                 <th></th>


                 <th>NO.OF HOUSES</th>
                 <th>QNTY</th>
                 <th>FARMER</th>
                 <th>QNTY</th>
                 <th>TOTAL(H+F)</th>
                 <th>TOTAL QNTY</th>

                 <th>NO.OFNADEP</th>
                 <th>TODAY QTY</th>
                 <th>TOTAL QTY</th>

                 <th>NO.OF VERMI</th>
                 <th>TODAY QTY</th>
                 <th>TOTAL QTY</th>

                 <th>NO.OF BATCHS</th>
                 <th>5 KG</th>
                 <th>10 KG</th>
                 <th>25 KG</th>
                 <th>TOTAL</th>

                 <th></th>
                 <th></th>
                 <th></th>

             </tr>

             <?php

             $total_assessments = 0;
             $total_blocks = 0;
             $total_gp = 0;
             $total_tractors=0;
             $total_autos= 0;
             $total_tricycle=0;
             $total_houses=0;
             $total_qty1 = 0;
             $total_farmer=0;
             $total_qty2=0;
             $total_qty=0;
             $total_nadep=0;
             $total_today_nadep=0;
             $total_qty3=0;
             $total_vermi=0;
             $total_today_vermi=0;
             $total_qty4=0;
             $total_batch=0;
             $total_qty5=0;
             $total_qty6=0;
             $total_qty7=0;
             $total_compost_qty=0;
             $total_hf=0;
             $fromdate=strtotime(date('d-m-Y'));
             $todate=strtotime(date('d-m-Y'). ' 23:59:59');


             $slno=0;

             while($p = mysqli_fetch_array($panchayat_sel)){

                 $slno++;

                 $panchayat_id = $p['panchayat_id'];

                 ?>
                 <tr>
                     <td><?php echo $slno;?></td>
                     <td><a onclick="setStateGet('statistics','<?php echo SECURE_PATH;?>trough/process.php','dashBoard=1&select_panchayatStats=true&panchayat_id=<?php echo $panchayat_id;?>');"><?php echo ucwords($p['panchayat']);?></a></td>
                     <td>
                         <?php
                         $no_assessments = $database->query("SELECT rfid_tags.* FROM rfid_tags,global_panchayats where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = rfid_tags.panchayat ");
                         echo mysqli_num_rows($no_assessments);
                         $total_assessments += mysqli_num_rows($no_assessments);
                         ?>
                     </td>

                     <td>
                         <?php
                         $no_blocks = $database->query("SELECT swm_blocks.block_no FROM swm_blocks,global_panchayats where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_blocks.panchayat");
                         echo mysqli_num_rows($no_blocks);
                         $total_blocks += mysqli_num_rows($no_blocks);
                         ?>
                     </td>

                     <td>
                         <?php
                         $gp = $database->query("SELECT swm_blocks.mobile FROM swm_blocks,global_panchayats where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_blocks.panchayat group by swm_blocks.mobile");
                         echo mysqli_num_rows($gp);
                         $total_gp += mysqli_num_rows($gp);
                         ?>
                     </td>

                     <td>NA</td>

                     <td>
                         <?php
                         $tractor = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=3");
                         echo mysqli_num_rows($tractor);
                         $total_tractors += mysqli_num_rows($tractor);
                         ?>
                     </td>

                     <td>
                         <?php
                         $autos = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=1");
                         echo mysqli_num_rows($autos);
                         $total_autos += mysqli_num_rows($autos);
                         ?>
                     </td>

                     <td>
                         <?php
                         $tricycle = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=2");
                         echo mysqli_num_rows($tricycle);
                         $total_tricycle += mysqli_num_rows($tricycle);
                         ?>
                     </td>

                     <td>NA</td>
                     <td>NA</td>

                     <td>
                         <?php
                         $houses = $database->query("SELECT swm_trough_filling.* FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source IN (1,2,3,4,5) and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                         echo mysqli_num_rows($houses);
                         $h = mysqli_num_rows($houses);
                         $total_houses += mysqli_num_rows($houses);
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty1=0;
                         $q = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source IN (1,2,3,4,5 ) and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                         if(mysqli_num_rows($q)){
                             while($house_qty=mysqli_fetch_array($q)){
                                 $qty1 += $house_qty['quantity'];
                             }
                         }
                         echo $qty1;
                         $total_qty1 += $qty1;
                         ?>
                     </td>

                     <td>
                         <?php
                         $farmers = $database->query("SELECT swm_trough_filling.* FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source=6 and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                         echo mysqli_num_rows($farmers);
                         $f = mysqli_num_rows($farmers);
                         $total_farmer += mysqli_num_rows($farmers);
                         ?>
                     </td>


                     <td>
                         <?php
                         $qty2=0;
                         $query = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source=6 and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                         if(mysqli_num_rows($query)){
                             while($farmer_qty=mysqli_fetch_array($query)){
                                 $qty2 += $farmer_qty['quantity'];
                             }
                         }
                         echo $qty2;
                         $total_qty2 += $qty2;
                         ?>
                     </td>

                     <td><?php $hf = $h+$f;
                         echo $hf;
                         $total_hf += $hf;
                         ?></td>

                     <td><?php echo $qty1+$qty2;
                         $total_qty += $qty1+$qty2;
                         ?>
                     </td>


                     <td>
                         <?php
                         $no_nadep = $database->query("SELECT swm_troughs.trough_id FROM global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2");
                         echo mysqli_num_rows($no_nadep);
                         $total_nadep += mysqli_num_rows($no_nadep);
                         ?>
                     </td>

                     <td>
                         <?php
                         $ntoday_qty=0;
                         $query = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."' and swm_trough_filling.trough_id in (select trough_id from swm_trough_log where close_time>='".$fromdate."' and close_time<='".$todate."')");
                         if(mysqli_num_rows($query)){
                             while($nadep_today=mysqli_fetch_array($query)){
                                 $ntoday_qty += $nadep_today['quantity'];
                             }
                         }
                         echo $ntoday_qty;
                         $total_today_nadep += $ntoday_qty;
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty3=0;
                         $query = $database->query("SELECT swm_trough_log.qty FROM swm_trough_log,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_log.trough_id and open_time in (select max(open_time) from swm_trough_log WHERE LENGTH(close_time)>0 group by trough_id)");
                         if(mysqli_num_rows($query)){
                             while($nadep_qty=mysqli_fetch_array($query)){
                                 $qty3 += $nadep_qty['qty'];
                             }
                         }
                         echo $qty3;
                         $total_qty3 += $qty3;
                         ?>
                     </td>

                     <td>
                         <?php
                         $no_vermi = $database->query("SELECT swm_troughs.trough_id FROM global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2");
                         echo mysqli_num_rows($no_vermi);
                         $total_vermi += mysqli_num_rows($no_vermi);
                         ?>
                     </td>

                     <td>
                         <?php
                         $vtoday_qty=0;
                         $query = $database->query("SELECT swm_vermi_filling.qty FROM swm_vermi_filling,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2 and swm_troughs.status=1 and swm_troughs.trough_id=swm_vermi_filling.vermi_trough and swm_vermi_filling.timestamp>='".$fromdate."' and swm_vermi_filling.timestamp<='".$todate."'");
                         if(mysqli_num_rows($query)){
                             while($vermi_today=mysqli_fetch_array($query)){
                                 $vtoday_qty += $vermi_today['qty'];
                             }
                         }
                         echo $vtoday_qty;
                         $total_today_vermi += $vtoday_qty;
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty4=0;
                         $query = $database->query("SELECT swm_trough_log.qty FROM swm_trough_log,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_log.trough_id and open_time in (select max(open_time) from swm_trough_log WHERE LENGTH(close_time)>0 group by trough_id)");
                         if(mysqli_num_rows($query)){
                             while($vermi_qty=mysqli_fetch_array($query)){
                                 $qty4 += $vermi_qty['qty'];
                             }
                         }
                         echo $qty4;
                         $total_qty4 += $qty4;
                         ?>
                     </td>


                     <td>
                         <?php
                         $no_batch = $database->query("SELECT compost.batch_no FROM global_panchayats,compost where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = compost.panchayat");
                         echo mysqli_num_rows($no_batch);
                         $total_batch += mysqli_num_rows($no_batch);
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty5=0;
                         $query = $database->query("SELECT compost.5kg_bags FROM global_panchayats,compost where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = compost.panchayat");
                         if(mysqli_num_rows($query)){
                             while($vermi_qty=mysqli_fetch_array($query)){
                                 $qty5 += $vermi_qty['5kg_bags'];
                             }
                         }
                         echo $qty5;
                         $total_qty5 += $qty5;
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty6=0;
                         $query = $database->query("SELECT compost.10kg_bags FROM global_panchayats,compost where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = compost.panchayat");
                         if(mysqli_num_rows($query)){
                             while($vermi_qty=mysqli_fetch_array($query)){
                                 $qty6 += $vermi_qty['10kg_bags'];
                             }
                         }
                         echo $qty6;
                         $total_qty6 += $qty6;
                         ?>
                     </td>
                     <td>
                         <?php
                         $qty7=0;
                         $query = $database->query("SELECT compost.25kg_bags FROM global_panchayats,compost where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = compost.panchayat");
                         if(mysqli_num_rows($query)){
                             while($vermi_qty=mysqli_fetch_array($query)){
                                 $qty7 += $vermi_qty['25kg_bags'];
                             }
                         }
                         echo $qty7;
                         $total_qty7 += $qty7;
                         ?>
                     </td>
                     <td><?php
                         echo $qty5+$qty6+$qty7;
                         $total_compost_qty +=  $qty5+$qty6+$qty7;
                         ?>
                     </td>
                     <td>NA</td>
                     <td>NA</td>
                     <td>NA</td>

                 </tr>
                 <?php

             }
             ?>

             <tr>
                 <th></th>
                 <th>Total</th>
                 <th><?php echo $total_assessments;?></th>
                 <th><?php echo $total_blocks;?></th>
                 <th><?php echo $total_gp;?></th>
                 <th></th>

                 <th><?php echo $total_tractors;?></th>
                 <th><?php echo $total_autos;?></th>
                 <th><?php echo $total_tricycle;?></th>

                 <th></th>
                 <th></th>

                 <th><?php echo $total_houses;?></th>
                 <th><?php echo $total_qty1;?></th>
                 <th><?php echo $total_farmer;?></th>
                 <th><?php echo $total_qty2;?></th>
                 <th><?php echo $total_hf;?></th>
                 <th><?php echo $total_qty;?></th>

                 <th><?php echo $total_nadep;?></th>
                 <th><?php echo $total_today_nadep;?></th>
                 <th><?php echo $total_qty3;?></th>

                 <th><?php echo $total_vermi;?></th>
                 <th><?php echo $total_today_vermi;?></th>
                 <th><?php echo $total_qty4;?></th>

                 <td><?php echo $total_batch;?></td>
                 <td><?php echo $total_qty5;?></td>
                 <td><?php echo $total_qty6;?></td>
                 <td><?php echo $total_qty7;?></td>
                 <td><?php echo $total_compost_qty;?></td>
                 <td></td>
                 <td></td>
                 <td></td>

             </tr>
         </table>
         <?php
     }

     else if(isset($_GET['select_panchayatStats'])){

         $panchayat_sel = $database->query("SELECT * FROM global_panchayats WHERE panchayat_id='".$_GET['panchayat_id']."'");



         ?>

         <table class="table table-condensed table-bordered">

             <tr>

                 <th rowspan="2" valign="middle" style="text-align:center">SL.No</th>
                 <th rowspan="2" valign="middle" style="text-align:center">NAME OF PANCHAYAT</th>
                 <th rowspan="2" valign="middle" style="text-align:center">NO.OF ASMNTS</th>
                 <th rowspan="2" valign="middle" style="text-align:center">NO.OF BLOCKS</th>

                 <th colspan="2"  valign="middle" style="text-align:center">MAN POWER</th>
                 <th colspan="3" valign="middle" style="text-align:center">TRANSPORTATION </th>
                 <th colspan="2" valign="middle" style="text-align:center">INFRASTRUCTURE</th>
                 <th colspan="6" valign="middle" style="text-align:center">DAILY COLLECTION (TONS)</th>
                 <th colspan="3" valign="middle" style="text-align:center">COMPOST</th>
                 <th colspan="3" valign="middle" style="text-align:center">VERMI COMPOST</th>
                 <th colspan="5" valign="middle" style="text-align:center">VERMI STOCK</th>
                 <th colspan="3" valign="middle" style="text-align:center">SALE</th>
             </tr>

             <tr>

                 <th>GP</th>
                 <th>MNREGS</th>

                 <th>TRACTORS</th>
                 <th>AUTOS</th>
                 <th>TRYCYCLE</th>

                 <th>SWPC</th>
                 <th></th>


                 <th>NO.OF HOUSES</th>
                 <th>QNTY</th>
                 <th>FARMER</th>
                 <th>QNTY</th>
                 <th>TOTAL(H+F)</th>
                 <th>TOTAL QNTY</th>

                 <th>NO.OFNADEP</th>
                 <th>TODAY QTY</th>
                 <th>TOTAL QTY</th>

                 <th>NO.OF VERMI</th>
                 <th>TODAY QTY</th>
                 <th>TOTAL QTY</th>

                 <th>NO.OF BATCHS</th>
                 <th>5 KG</th>
                 <th>10 KG</th>
                 <th>25 KG</th>
                 <th>TOTAL</th>

                 <th></th>
                 <th></th>
                 <th></th>

             </tr>

             <?php

             $total_assessments = 0;
             $total_blocks = 0;
             $total_gp = 0;
             $total_tractors=0;
             $total_autos= 0;
             $total_tricycle=0;
             $total_houses=0;
             $total_qty1 = 0;
             $total_farmer=0;
             $total_qty2=0;
             $total_qty=0;
             $total_nadep=0;
             $total_today_nadep=0;
             $total_qty3=0;
             $total_vermi=0;
             $total_today_vermi=0;
             $total_qty4=0;
             $total_batch=0;
             $total_qty5=0;
             $total_qty6=0;
             $total_qty7=0;
             $total_compost_qty=0;
             $total_hf=0;
             $fromdate=strtotime(date('d-m-Y'));
             $todate=strtotime(date('d-m-Y'). ' 23:59:59');


             $slno=0;

             while($p = mysqli_fetch_array($panchayat_sel)){

                 $slno++;

                 $panchayat_id = $p['panchayat_id'];

                 ?>
                 <tr>
                     <td><?php echo $slno;?></td>
                     <td><a><?php echo ucwords($p['panchayat']);?></a></td>
                     <td>
                         <?php
                         $no_assessments = $database->query("SELECT rfid_tags.* FROM rfid_tags,global_panchayats where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = rfid_tags.panchayat ");
                         echo mysqli_num_rows($no_assessments);
                         $total_assessments += mysqli_num_rows($no_assessments);
                         ?>
                     </td>

                     <td>
                         <?php
                         $no_blocks = $database->query("SELECT swm_blocks.block_no FROM swm_blocks,global_panchayats where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_blocks.panchayat");
                         echo mysqli_num_rows($no_blocks);
                         $total_blocks += mysqli_num_rows($no_blocks);
                         ?>
                     </td>

                     <td>
                         <?php
                         $gp = $database->query("SELECT swm_blocks.mobile FROM swm_blocks,global_panchayats where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_blocks.panchayat group by swm_blocks.mobile");
                         echo mysqli_num_rows($gp);
                         $total_gp += mysqli_num_rows($gp);
                         ?>
                     </td>

                     <td>NA</td>

                     <td>
                         <?php
                         $tractor = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=3");
                         echo mysqli_num_rows($tractor);
                         $total_tractors += mysqli_num_rows($tractor);
                         ?>
                     </td>

                     <td>
                         <?php
                         $autos = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=1");
                         echo mysqli_num_rows($autos);
                         $total_autos += mysqli_num_rows($autos);
                         ?>
                     </td>

                     <td>
                         <?php
                         $tricycle = $database->query("SELECT swm_blocks.mode_of_transport FROM swm_blocks,global_panchayats where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_blocks.panchayat and swm_blocks.mode_of_transport=2");
                         echo mysqli_num_rows($tricycle);
                         $total_tricycle += mysqli_num_rows($tricycle);
                         ?>
                     </td>

                     <td>NA</td>
                     <td>NA</td>

                     <td>
                         <?php
                         $houses = $database->query("SELECT swm_trough_filling.* FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source IN (1,2,3,4,5) and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                         echo mysqli_num_rows($houses);
                         $h = mysqli_num_rows($houses);
                         $total_houses += mysqli_num_rows($houses);
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty1=0;
                         $q = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source IN (1,2,3,4,5 ) and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                         if(mysqli_num_rows($q)){
                             while($house_qty=mysqli_fetch_array($q)){
                                 $qty1 += $house_qty['quantity'];
                             }
                         }
                         echo $qty1;
                         $total_qty1 += $qty1;
                         ?>
                     </td>

                     <td>
                         <?php
                         $farmers = $database->query("SELECT swm_trough_filling.* FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source=6 and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                         echo mysqli_num_rows($farmers);
                         $f = mysqli_num_rows($farmers);
                         $total_farmer += mysqli_num_rows($farmers);
                         ?>
                     </td>


                     <td>
                         <?php
                         $qty2=0;
                         $query = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=1 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.source=6 and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."'");
                         if(mysqli_num_rows($query)){
                             while($farmer_qty=mysqli_fetch_array($query)){
                                 $qty2 += $farmer_qty['quantity'];
                             }
                         }
                         echo $qty2;
                         $total_qty2 += $qty2;
                         ?>
                     </td>

                     <td><?php $hf = $h+$f;
                         echo $hf;
                         $total_hf += $hf;
                         ?></td>

                     <td><?php echo $qty1+$qty2;
                         $total_qty += $qty1+$qty2;
                         ?>
                     </td>


                     <td>
                         <?php
                         $no_nadep = $database->query("SELECT swm_troughs.trough_id FROM global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2");
                         echo mysqli_num_rows($no_nadep);
                         $total_nadep += mysqli_num_rows($no_nadep);
                         ?>
                     </td>

                     <td>
                         <?php
                         $ntoday_qty=0;
                         $query = $database->query("SELECT swm_trough_filling.quantity FROM swm_trough_filling,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_filling.trough_id and swm_trough_filling.timestamp>='".$fromdate."' and swm_trough_filling.timestamp<='".$todate."' and swm_trough_filling.trough_id in (select trough_id from swm_trough_log where close_time>='".$fromdate."' and close_time<='".$todate."')");
                         if(mysqli_num_rows($query)){
                             while($nadep_today=mysqli_fetch_array($query)){
                                 $ntoday_qty += $nadep_today['quantity'];
                             }
                         }
                         echo $ntoday_qty;
                         $total_today_nadep += $ntoday_qty;
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty3=0;
                         $query = $database->query("SELECT swm_trough_log.qty FROM swm_trough_log,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=1 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_log.trough_id and open_time in (select max(open_time) from swm_trough_log WHERE LENGTH(close_time)>0 group by trough_id)");
                         if(mysqli_num_rows($query)){
                             while($nadep_qty=mysqli_fetch_array($query)){
                                 $qty3 += $nadep_qty['qty'];
                             }
                         }
                         echo $qty3;
                         $total_qty3 += $qty3;
                         ?>
                     </td>

                     <td>
                         <?php
                         $no_vermi = $database->query("SELECT swm_troughs.trough_id FROM global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2");
                         echo mysqli_num_rows($no_vermi);
                         $total_vermi += mysqli_num_rows($no_vermi);
                         ?>
                     </td>

                     <td>
                         <?php
                         $vtoday_qty=0;
                         $query = $database->query("SELECT swm_vermi_filling.qty FROM swm_vermi_filling,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2 and swm_troughs.status=1 and swm_troughs.trough_id=swm_vermi_filling.vermi_trough and swm_vermi_filling.timestamp>='".$fromdate."' and swm_vermi_filling.timestamp<='".$todate."'");
                         if(mysqli_num_rows($query)){
                             while($vermi_today=mysqli_fetch_array($query)){
                                 $vtoday_qty += $vermi_today['qty'];
                             }
                         }
                         echo $vtoday_qty;
                         $total_today_vermi += $vtoday_qty;
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty4=0;
                         $query = $database->query("SELECT swm_trough_log.qty FROM swm_trough_log,global_panchayats,swm_troughs where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = swm_troughs.panchayat and swm_troughs.trough_type=2 and swm_troughs.status=2 and swm_troughs.trough_id=swm_trough_log.trough_id and open_time in (select max(open_time) from swm_trough_log WHERE LENGTH(close_time)>0 group by trough_id)");
                         if(mysqli_num_rows($query)){
                             while($vermi_qty=mysqli_fetch_array($query)){
                                 $qty4 += $vermi_qty['qty'];
                             }
                         }
                         echo $qty4;
                         $total_qty4 += $qty4;
                         ?>
                     </td>



                     <td>
                         <?php
                         $no_batch = $database->query("SELECT compost.batch_no FROM global_panchayats,compost where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = compost.panchayat");
                         echo mysqli_num_rows($no_batch);
                         $total_batch += mysqli_num_rows($no_batch);
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty5=0;
                         $query = $database->query("SELECT compost.5kg_bags FROM global_panchayats,compost where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = compost.panchayat");
                         if(mysqli_num_rows($query)){
                             while($vermi_qty=mysqli_fetch_array($query)){
                                 $qty5 += $vermi_qty['5kg_bags'];
                             }
                         }
                         echo $qty5;
                         $total_qty5 += $qty5;
                         ?>
                     </td>

                     <td>
                         <?php
                         $qty6=0;
                         $query = $database->query("SELECT compost.10kg_bags FROM global_panchayats,compost where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = compost.panchayat");
                         if(mysqli_num_rows($query)){
                             while($vermi_qty=mysqli_fetch_array($query)){
                                 $qty6 += $vermi_qty['10kg_bags'];
                             }
                         }
                         echo $qty6;
                         $total_qty6 += $qty6;
                         ?>
                     </td>
                     <td>
                         <?php
                         $qty7=0;
                         $query = $database->query("SELECT compost.25kg_bags FROM global_panchayats,compost where global_panchayats.panchayat_id='".$panchayat_id."' and global_panchayats.panchayat_id = compost.panchayat");
                         if(mysqli_num_rows($query)){
                             while($vermi_qty=mysqli_fetch_array($query)){
                                 $qty7 += $vermi_qty['25kg_bags'];
                             }
                         }
                         echo $qty7;
                         $total_qty7 += $qty7;
                         ?>
                     </td>
                     <td><?php
                         echo $qty5+$qty6+$qty7;
                         $total_compost_qty +=  $qty5+$qty6+$qty7;
                         ?>
                     </td>
                     <td>NA</td>
                     <td>NA</td>
                     <td>NA</td>

                 </tr>
                 <?php

             }
             ?>

             <tr>
                 <th></th>
                 <th>Total</th>
                 <th><?php echo $total_assessments;?></th>
                 <th><?php echo $total_blocks;?></th>
                 <th><?php echo $total_gp;?></th>
                 <th></th>

                 <th><?php echo $total_tractors;?></th>
                 <th><?php echo $total_autos;?></th>
                 <th><?php echo $total_tricycle;?></th>

                 <th></th>
                 <th></th>

                 <th><?php echo $total_houses;?></th>
                 <th><?php echo $total_qty1;?></th>
                 <th><?php echo $total_farmer;?></th>
                 <th><?php echo $total_qty2;?></th>
                 <th><?php echo $total_hf;?></th>
                 <th><?php echo $total_qty;?></th>

                 <th><?php echo $total_nadep;?></th>
                 <th><?php echo $total_today_nadep;?></th>
                 <th><?php echo $total_qty3;?></th>

                 <th><?php echo $total_vermi;?></th>
                 <th><?php echo $total_today_vermi;?></th>
                 <th><?php echo $total_qty4;?></th>

                 <td><?php echo $total_batch;?></td>
                 <td><?php echo $total_qty5;?></td>
                 <td><?php echo $total_qty6;?></td>
                 <td><?php echo $total_qty7;?></td>
                 <td><?php echo $total_compost_qty;?></td>
                 <td></td>
                 <td></td>
                 <td></td>


             </tr>
         </table>
         <?php
     }


}


//Display house_tax
if(isset($_REQUEST['tableDisplay'])){





    function daysOfWeekBetween($start_date, $end_date, $weekDay)
{
   $first_date = strtotime($start_date." -1 days");
   $first_date = strtotime(date("M d Y",$first_date)." next ".$weekDay);

   $last_date = strtotime($end_date." +1 days");
   $last_date = strtotime(date("M d Y",$last_date)." last ".$weekDay);

   return  floor(($last_date - $first_date)/(7*86400)) + 1;
}

    unset($_SESSION['error']);
$_SESSION['error'] = array();

	$post = $session->cleanInput($_GET);

		 $field = 'panchayat';
			if(!$post['panchayat'] || strlen(trim($post['panchayat'])) == 0){
			  $_SESSION['error'][$field] = "* Select a Panchayat";
			}



/* $field = 'due_year';
			if(!$post['due_year'] || strlen(trim($post['due_year'])) == 0){
			  $_SESSION['error'][$field] = "* Select a Due Year";
			}*/





	if(count($_SESSION['error']) > 0){
	?>
    <script type="text/javascript">
    setStateGet('adminForm','<?php echo SECURE_PATH;?>drains_public/process.php','addForm=1&panchayat=<?php echo $post['panchayat'];?>');

    </script>

<?php
	}

	else{


/*
 Query:
 select swm_drains.block,swm_drains.panchayat,swm_drains.assessment_no,swm_blocks.day_frequency,swm_blocks.time_slots,swm_blocks.mobile
 * from swm_drains,swm_blocks where swm_drains.panchayat='1130101' and  swm_blocks.panchayat='1130101' and swm_drains.block=1 and swm_blocks.block=1
 * and swm_blocks.time_slots like '1%' and swm_blocks.agency=2;
 */

//Pagination code
  $limit=50;
   if(isset($_GET['page']))
   {
      $start = ($_GET['page'] - 1) * $limit;     //first item to display on this page
      $page=$_GET['page'];
   }
   else
   {
	   $start = 0;      //if no page var is given, set start to 0
		$page=0;
   }
$tableName = 'swm_drains_reports,swm_drains';
$condition='';

if(isset($_GET['panchayat'])){

		if(strlen($_GET['panchayat'])>0){
		if(strlen($condition) > 0){
			   $condition.= " AND ";
			}

                            $condition.=" swm_drains.`panchayat` = '".$_GET['panchayat']."'  and swm_drains_reports.drain_id=swm_drains.id";


		}

	}

if(isset($_GET['block'])){

		if(strlen($_GET['block'])>0){

			if(strlen($condition) > 0){
			   $condition.= " AND ";
			}

		    $condition.= "swm_drains.`block` = '".$_GET['block']."'  ";
		}

	}


if(isset($_GET['drain_type'])){

		if(strlen($_GET['drain_type'])>0){

			if(strlen($condition) > 0){
			   $condition.= " AND ";
			}

		//	$years = explode('-',$_GET['due_year']);
			  $condition.= "swm_drains.drain_type = '".$_GET['drain_type']."'";


		  //  $condition.= "`created_time` BETWEEN   '".strtotime('1-4-'.$years[0])."' AND '".strtotime('1-4-'.$years[1])."'";
		}

	}




if(strlen($_GET['from_date'])==0 && strlen($_GET['to_date'])==0)
{
    $t1=strtotime(date('d-m-Y').' 23:59:59');
    $end_time=date('d-m-Y',$t1);
    $r= strtotime($end_time.'-30 days');
    $start_time=date('d-m-Y',$r);

}
else if(strlen($_GET['from_date'])==0 && strlen($_GET['to_date'])>0)
{
 $t1=strtotime(date('d-m-Y').' 23:59:59');
      $start_time=date('d-m-Y',$t1);
 $end_time=$_GET['to_date'];
}
 else if(strlen($_GET['from_date'])>0 && strlen($_GET['to_date'])==0){
  $start_time=$_GET['from_date'];
  $t1=strtotime(date('d-m-Y').' 23:59:59');
      $end_time=date('d-m-Y',$t1);
}
else
{
    $start_time=$_GET['from_date'];
    $end_time=$_GET['to_date'];
}


if(strlen($condition) > 0){
    $condition = 'WHERE '.$condition;
}
//$query_string = $_SERVER['QUERY_STRING'];
//echo $condition;
$pagination = $session->showPagination(SECURE_PATH."drains_public/process.php?tableDisplay=1&",$tableName,$start,$limit,$page,$condition);
  $q = "SELECT swm_drains.block,swm_drains.street_name FROM $tableName ".$condition." ORDER BY swm_drains.panchayat ASC";

  echo "<span style='display:none'>".$q."</span>";

   $result_sel = $database->query($q);
   $numres = mysqli_num_rows($result_sel);
    $query = "SELECT  distinct(swm_drains_reports.drain_id),swm_drains.block,swm_drains.street_name,swm_drains_reports.status,swm_drains_reports.remarks,swm_drains.drain_type,swm_drains.length,swm_drains.width,swm_drains_reports.latitude,swm_drains_reports.longitude,swm_drains_reports.photo,swm_drains_reports.latitude2,swm_drains_reports.longitude2,swm_drains_reports.photo2 FROM $tableName ".$condition."  ORDER BY swm_drains.panchayat ASC,swm_drains_reports.timestamp DESC LIMIT $start,$limit";
  $data_sel = $database->query($query);

if(($start+$limit) > $numres){
	 $onpage = $numres;
	 }
	 else{
	  $onpage = $start+$limit;
	 }
	 	$drain_types = array('Kaccha','Pakka','Underground');

	 if($numres > 0){

		 $que= base64_encode($q);

		 echo '<p  class="pull-right label label-info" >Showing '.($start+1).' - '.($onpage).' results out of '.$numres.'</p><p  class="pull-left " ><a href="../drains_public/e03export.php?q='.$que.'&start_time='.$start_time.'&end_time='.$end_time.'&panchayat='.$_GET['panchayat'].'" class="btn btn-warning btn-sm" target="_blank"><i class="fa fa-download"></i> Download Excel</a></p>';







	?>







     <div style="text-align:center"> <?php echo $pagination ;?></div>
	<br />
  <div class="clearfix"></div>


<br />

<div id="swm_dashboard_table" style="width:99%; overflow-x:auto; white-space: nowrap;overflow-y:hidden;">



<table class="table table-striped table-bordered table-condensed table-hover">
  <tr>
  <th>Block No</th>
  <th>Street Name</th>
  <th>Drain Type</th>

  <th>Length(mts)</th>
  <th>Width(mts)</th>
   <th>Status</th>
 <th>Remarks</th>

  <th>Photos</th>


  </tr>
	<?php
	if(isset($_GET['page'])){
	if($_GET['page']==1)
	$i=1;
	else
	$i=(($_GET['page']-1)*50)+1;
	}else $i=1;

while($value = mysqli_fetch_array($data_sel))
{


	?>
  <tr>
      <td><?php echo $value['block'];?></td>
      <td><?php echo ucwords($value['street_name']);?></td>
       <td><?php echo $drain_types[$value['drain_type']];?></td>


      <td><?php echo $value['length'];?></td>

      <td><?php echo $value['width'];?></td>




      <td><?php

		  if($value['status'] == 1){
			  echo '<span class="text-success">Cleaned</span>';
		  }
		  else{
			  echo '<span class="text-error">Not Cleaned</span>';
		  }

	  ?></td>

      <td>
<?php echo $value['remarks'];?>
</td>
      <td>
      <?php
	  if($value['status'] == 1){

		   ?>

           <div class="col-sm-6" style="text-align:center;">
                  <?php
				    if(strlen($value['photo']) > 0){
					    ?>
                           <a  target="_blank" href="../mobile/app_service/files/<?php echo $value['photo'];?>"><img src="../mobile/app_service/files/<?php echo $value['photo'];?>" style="width:90px;height:auto;" /></a>

                           <p><a target="_blank" href="http://maps.google.com/maps?q=<?php echo $value['latitude'].','.$value['longitude'];?>"><?php echo $value['latitude'].','.$value['longitude'];?></a></p>
                        <?php
					}
				  ?>
           </div>


           <div class="col-sm-6" style="text-align:center;">
                  <?php
				    if(strlen($value['photo2']) > 0){
					    ?>
                           <a  target="_blank" href="../mobile/app_service/files/<?php echo $value['photo2'];?>"><img src="../mobile/app_service/files/<?php echo $value['photo2'];?>" style="width:90px;height:auto;" /></a>
                           <p><a target="_blank" href="http://maps.google.com/maps?q=<?php echo $value['latitude'].','.$value['longitude'];?>"><?php echo $value['latitude2'].','.$value['longitude2'];?></a></p>
                        <?php
					}
				  ?>
           </div>



           <?php
	  }
	  ?>
      <div style="clear:both"></div>
      </td>


  </tr>
	<?php
}
	?>




  </tr>
    </table>

  </div>
    <script type="text/javascript">

    $("#swm_dashboard_table").niceScroll({styler:"fb",cursorcolor:"#e8403f", cursorwidth: '3', cursorborderradius: '10px', background: '#404040', spacebarenabled:true, cursorborder: ''});

</script>

    <div style="text-align:center"> <?php echo $pagination ;?></div>
	<?php
	 }
else{
	?>
    <div style="text-align:center">No Results Found</div>
    <?php
}

	}

}


function moneyFormatIndia($num){
    $explrestunits = "" ;
    if(strlen($num)>3){
        $lastthree = substr($num, strlen($num)-3, strlen($num));
        $restunits = substr($num, 0, strlen($num)-3); // extracts the last three digits
        $restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
        $expunit = str_split($restunits, 2);
        for($i=0; $i<sizeof($expunit); $i++){
            // creates each of the 2's group and adds a comma to the end
            if($i==0)
            {
                $explrestunits .= (int)$expunit[$i].","; // if is first value , convert into integer
            }else{
                $explrestunits .= $expunit[$i].",";
            }
        }
        $thecash = $explrestunits.$lastthree;
    } else {
        $thecash = $num;
    }
    return $thecash; // writes the final format where $currency is the currency symbol.
}

//Display house_tax
if(isset($_GET['homeDisplay'])){ }

?>    