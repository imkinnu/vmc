<?php
include('../include/session.php');

if(!$session->logged_in){
?>
<script type="text/javascript">
setStateGet('main','login_process.php','loginForm=1');
</script>

<?php
}

//Metircs Forms, Tables and Functions
//Display assignments form
if(isset($_REQUEST['addForm'])){}

//Process and Validate POST data
if(isset($_POST['validateForm'])){}

//Delete assignments 
if(isset($_GET['rowDelete'])){}

//Display assignments
if(isset($_GET['tableDisplay'])){
	
	
?>
        
        
 <div class="clr"></div>
 <?php
  $query = "SELECT * FROM log WHERE display = '1' ORDER BY timestamp DESC";
 ?>
   <div id="activity">
     <ul>
       <?php
	    $data_sel = $database->query($query);
		echo '<li>['.date("M j, Y, g:i a").'] : ... <blink class="blink">|</blink></li>';
		while($data = mysql_fetch_array($data_sel)){
		  if($data['display'] == 1 || $session->isAdmin()){
		  echo '<li>';
		  echo '['.date("M j, Y, g:i a",$data['timestamp']).'] : ';
		  echo $data['text'].', ';
		  echo 'From: '.$data['ip'];
		  echo '</li>';
		  }
		}
	   ?>
     </ul> 
   </div>
<?php
	
	}
?>
<script type="text/javascript"> 


$("#leftDiv").sticky({topSpacing:10});

$('.blink').blink({delay:400});

</script>