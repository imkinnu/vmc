<?php
include('../include/session.php');
if(!$session->logged_in){
?>
<script type="text/javascript">
setStateGet('main','<?php echo SECURE_PATH;?>login_process.php','loginForm=1');
</script>

<?php
}
else{
?>
<h3>Access Log</h3>

<script type="text/javascript">

function doBlink() {
var blink = document.all.tags("BLINK")
for (var i=0; i<blink.length; i++)
blink[i].style.visibility = blink[i].style.visibility == "" ? "hidden" : ""
}
function startBlink() {
if (document.all)
setInterval("doBlink()",400)
}


</script>

<div id="adminLog">

<script type="text/javascript">



setStateGet('adminLog','<?php echo SECURE_PATH;?>log/process.php','tableDisplay=1&page=<?php if(isset($_GET['page'])){echo $_GET['page'];}else{ echo '1';}?>');
</script>

</div>
<?php
}
?>