<?php
ini_set('display_errors', 'On');
 error_reporting(E_ALL);
ini_set("memory_limit", "-1");
/** PHPExcel */
require_once '../Classes/PHPExcel.php';

 include("../include/session.php");


$appcon2 = mysqli_connect(DB_SERVER22, DB_USER22, DB_PASS22,"priswg_new") or die(mysqli_error($appcon2));

function query2($sql){
    global $appcon2;
    return 	mysqli_query($appcon2,$sql);
}



if(!isset($_GET['q'])){
	header("Location: ../");
	
	exit;
	
}
 

 $sql=urldecode( $_GET['q']);

 	$due_year = date('Y').'-'.substr(date('Y')+1,2);
	 
	if(time()  <  strtotime('01-'.VALID_MONTH.'-'.date('Y')))
     	$due_year = (date('Y')-1).'-'.substr(date('Y'),2);
		
		if(isset($_SESSION['demandq_dueyear'])){
	 $due_year = $_SESSION['demandq_dueyear'];
	
		}

//unset($userinfo[$_GET['q']]);
  $sql=base64_decode($sql);
$query=query2($sql);

$rows=mysqli_num_rows($query);
// Create new PHPExcel object
$objPHPExcel = new PHPExcel();

// Set properties
$objPHPExcel->getProperties()->setCreator("Demand Report")
							 ->setLastModifiedBy("Demand Report")
							 ->setTitle("Demand Report");
							// ->setSubject("PDF Test Document")
							// ->setDescription("Test document for PDF, generated using PHP classes.")
							// ->setKeywords("pdf php")
							// ->setCategory("Test result file");
$objPHPExcel->getActiveSheet();

//  PAGE SETUP

//$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToWidth(1);
//$objPHPExcel->getActiveSheet()->getPageSetup()->setVerticalCentered(true);
//$objPHPExcel->getActiveSheet()->getPageSetup()->setHorizontalCentered(true);


//$objPHPExcel->getActiveSheet()->getStyle('A2:F2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF0000');
$objPHPExcel->getActiveSheet()->getStyle('A2:S2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('ACACAC');
$objPHPExcel->getActiveSheet()->getStyle('A2:S2')->getFont()->setBold(true);

// COLUMN SETUP
$objPHPExcel->getActiveSheet()->getDefaultColumnDimension()->setWidth(18);

$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(8); //SNO
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(18); //TIMESTAMP
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(18);  //RECIPIENT
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(18);  //VMN
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(18);  //VMN
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(18);  //MESSAGE
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(18);  //MESSAGE
$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(25); 
$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(18); 
$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(25); 
$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(18); 
$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(25); 
$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(18);  

 
//$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(47);  //URL
$objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(20);

/*$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);*/



// setting header 



	$objPHPExcel->getActiveSheet()->mergeCells('A1:S1');
	
		$objPHPExcel->getActiveSheet()->mergeCells('H1:J1');
	$userinfo=array();//$database->getUserInfo($session->username);

$objPHPExcel->getActiveSheet()
            ->getCellByColumnAndRow('0', '1')->setValue("  \n  Demand Report\n");




$objPHPExcel->getActiveSheet()
            ->getCellByColumnAndRow('5', '1')->setValue("  \n  Generated on: ".date("j M Y, g:i A ",time())."\n  Report contains: ".$rows." results.");

  
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', '2')->setValue(" S.No");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', '2')->setValue(" HID");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('2', '2')->setValue(" District");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('3', '2')->setValue(" Division");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('4', '2')->setValue(" Mandal");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('5', '2')->setValue(" Panchayat");
 
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('6', '2')->setValue(" GP Type");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('7', '2')->setValue(" Construction Date");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('8', '2')->setValue(" Revision Date");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('9', '2')->setValue(" Owner Name");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('10', '2')->setValue(" Gender");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('11', '2')->setValue(" Father Name");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('12', '2')->setValue(" Aadhar");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('13', '2')->setValue(" Block No");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('14', '2')->setValue(" Survey No");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('15', '2')->setValue(" Door No");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('16', '2')->setValue(" Assessment No");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('17', '2')->setValue(" LP No");

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('18', '2')->setValue(" BLR No");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('19', '2')->setValue(" Site(Sq.y)");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('20', '2')->setValue(" Government Value");

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('21', '2')->setValue(" Site Value");

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('22', '2')->setValue(" Classification 1");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('23', '2')->setValue(" Status 1");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('24', '2')->setValue(" Usage 1");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('25', '2')->setValue(" PA(Sq.ft) 1");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('26', '2')->setValue(" Rate 1");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('27', '2')->setValue(" Value 1");

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('28', '2')->setValue(" Classification 2");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('29', '2')->setValue(" Status 2");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('30', '2')->setValue(" Usage 2");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('31', '2')->setValue(" PA(Sq.ft) 2");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('32', '2')->setValue(" Rate 2");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('33', '2')->setValue(" Value 2");

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('34', '2')->setValue(" Building Value");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('35', '2')->setValue(" Building age");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('36', '2')->setValue(" Depreciation");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('37', '2')->setValue(" Site+Building value");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('38', '2')->setValue(" Tax Rate");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('39', '2')->setValue(" Total House Tax");

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('40', '2')->setValue(" House Tax");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('41', '2')->setValue(" Water Tax");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('42', '2')->setValue(" Library Cess");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('43', '2')->setValue(" Drainage Tax");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('44', '2')->setValue(" Lighting Tax");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('45', '2')->setValue(" Total Tax");

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('46', '2')->setValue(" Private Taps");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('47', '2')->setValue(" Private Tap Fee");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('48', '2')->setValue(" IHHL");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('49', '2')->setValue(" Soak Pit");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('50', '2')->setValue(" Tree");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('51', '2')->setValue(" Power");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('52', '2')->setValue(" LPG");
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('53', '2')->setValue(" Mobile");

 

$sno=0;
$rcounter=2;

// data loop
$panchayat_sel = query2("SELECT SQL_NO_CACHE  * FROM global_panchayats WHERE panchayat_id = '".$_SESSION['demandq_panchayat']."'");
$panchayat_data = mysqli_fetch_array($panchayat_sel);

while($row=mysqli_fetch_array($query)){
	
	
	$rcounter++;
	$sno++;
	$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('0', $rcounter)->setValue($sno);
	
 	
		$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('1', $rcounter)->setValue($row['hid']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('2', $rcounter)->setValue(ucwords($database->get_name('global_divisions','id',$panchayat_data['division'],'division')));
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('3', $rcounter)->setValue( ucwords($database->get_name('global_districts','district_id',$panchayat_data['district'],'district')));
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('4', $rcounter)->setValue(ucwords($database->get_name('global_mandals','uid',$panchayat_data['mandal'],'mandal')));
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('5', $rcounter)->setValue(ucwords($panchayat_data['panchayat']));

if($panchayat_data['village_type'] == 0){
	$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('6', $rcounter)->setValue('Non-notified');;
	}
else{
	$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('6', $rcounter)->setValue('Notified'); ;
	}
	
	
if($row['doc'] > 0)
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('7', $rcounter)->setValue(date('d-m-Y',$row['doc']) );
else{
 
		//	 $datetime = new DateTime('@'.$row['doc']);
  
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('7', $rcounter)->setValue("");
 
}


 
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('8', $rcounter)->setValue(date('d-m-Y',$row['dov']));
 

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('9', $rcounter)->setValue(ucwords($row['full_name']) );

 if($row['gender'] == 0){
	 $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('10', $rcounter)->setValue('Female');
 }else{
     $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('10', $rcounter)->setValue('Male');
}

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('11', $rcounter)->setValue(ucwords($row['father_name']));
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('12', $rcounter)->setValue(ucwords($row['aadhar']));
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('13', $rcounter)->setValue($row['block_no']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('14', $rcounter)->setValue($row['survey_no']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('15', $rcounter)->setValue($row['door_no']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('16', $rcounter)->setValue($row['assessment_no']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('17', $rcounter)->setValue($row['lp_no']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('18', $rcounter)->setValue($row['blr_no']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('19', $rcounter)->setValue($row['site_dimentions']);

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('20', $rcounter)->setValue($row['government_value']);

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('21', $rcounter)->setValue($row['site_value']);



 $subtax_sel = query2("SELECT * FROM house_tax_listing WHERE hid = '".$row['hid']."'");
	     
		 if(mysqli_num_rows($subtax_sel) > 0){
			   
			   
			   $subtax = mysqli_fetch_array($subtax_sel);
			   $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('22', $rcounter)->setValue($database->get_name('house_types','id',$subtax['house_type'],'house_type'));
			   $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('23', $rcounter)->setValue($database->get_name('construction_status','id',$subtax['construction_status'],'construction_status'));
			   $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('24', $rcounter)->setValue($database->get_name('usages','id',$subtax['construction_usage'],'construction_usage'));
			   $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('25', $rcounter)->setValue($subtax['plingth_area']);
			   $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('26', $rcounter)->setValue($subtax['rate_per_sft']);
               $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('27', $rcounter)->setValue($subtax['calculated_value']);

 
			if(mysqli_num_rows($subtax_sel) > 1){
			  
			   $subtax = mysqli_fetch_array($subtax_sel);
			   
			   	   $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('28', $rcounter)->setValue($database->get_name('house_types','id',$subtax['house_type'],'house_type'));
			   $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('29', $rcounter)->setValue($database->get_name('construction_status','id',$subtax['construction_status'],'construction_status'));
			   $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('30', $rcounter)->setValue($database->get_name('usages','id',$subtax['construction_usage'],'construction_usage'));
			   $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('31', $rcounter)->setValue($subtax['plingth_area']);
			   $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('32', $rcounter)->setValue($subtax['rate_per_sft']);
               $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('33', $rcounter)->setValue($subtax['calculated_value']);

			 
				
			}
		 else{
			$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('28', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('29', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('30', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('31', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('32', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('33', $rcounter)->setValue(' ');

			 
		 }
			
			 
		 }
		 else{
			 $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('22', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('23', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('24', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('25', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('26', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('27', $rcounter)->setValue(' ');

			$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('28', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('29', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('30', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('31', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('32', $rcounter)->setValue(' ');
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('33', $rcounter)->setValue(' ');

		 }

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('34', $rcounter)->setValue($row['building_value']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('35', $rcounter)->setValue($row['building_age']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('36', $rcounter)->setValue($row['depreciation']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('37', $rcounter)->setValue($row['total_value']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('38', $rcounter)->setValue($row['gp_tax']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('39', $rcounter)->setValue(round($row['total_house_tax'],2));
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('40', $rcounter)->setValue(round($row['total_house_tax']));
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('41', $rcounter)->setValue($row['total_water_tax']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('42', $rcounter)->setValue($row['lc']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('43', $rcounter)->setValue($row['drainage_tax']);

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('44', $rcounter)->setValue($row['lighting_tax']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('45', $rcounter)->setValue($row['house_tax']);
 
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('46', $rcounter)->setValue($row['private_taps']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('47', $rcounter)->setValue($row['water_tax']);

$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('48', $rcounter)->setValue($row['ihhl']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('49', $rcounter)->setValue($row['two_wheeler']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('50', $rcounter)->setValue($row['four_wheeler']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('51', $rcounter)->setValue($row['power_connection']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('52', $rcounter)->setValue($row['lpg_connection']);
$objPHPExcel->getActiveSheet()->getCellByColumnAndRow('53', $rcounter)->setValue($row['mobile']);


	 
    
	
	
}




// Set active sheet index to the first sheet, so Excel opens this as the first sheet

$filename="Demand-Report-".date("j_n_y,G-i.",time())."xls";

// Redirect output to a client's web browser (Excel2005)
//header('Content-Type: application/vnd.ms-excel');
//header("Content-Disposition: attachment;filename=".$filename."");
//header('Cache-Control: max-age=0');

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
//$objWriter->save('php://output');
$objWriter->save('generatedFiles/'.$filename); 
?>
<script type="text/javascript">
 window.location = '<?php echo 'generatedFiles/'.$filename;?>';
</script>
<?php

//$objWriter->save("one.pdf");
//exit;

?>