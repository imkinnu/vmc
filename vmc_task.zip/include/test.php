<?php
include("session.php");
echo $session->getValidTime(4);
?>