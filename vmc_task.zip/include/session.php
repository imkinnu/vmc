<?php
include("database.php");
//include("mailer.php");
include("form.php");
date_default_timezone_set('Asia/Kolkata');
class Session
{
    var $username;     //Username given on sign-up
    var $userFullname; //Username Full name given on sign-up
    var $userslno;    //Username Slno given on sign-up
    var $userid;       //Random value generated on current login
    var $userlevel;    //The level to which the user pertains
    var $time;         //Time user was last active (page loaded)
    var $logged_in;    //True if user is logged in, false otherwise
    var $userinfo = array();  //The array holding all user info
    var $url;          //The page url current being viewed
    var $referrer;     //Last recorded site page viewed

    /* Class constructor */
    function Session(){
        $this->time = time();
        $this->startSession();
    }


    function startSession(){
        global $database;  //The database connection
        session_start();   //Tell PHP to start the session

        /* Determine if user is logged in */
        $this->logged_in = $this->checkLogin();

        /**
         * Set guest value to users not logged in, and update
         * active guests table accordingly.
         */
        if(!$this->logged_in){
            $this->username = $_SESSION['username'] = GUEST_NAME;
            $this->userlevel = GUEST_LEVEL;
            $database->addActiveGuest($_SERVER['REMOTE_ADDR'], $this->time);
        }
        /* Update users last active timestamp */
        else{
//            $database->addActiveUser($this->username, $this->time);
        }

        /* Remove inactive visitors from database */

        if(date('i') % 20 == 0){
            $database->removeInactiveUsers();
            $database->removeInactiveGuests();
        }


        /* Set referrer page */
        if(isset($_SESSION['url'])){
            $this->referrer = $_SESSION['url'];
        }else{
            $this->referrer = "/";
        }

        /* Set current url */
        $this->url = $_SESSION['url'] = $_SERVER['PHP_SELF'];
    }

    /**
     * checkLogin - Checks if the user has already previously
     * logged in, and a session with the user has already been
     * established. Also checks to see if user has been remembered.
     * If so, the database is queried to make sure of the user's
     * authenticity. Returns true if the user has logged in.
     */
    function query($q)
    {
        global $database;
        return $database->connection->prepare($q);
    }
    function checkLogin(){
        global $database;  //The database connection
        /* Check if user has been remembered */
        if(isset($_COOKIE['cookname']) && isset($_COOKIE['cookid']))
        {
            $this->username = $_SESSION['username'] = $_COOKIE['cookname'];
            $this->userid   = $_SESSION['userid']   = $_COOKIE['cookid'];
        }

        /* Username and userid have been set and not guest */
        if(isset($_SESSION['username']) && isset($_SESSION['userid']) &&
            $_SESSION['username'] != GUEST_NAME){
            /* Confirm that username and userid are valid */
            if($database->confirmUserID($_SESSION['username'], $_SESSION['userid']) != 0)
            {
                /* Variables are incorrect, user not logged in */
                unset($_SESSION['username']);
                unset($_SESSION['userid']);
                return false;
            }
            /* User is logged in, set class variables */
            $this->userinfo  = $database->getUserInfo($_SESSION['username']);
            $this->username  = $this->userinfo['username'];
            $this->userid    = $this->userinfo['userid'];
            $this->userlevel = $this->userinfo['userlevel'];

            /* auto login hash expires in three days */
            if($this->userinfo['hash_generated'] < (time() - (60*60*24*3))){
                /* Update the hash */
                $database->updateUserField($this->userinfo['username'], 'hash', $this->generateRandID());
                $database->updateUserField($this->userinfo['username'], 'hash_generated', time());
            }

            return true;
        }
        /* User not logged in */
        else{
            return false;
        }
    }

    /**
     * login - The user has submitted his username and password
     * through the login form, this function checks the authenticity
     * of that information in the database and creates the session.
     * Effectively logging in the user if all goes well.
     */
    function login($subuser, $subpass, $subremember){
        global $database, $form;  //The database and form object

        /* Username error checking */
        $field = "user";  //Use field name for username
        $stmt=$database->prepare("select * from".TBL_USERS."where username=:username ");
        $stmt->execute(array("username"=>$subuser));
        $valid = $stmt->fetch(PDO:: FETCH_ASSOC);

        if(!$subuser || strlen($subuser = trim($subuser)) == 0){
            $form->setError($field, "* Username not entered");
        }
        else{
            /* Check if username is not alphanumeric */
            if(!ctype_alnum($subuser)){
                $form->setError($field, "* Username not alphanumeric");
            }
        }

        /* Password error checking */
        $field = "pass";  //Use field name for password
        if(!$subpass){
            $form->setError($field, "* Password not entered");
        }

        /* Return if form errors exist */
        if($form->num_errors > 0){
            return false;
        }

        /* Checks that username is in database and password is correct */
        $subuser = stripslashes($subuser);
        $result = $database->confirmUserPass($subuser, $subpass);

        /* Check error codes */
        if($result == 1){
            $field = "user";
            $form->setError($field, "* Username not found");
        }
        else if($result == 2){
            $field = "pass";
            $form->setError($field, "* Invalid password");
        }

        /* Return if form errors exist */
        if($form->num_errors > 0){
            return false;
        }


        if(EMAIL_WELCOME){
            if($valid['valid'] == 0){
                $form->setError($field, "* User's account has not yet been confirmed.");
            }
        }

        /* Return if form errors exist */
        if($form->num_errors > 0){
            return false;
        }



        /* Username and password correct, register session variables */
        $this->userinfo  = $database->getUserInfo($subuser);
        $this->username  = $_SESSION['username'] = $this->userinfo['username'];
        $this->userid    = $_SESSION['userid']   = $this->generateRandID();
        $this->userlevel = $this->userinfo['userlevel'];
        $this->userFullname  = $_SESSION['userFullname'] = $session->userinfo['name'];
        $this->userslno  = $_SESSION['userslno'] = $session->userinfo['slno'];

        /* Insert userid into database and update active users table */
        $database->updateUserField($this->username, "userid", $this->userid);
        $database->addActiveUser($this->username, $this->time);
        $database->removeActiveGuest($_SERVER['REMOTE_ADDR']);

        /**
         * This is the cool part: the user has requested that we remember that
         * he's logged in, so we set two cookies. One to hold his username,
         * and one to hold his random value userid. It expires by the time
         * specified in constants.php. Now, next time he comes to our site, we will
         * log him in automatically, but only if he didn't log out before he left.
         */
        if($subremember){
            setcookie("cookname", $this->username, time()+COOKIE_EXPIRE, COOKIE_PATH);
            setcookie("cookid",   $this->userid,   time()+COOKIE_EXPIRE, COOKIE_PATH);
        }

        /* Login completed successfully */
        return true;
    }

    /**
     * logout - Gets called when the user wants to be logged out of the
     * website. It deletes any cookies that were stored on the users
     * computer as a result of him wanting to be remembered, and also
     * unsets session variables and demotes his user level to guest.
     */
    function logout(){
        global $database;  //The database connection
        /**
         * Delete cookies - the time must be in the past,
         * so just negate what you added when creating the
         * cookie.
         */
        if(isset($_COOKIE['cookname']) && isset($_COOKIE['cookid'])){
            setcookie("cookname", "", time()-COOKIE_EXPIRE, COOKIE_PATH);
            setcookie("cookid",   "", time()-COOKIE_EXPIRE, COOKIE_PATH);
        }

        /* Unset PHP session variables */
        unset($_SESSION['username']);
        unset($_SESSION['userid']);

        /* Reflect fact that user has logged out */
        $this->logged_in = false;

        /**
         * Remove from active users table and add to
         * active guests tables.
         */
        $database->removeActiveUser($this->username);
        $database->addActiveGuest($_SERVER['REMOTE_ADDR'], $this->time);

        /* Set user level to guest */
        $this->username  = GUEST_NAME;
        $this->userlevel = GUEST_LEVEL;
    }

    /**
     * register - Gets called when the user has just submitted the
     * registration form. Determines if there were any errors with
     * the entry fields, if so, it records the errors and returns
     * 1. If no errors were found, it registers the new user and
     * returns 0. Returns 2 if registration failed.
     */
    function register($subuser, $subpass, $subemail, $subname){

        global $database, $form, $mailer;  //The database, form and mailer object

        /* Username error checking */
        $field = "user";  //Use field name for username
        if(!$subuser || strlen($subuser = trim($subuser)) == 0){
            $form->setError($field, "* Username not entered");
        }
        else{
            /* Spruce up username, check length */
            $subuser = stripslashes($subuser);
            if(strlen($subuser) < 5){
                $form->setError($field, "* Username below 5 characters");
            }
            else if(strlen($subuser) > 30){
                $form->setError($field, "* Username above 30 characters");
            }
            /* Check if username is not alphanumeric */
            else if(!ctype_alnum($subuser)){
                $form->setError($field, "* Username not alphanumeric");
            }
            /* Check if username is reserved */
            else if(strcasecmp($subuser, GUEST_NAME) == 0){
                $form->setError($field, "* Username reserved word");
            }
            /* Check if username is already in use */
            else if($database->usernameTaken($subuser)){
                $form->setError($field, "* Username already in use");
            }
            /* Check if username is banned */
            else if($database->usernameBanned($subuser)){
                $form->setError($field, "* Username banned");
            }
        }

        /* Password error checking */
        $field = "pass";  //Use field name for password
        if(!$subpass){
            $form->setError($field, "* Password not entered");
        }
        else{
            /* Spruce up password and check length*/
            $subpass = stripslashes($subpass);
            if(strlen($subpass) < 4){
                $form->setError($field, "* Password too short");
            }
            /* Check if password is not alphanumeric */
            else if(!ctype_alnum(($subpass = trim($subpass)))){
                $form->setError($field, "* Password not alphanumeric");
            }
            /**
             * Note: I trimmed the password only after I checked the length
             * because if you fill the password field up with spaces
             * it looks like a lot more characters than 4, so it looks
             * kind of stupid to report "password too short".
             */
        }

        /* Email error checking */
        $field = "email";  //Use field name for email
        if(!$subemail || strlen($subemail = trim($subemail)) == 0){
            $form->setError($field, "* Email not entered");
        }
        else{
            /* Check if valid email address */
            if(filter_var($subemail, FILTER_VALIDATE_EMAIL) == FALSE){
                $form->setError($field, "* Email invalid");
            }
            /* Check if email is already in use */
            if($database->emailTaken($subemail)){
                $form->setError($field, "* Email already in use");
            }

            $subemail = stripslashes($subemail);
        }

        /* Name error checking */
        $field = "name";
        if(!$subname || strlen($subname = trim($subname)) == 0){
            $form->setError($field, "* Name not entered");
        } else {
            $subname = stripslashes($subname);
        }

        $randid = $this->generateRandID();

        /* Errors exist, have user correct them */
        if($form->num_errors > 0){
            return 1;  //Errors with form
        }
        /* No errors, add the new account to the */
        else{
            if($database->addNewUser($subuser, md5($subpass), $subemail, $randid, $subname)){
                if(EMAIL_WELCOME){
                    $mailer->sendWelcome($subuser,$subemail,$subpass,$randid);
                }
                return 0;  //New user added succesfully
            }else{
                return 2;  //Registration attempt failed
            }
        }
    }

    /**
     * editAccount - Attempts to edit the user's account information
     * including the password, which it first makes sure is correct
     * if entered, if so and the new password is in the right
     * format, the change is made. All other fields are changed
     * automatically.
     */
    function editAccount($subcurpass, $subnewpass, $subemail, $subname){
        global $database, $form;  //The database and form object
        /* New password entered */
        if($subnewpass){
            /* Current Password error checking */
            $field = "curpass";  //Use field name for current password
            if(!$subcurpass){
                $form->setError($field, "* Current Password not entered");
            }
            else{
                /* Check if password too short or is not alphanumeric */
                $subcurpass = stripslashes($subcurpass);
                if(strlen($subcurpass) < 4 ||
                    !preg_match("^([0-9a-z])+$", ($subcurpass = trim($subcurpass)))){
                    $form->setError($field, "* Current Password incorrect");
                }
                /* Password entered is incorrect */
                if($database->confirmUserPass($this->username,md5($subcurpass)) != 0){
                    $form->setError($field, "* Current Password incorrect");
                }
            }

            /* New Password error checking */
            $field = "newpass";  //Use field name for new password
            /* Spruce up password and check length*/
            $subpass = stripslashes($subnewpass);
            if(strlen($subnewpass) < 4){
                $form->setError($field, "* New Password too short");
            }
            /* Check if password is not alphanumeric */
            else if(!preg_match("^([0-9a-z])+$", ($subnewpass = trim($subnewpass)))){
                $form->setError($field, "* New Password not alphanumeric");
            }
        }
        /* Change password attempted */
        else if($subcurpass){
            /* New Password error reporting */
            $field = "newpass";  //Use field name for new password
            $form->setError($field, "* New Password not entered");
        }

        /* Email error checking */
        $field = "email";  //Use field name for email
        if($subemail && strlen($subemail = trim($subemail)) > 0){
            /* Check if valid email address */
            if(filter_var($subemail, FILTER_VALIDATE_EMAIL) == FALSE){
                $form->setError($field, "* Email invalid");
            }
            $subemail = stripslashes($subemail);
        }

        /* Name error checking */
        $field = "name";
        if(!$subname || strlen($subname = trim($subname)) == 0){
            $form->setError($field, "* Name not entered");
        } else {

            $subname = stripslashes($subname);
        }

        /* Errors exist, have user correct them */
        if($form->num_errors > 0){
            return false;  //Errors with form
        }

        /* Update password since there were no errors */
        if($subcurpass && $subnewpass){
            $database->updateUserField($this->username,"password",md5($subnewpass));
        }

        /* Change Email */
        if($subemail){
            $database->updateUserField($this->username,"email",$subemail);
        }

        /* Change Name */
        if($subname){
            $database->updateUserField($this->username,"name",$subname);
        }

        /* Success! */
        return true;
    }

    /**
     * isAdmin - Returns true if currently logged in user is
     * an administrator, false otherwise.
     */
    function isAdmin(){
        return ($this->userlevel == ADMIN_LEVEL ||
            $this->username  == ADMIN_NAME);
    }

    /**
     * isAuthor - Returns true if currently logged in user is
     * an author or an administrator, false otherwise.
     */
    function isAuthor(){
        return ($this->userlevel == AUTHOR_LEVEL ||
            $this->userlevel == ADMIN_LEVEL);
    }

    /**
     * generateRandID - Generates a string made up of randomized
     * letters (lower and upper case) and digits and returns
     * the md5 hash of it to be used as a userid.
     */
    function generateRandID(){
        return md5($this->generateRandStr(16));
    }

    /**
     * generateRandStr - Generates a string made up of randomized
     * letters (lower and upper case) and digits, the length
     * is a specified parameter.
     */
    function generateRandStr($length){
        $randstr = "";
        for($i=0; $i<$length; $i++){
            $randnum = mt_rand(0,61);
            if($randnum < 10){
                $randstr .= chr($randnum+48);
            }else if($randnum < 36){
                $randstr .= chr($randnum+55);
            }else{
                $randstr .= chr($randnum+61);
            }
        }
        return $randstr;
    }

    function cleanInput($post = array()) {
        foreach($post as $k => $v){
            $post[$k] = trim(htmlspecialchars($v));
        }
        return $post;
    }
    /*Pagination code*/
    function showPagination($pagename,$tbl_name,$start,$limit,$page,$query){

        $database = new MySQLDB;
        //your table name
        // How many adjacent pages should be shown on each side?
        $adjacents = 3;
        $total_pages = mysqli_fetch_array($database->query($query));
        $total_pages = $total_pages['num'];
        /* Setup vars for query. */
        $targetpage = $pagename;     //your file name  (the name of this file)
        //how many items to show per page
        /* Setup page vars for display. */
        if ($page == 0) $page = 1;                    //if no page var is given, default to 1.
        $prev = $page - 1;                            //previous page is page - 1
        $next = $page + 1;                            //next page is page + 1
        $lastpage = ceil($total_pages/$limit);        //lastpage is = total pages / items per page, rounded up.
        $lpm1 = $lastpage - 1;                        //last page minus 1
        /*
           Now we apply our rules and draw the pagination object.
           We're actually saving the code to a variable in case we want to draw it more than once.
        */
        $pagination = "";
        if($lastpage > 1)
        {

            $pagination .= "<div class=\"pagination\">";
            //previous button
            if ($page > 1){

                $pagination.= "<a title=\"Go to page $page of $lastpage\" onclick=\"setStateGet('adminForm','".$targetpage."','page=".$prev."')\">&laquo; previous</a>";
            }
            else{
                $pagination.= "<span class=\"disabled\">&laquo; previous</span>";
            }
            //pages
            if ($lastpage < 7 + ($adjacents * 2))    //not enough pages to bother breaking it up
            {
                for ($counter = 1; $counter <= $lastpage; $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"current\">$counter</span>";
                    else
                        $pagination.= "<a title=\"Go to page $counter of $lastpage\" onclick=\"setStateGet('adminForm','".$targetpage."','page=".$counter."')\">$counter</a>";
                }
            }
            elseif($lastpage > 5 + ($adjacents * 2))    //enough pages to hide some
            {
                //close to beginning; only hide later pages
                if($page < 1 + ($adjacents * 2))
                {
                    for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
                    {
                        if ($counter == $page)
                            $pagination.= "<span class=\"current\">$counter</span>";
                        else
                            $pagination.= "<a title=\"Go to page $counter of $lastpage\"  onclick=\"setStateGet('adminForm','".$targetpage."','page=".$counter."')\">$counter</a>";
                    }
                    $pagination.= "...";
                    $pagination.= "<a title=\"Go to page $page of $lastpage\" onclick=\"setStateGet('adminForm','".$targetpage."','page=".$lpm1."')\">$lpm1</a>";
                    $pagination.= "<a  title=\"Go to page $counter of $lastpage\" onclick=\"setStateGet('adminForm','".$targetpage."','page=".$lastpage."')\">$lastpage</a>";
                }
                //in middle; hide some front and some back
                elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
                {
                    $pagination.= "<a title=\"Go to page $page of $lastpage\" onclick=\"setStateGet('adminForm','".$targetpage."','page=1')\">1</a>";
                    $pagination.= "<a title=\"Go to page $page of $lastpage\" onclick=\"setStateGet('adminForm','".$targetpage."','page=2')\">2</a>";
                    $pagination.= "...";
                    for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
                    {
                        if ($counter == $page)
                            $pagination.= "<span class=\"current\">$counter</span>";
                        else
                            $pagination.= "<a title=\"Go to page $counter of $lastpage\" onclick=\"setStateGet('adminForm','".$targetpage."','page=".$counter."')\">$counter</a>";
                    }
                    $pagination.= "...";
                    $pagination.= "<a >$lpm1</a>";
                    $pagination.= "<a title=\"Go to page $page of $lastpage\" onclick=\"setStateGet('adminForm','".$targetpage."','page=".$lastpage."')\">$lastpage</a>";
                }
                //close to end; only hide early pages
                else
                {
                    $pagination.= "<a title=\"Go to page $page of $lastpage\" onclick=\"setStateGet('adminForm','".$targetpage."','page=1')\">1</a>";
                    $pagination.= "<a title=\"Go to page $page of $lastpage\" onclick=\"setStateGet('adminForm','".$targetpage."','page=2')\">2</a>";
                    $pagination.= "...";
                    for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
                    {
                        if ($counter == $page)
                            $pagination.= "<span class=\"current\">$counter</span>";
                        else
                            $pagination.= "<a title=\"Go to page $counter of $lastpage\" onclick=\"setStateGet('adminForm','".$targetpage."','page=".$counter."')\">$counter</a>";
                    }
                }
            }

            //next button
            if ($page < $counter - 1)
                $pagination.= "<a  onclick=\"setStateGet('adminForm','".$targetpage."','page=".$next."')\">next &raquo;</a>";
            else
                $pagination.= "<span class=\"disabled\">next  &raquo;</span>";
            $pagination.= "</div>\n";
        }
        return $pagination;
    }
    function showPagination1($pagename,$tbl_name,$start,$limit,$page,$data,$aging){

        $database = new MySQLDB;
        //your table name
        // How many adjacent pages should be shown on each side?
        $adjacents = 3;

        $sql = $database->query($data);
        $total_pages = mysqli_num_rows($sql);
        $targetpage = $pagename;     //your file name  (the name of this file)
        //how many items to show per page
        /* Setup page vars for display. */
        if ($page == 0) $page = 1;                    //if no page var is given, default to 1.
        $prev = $page - 1;                            //previous page is page - 1
        $next = $page + 1;                            //next page is page + 1
        $lastpage = ceil($total_pages/$limit);        //lastpage is = total pages / items per page, rounded up.
        $lpm1 = $lastpage - 1;                        //last page minus 1
        /*
           Now we apply our rules and draw the pagination object.
           We're actually saving the code to a variable in case we want to draw it more than once.
        */
        $pagination = "";
        if($lastpage > 1)
        {

            $pagination .= "<div class=\"pagination\">";
            //previous button
            if ($page > 1){

                $pagination.= "<a onclick=\"setStateGet('adminForm','".$targetpage."','page=".$prev."')\">&laquo; previous</a>";
            }
            else{
                $pagination.= "<span class=\"disabled\">&laquo; previous</span>";
            }
            //pages
            if ($lastpage < 7 + ($adjacents * 2))    //not enough pages to bother breaking it up
            {
                for ($counter = 1; $counter <= $lastpage; $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"current\">$counter</span>";
                    else
                        $pagination.= "<a  onclick=\"setStateGet('adminForm','".$targetpage."','page=".$counter."')\">$counter</a>";
                }
            }
            elseif($lastpage > 5 + ($adjacents * 2))    //enough pages to hide some
            {
                //close to beginning; only hide later pages
                if($page < 1 + ($adjacents * 2))
                {
                    for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
                    {
                        if ($counter == $page)
                            $pagination.= "<span class=\"current\">$counter</span>";
                        else
                            $pagination.= "<a  onclick=\"setStateGet('adminForm','".$targetpage."','page=".$counter."')\">$counter</a>";
                    }
                    $pagination.= "...";
                    $pagination.= "<a onclick=\"setStateGet('adminForm','".$targetpage."','page=".$lpm1."')\">$lpm1</a>";
                    $pagination.= "<a  onclick=\"setStateGet('adminForm','".$targetpage."','page=".$lastpage."')\">$lastpage</a>";
                }
                //in middle; hide some front and some back
                elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
                {
                    $pagination.= "<a  onclick=\"setStateGet('adminForm','".$targetpage."','page=1')\">1</a>";
                    $pagination.= "<a onclick=\"setStateGet('adminForm','".$targetpage."','page=2')\">2</a>";
                    $pagination.= "...";
                    for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
                    {
                        if ($counter == $page)
                            $pagination.= "<span class=\"current\">$counter</span>";
                        else
                            $pagination.= "<a onclick=\"setStateGet('adminForm','".$targetpage."','page=".$counter."')\">$counter</a>";
                    }
                    $pagination.= "...";
                    $pagination.= "<a >$lpm1</a>";
                    $pagination.= "<a onclick=\"setStateGet('adminForm','".$targetpage."','page=".$lastpage."')\">$lastpage</a>";
                }
                //close to end; only hide early pages
                else
                {
                    $pagination.= "<a onclick=\"setStateGet('adminForm','".$targetpage."','page=1')\">1</a>";
                    $pagination.= "<a  onclick=\"setStateGet('adminForm','".$targetpage."','page=2')\">2</a>";
                    $pagination.= "...";
                    for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
                    {
                        if ($counter == $page)
                            $pagination.= "<span class=\"current\">$counter</span>";
                        else
                            $pagination.= "<a  onclick=\"setStateGet('adminForm','".$targetpage."','page=".$counter."')\">$counter</a>";
                    }
                }
            }
            //next button
            if ($page < $counter - 1)
                $pagination.= "<a  onclick=\"setStateGet('adminForm','".$targetpage."','page=".$next."')\">next &raquo;</a>";
            else
                $pagination.= "<span class=\"disabled\">next  &raquo;</span>";
            $pagination.= "</div>\n";
        }
        return $pagination;
    }



    /*End Pagination*/


    function checkInput($pan)
    {

        if (filter_var($pan, FILTER_VALIDATE_INT, array("options" => array("min_range"=>10000, "max_range"=>1999999))) === false && strlen($pan)<8) {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    function checkInput1($pan)
    {

        if (filter_var($pan, FILTER_VALIDATE_INT, array("options" => array("min_range"=>1, "max_range"=>20))) === false) {
            return 1;
        }else
        {
            return 0;
        }
    }

    function sendsms($user,$pass,$msg,$sender,$mobile){
        global $database;
        $user='prisap';
        $pass='p31131';
        $mobile = '91'.substr($mobile,-10);
        $url = "http://bsms.entrolabs.com/spanelv2/api.php?username=".$user."&password=".$pass."&to=".$mobile."&from=".$sender."&message=".urlencode($msg);    //Store data into URL variable
        return $ret = @file($url);
    }

    function sendsms2($user,$pass,$msg,$sender,$mobile){

        global $database;
        $mobile = substr($mobile,-10);

        // Textlocal account details
        $username = 'entrolabsindia@gmail.com';
        $hash = $pass;

        // Message details
        $numbers = array($mobile);
        $sender = urlencode($sender);
        $message = rawurlencode($msg);

        $numbers = implode(',', $numbers);

        // Prepare data for POST request
        $data = array('username' => $username, 'apiKey' => 'ftlb3cldZs4-TIkUEBnUpgbwQHD7xFlr4wGX7iMXMB', 'numbers' => $numbers, "sender" => $sender, "message" => $message);


        // Send the POST request with cURL
        $ch = curl_init('https://api.textlocal.in/send/');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);


        // $database->query("INSERT INTO mlog VALUES(NULL, 'TEST SMS: ".$msg." - ".$mobile."' , '".$response."', '".time()."')");


        // Process your response here
        return $response;

    }

    function moneyFormat($num){
        $explrestunits = "" ;
        $num=preg_replace('/,+/', '', $num);
        $words = explode(".", $num);
        $des="";
        if(count($words)<=2){
            $num=$words[0];
            if(count($words)>=2){$des=$words[1];}
            if(strlen($des)<2){$des="$des0";}else{$des=substr($des,0,2);}
        }
        if(strlen($num)>3){
            $lastthree = substr($num, strlen($num)-3, strlen($num));
            $restunits = substr($num, 0, strlen($num)-3); // extracts the last three digits
            $restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
            $expunit = str_split($restunits, 2);
            for($i=0; $i<sizeof($expunit); $i++){
                // creates each of the 2's group and adds a comma to the end
                if($i==0)
                {
                    $explrestunits .= (int)$expunit[$i].","; // if is first value , convert into integer
                }else{
                    $explrestunits .= $expunit[$i].",";
                }
            }
            $thecash = $explrestunits.$lastthree;
        } else {
            $thecash = $num;
        }
        return "$thecash"; // writes the final format where $currency is the currency symbol.
    }
    function CheckRecord($tbl,$fld1,$val1,$fld2,$val2,$fld3,$val3,$fld4,$val4){
        global $database;
        if($fld1!="")
            $cond1=" AND ".$fld1."='".$val1."'";
        else
            $cond1="";

        if($fld2!="")
            $cond2=" AND ".$fld2."='".$val2."'";
        else
            $cond2="";

        if($fld3!="")
            $cond3=" AND ".$fld3."='".$val3."'";
        else
            $cond3="";

        if($fld4!="")
            $cond4=" AND ".$fld4."='".$val4."'";
        else
            $cond4="";

        $sql ='';
        $sql=$database->query("SELECT count(*) AS count FROM ".$tbl." WHERE slno!='' ".$cond1.$cond2.$cond3.$cond4);
        $data = mysqli_fetch_array($sql);
        $count =  $data['count'];
        if($count > 0){
            return 1;
        } else {
            return 0;
        }
    }
    function SrchReportSUM($tbl,$val,$fld1,$val1,$fld2,$val2,$fld3,$val3,$fld4,$val4,$fld5,$val5){
        global $database;
        if($fld1!="")
            $cond1=" AND ".$fld1."='".$val1."'";
        else
            $cond1="";

        if($fld2!="")
            $cond2=" AND ".$fld2."='".$val2."'";
        else
            $cond2="";

        if($fld3!="")
            $cond3=" AND ".$fld3."='".$val3."'";
        else
            $cond3="";

        if($fld4!="")
            $cond4=" AND ".$fld4."='".$val4."'";
        else
            $cond4="";

        if($fld5!="")
            $cond5=" AND ".$fld5."='".$val5."'";
        else
            $cond5="";

        $sql=$database->query("SELECT SUM(".$val.") FROM ".$tbl." WHERE slno!=''".$cond1.$cond2.$cond3.$cond4.$cond5);
        //echo "SELECT SUM(".$val.") FROM ".$tbl." WHERE slno!=''".$cond1.$cond2.$cond3.$cond4.$cond5."<br/>";
        $row = mysqli_fetch_array($sql);
        if($row[0] == NULL || $row[0] == "" || $row[0] == "0")
            return "0";
        else
            return $row[0];
    }
    function SrchReportCount($tbl,$fld1,$val1,$fld2,$val2,$fld3,$val3,$fld4,$val4,$fld5,$val5){
        global $database;
        if($fld1!="")
            $cond1=" AND ".$fld1."='".$val1."'";
        else
            $cond1="";

        if($fld2!="")
            $cond2=" AND ".$fld2."='".$val2."'";
        else
            $cond2="";

        if($fld3!="")
            $cond3=" AND ".$fld3."='".$val3."'";
        else
            $cond3="";

        if($fld4!="")
            $cond4=" AND ".$fld4."='".$val4."'";
        else
            $cond4="";

        if($fld5!="")
            $cond5=" AND ".$fld5."='".$val5."'";
        else
            $cond5="";

        $sql=$database->query("SELECT COUNT(*) FROM ".$tbl." WHERE slno!=''".$cond1.$cond2.$cond3.$cond4.$cond5);
        //echo "SELECT COUNT(*) FROM ".$tbl." WHERE slno!=''".$cond1.$cond2.$cond3.$cond4.$cond5;
        $row = mysqli_fetch_array($sql);
        return $row[0];
    }
    function SrchReportGroup($tbl,$fld1,$val1,$fld2,$val2,$fld3,$val3,$fld4,$val4,$grp){
        global $database;
        if($fld1!=""){
            $cond1=" AND ".$fld1."='".$val1."'";
            $flds=$fld1.",";
        }else{
            $cond1="";
        }

        if($fld2!=""){
            $cond2=" AND ".$fld2."='".$val2."'";
            $flds .=$fld2.",";
        }else{
            $cond2="";
        }

        if($fld3!=""){
            $cond3=" AND ".$fld3."='".$val3."'";
            $flds .=$fld3.",";
        }else{
            $cond3="";
        }

        if($fld4!=""){
            $cond4=" AND ".$fld4."='".$val4."'";
            $flds .=$fld4.",";
        }else{
            $cond4="";
        }

        if($grp!=""){
            $flds .=$grp.",";
            $grp=" GROUP BY ".$grp;
        } else {
            $grp="";
        }

        $flds=substr($flds,0,-1);

        $database->query("CREATE INDEX id_index3 ON ".$tbl."(".$flds.");");

        $sql=$database->query("SELECT * FROM ".$tbl." WHERE slno!=''".$cond1.$cond2.$cond3.$cond4.$grp);
        return $sql;
    }
    function SrchReport($tbl,$fld1,$val1,$fld2,$val2,$fld3,$val3,$fld4,$val4,$ord){
        global $database;
        if($fld1!=""){
            $cond1=" AND ".$fld1."='".$val1."'";
            $flds=$fld1.",";
        }else{
            $cond1="";
        }

        if($fld2!=""){
            $cond2=" AND ".$fld2."='".$val2."'";
            $flds .=$fld2.",";
        }else{
            $cond2="";
        }

        if($fld3!=""){
            $cond3=" AND ".$fld3."='".$val3."'";
            $flds .=$fld3.",";
        }else{
            $cond3="";
        }

        if($fld4!=""){
            $cond4=" AND ".$fld4."='".$val4."'";
            $flds .=$fld4.",";
        }else{
            $cond4="";
        }

        if($ord!=""){
            $flds .=$ord.",";
            $ord=" ORDER BY ".$ord;
        } else {
            $ord="";
        }

        $flds=substr($flds,0,-1);

        $database->query("CREATE INDEX id_index1 ON ".$tbl."(".$flds.");");
        $sql=$database->query("SELECT * FROM ".$tbl." WHERE slno!=''".$cond1.$cond2.$cond3.$cond4.$ord);
        return $sql;
    }
    function Idref($tbl,$disp,$fld1,$val1,$fld2,$val2,$fld3,$val3,$fld4,$val4,$ord){
        global $database;
        if($fld1!="")
            $cond1=" AND ".$fld1."='".$val1."'";
        else
            $cond1="";

        if($fld2!="")
            $cond2=" AND ".$fld2."='".$val2."'";
        else
            $cond2="";

        if($fld3!="")
            $cond3=" AND ".$fld3."='".$val3."'";
        else
            $cond3="";

        if($fld4!="")
            $cond4=" AND ".$fld4."='".$val4."'";
        else
            $cond4="";

        if($ord!=""){
            $ord=" ORDER BY ".$ord;
        } else {
            $ord="";
        }

        $sql=$database->query("SELECT ".$disp." FROM ".$tbl." WHERE slno!='' AND estatus='1'".$cond1.$cond2.$cond3.$cond4.$ord);
        $count = mysqli_fetch_array($sql);
        return $count[0];
    }

    /*imageResize - Resizes images of all types to the specified dimentions.
     Preserves image alpha channel information also*/

    function image_resize($src, $dst, $width, $height, $crop=0){

        if(!list($w, $h) = getimagesize($src)) return "Unsupported picture type!";

        $type = strtolower(substr(strrchr($src,"."),1));
        if($type == 'jpeg') $type = 'jpg';
        switch($type){
            case 'bmp': $img = imagecreatefromwbmp($src); break;
            case 'gif': $img = imagecreatefromgif($src); break;
            case 'jpg': $img = imagecreatefromjpeg($src); break;
            case 'png': $img = imagecreatefrompng($src); break;
            default : return "Unsupported picture type!";
        }

        //resize
        if(is_array($crop)){
            // $_SESSION['crop'] = 'Is here.. reading crop array';
            $ratio = max($width/$w, $height/$h);

            if($w < $width or $h < $height){
                //$_SESSION['crop'].= "Picture is too small!".$ratio;
            }

            $h = $crop['height'];
            $x = $crop['x'];
            $w = $crop['width'];
            $y= $crop['y'];

        }
        else{
            if($w < $width and $h < $height) return "Picture is too small!";
            $ratio = min($width/$w, $height/$h);
            $width = $w * $ratio;
            $height = $h * $ratio;
            $x = 0;
            $y=0;
        }

        $new = imagecreatetruecolor($width, $height);

        // preserve transparency
        if($type == "gif" or $type == "png"){
            imagecolortransparent($new, imagecolorallocatealpha($new, 0, 0, 0, 127));
            imagealphablending($new, false);
            imagesavealpha($new, true);
        }

        // $_SESSION['crop'].= "x:".$x."--y:".$y."--W:".$w."--H:".$h."--Width:".$width."--Height:".$height;
        imagecopyresampled($new, $img, 0, 0, $x, $y, $width, $height, $w, $h);

        switch($type){
            case 'bmp': imagewbmp($new, $dst); break;
            case 'gif': imagegif($new, $dst); break;
            case 'jpg': imagejpeg($new, $dst); break;
            case 'png': imagepng($new, $dst); break;
        }
        return true;
    }


    //Functions for all Includes
    function commonAdminJS(){
        ?>
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>assets/js/modernizr.min.js"></script>

        <?php
    }
    function dataTableAssets()
    { ?>
        <link rel="stylesheet" type="text/css" href="<?php echo SECURE_PATH ?>vendor/datatables/dataTables.bootstrap4.css"/>
        <link rel="stylesheet" type="text/css" href="<?php echo SECURE_PATH ?>vendor/datatables/dataTables.bootstrap4.min.css"/>
        <script type="text/javascript" src="<?php echo SECURE_PATH ?>vendor/datatables/dataTables.bootstrap4.js"></script>
        <script type="text/javascript" src="<?php echo SECURE_PATH ?>vendor/datatables/dataTables.bootstrap4.min.js"></script>
        <script type="text/javascript" src="<?php echo SECURE_PATH ?>vendor/datatables/jquery.dataTables.js"></script>
        <script type="text/javascript" src="<?php echo SECURE_PATH ?>vendor/datatables/jquery.dataTables.min.js"></script>
    <?php }
    function commonJS(){
        ?>
        <!-- js placed at the end of the document so the pages load faster -->
        <script type="text/javascript">
            function eform(){
                window.scrollTo(0, 0);
            }
        </script>
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>vendor/app/js/select2.min.js"></script>
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/validate-aadhar.js"></script>
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/nprogress.js"></script>
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/ajaxfunction.js"></script>
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>theme/js/upload/fileuploader.js"></script>
        <script type="text/javascript">
            // Allow only Alphabates and White Space for Name
            function lettersOnly2(evt) {
                evt = (evt) ? evt : event;
                var charCode = (evt.charCode) ? evt.charCode : ((evt.keyCode) ? evt.keyCode :
                    ((evt.which) ? evt.which : 0));
                if (charCode == 32 || charCode == 95 || charCode == 9 || charCode == 10 || charCode == 11 || charCode == 8 || charCode == 37 || charCode == 39)
                    return true;
                if (charCode > 31 && (charCode < 65 || charCode > 90) &&
                    (charCode < 97 || charCode > 122)) {
                    return false;
                }
                else
                    return true;
            }
            //Allow Only Numbers
            function onlyNos(e, t) {
                try {
                    if (window.event) {
                        var charCode = window.event.keyCode;
                    }
                    else if (e) {
                        var charCode = e.which;
                    }
                    else { return true; }
                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    }
                    return true;
                }
                catch (err) {
                    alert(err.Description);
                }
            }
            //onkeypress="return onlyNos(event,this);"
            //only numbers and one dot after decimal two numbers
            function NumAndTwoDecimals(e,field) {
                var val = field.value;
                var re = /^([0-9]+[\.]?[0-9]?[0-9]?|[0-9]+)$/g;
                var re1 = /^([0-9]+[\.]?[0-9]?[0-9]?|[0-9]+)/g;
                if (re.test(val)) {
                    //do something here

                } else {
                    val = re1.exec(val);
                    if (val) {
                        field.value = val[0];
                    } else {
                        field.value = "";
                    }
                }
            }
            //onKeyup="NumAndTwoDecimals(event,this);"
        </script>

        <?php
    }
    function commonFooterAdminJS(){
        ?>

        <!-- Bootstrap core JavaScript-->
        <!-- <script type="text/javascript" src="<?php echo SECURE_PATH;?>vendor/jquery/jquery.min.js"></script> -->
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Core plugin JavaScript-->
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>vendor/jquery-easing/jquery.easing.min.js"></script>

        <!-- bootstrap-datetimepicker JS -->
        <script src="<?php echo SECURE_PATH;?>vendor/bootstrap-datetimepicker/js/moment.min.js"></script>
        <script src="<?php echo SECURE_PATH;?>vendor/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>

        <!-- Page level plugin JavaScript-->
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>vendor/chart.js/Chart.min.js"></script>
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>vendor/datatables/jquery.dataTables.js"></script>
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>vendor/datatables/dataTables.bootstrap4.js"></script>

        <!-- Custom scripts for all pages-->
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>vendor/app/js/admin.js"></script>

        <!--        <script src="--><?php //echo SECURE_PATH;?><!--summernote/summernote.js"></script>-->

        <!-- Demo scripts for this page-->
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>vendor/app/js/custom-js/datatables-demo.js"></script>
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>vendor/app/js/custom-js/chart-area-demo.js"></script>
        <script type="text/javascript" src="<?php echo SECURE_PATH;?>vendor/app/js/custom-js/to-do-list.js"></script>
        <!-- jQuery Custom Scroller CDN -->
        <script src="<?php echo SECURE_PATH;?>vendor/jquery-mousewheel-scrollbar/js/jquery.mCustomScrollbar.min.js"></script>
        <?php
    }
    function commonHeader(){
        ?>
        <header class="header-area">
            <nav class="navbar navbar-expand navbar-light bg-admin">
                <div class="container">
                    <button class="btn btn-light btn-circle text-theme order-1 order-sm-0" id="sidebarCollapse" >
                        <i class="material-icons text-theme md-18">more_vert</i>
                    </button>
                    <form class="form-inline mr-auto mr-0 ml-md-3">
                        <div class="has-search">
                            <span class="material-icons md-24 form-control-feedback">search</span>
                            <input type="text" class="form-control" placeholder="Search...">
                        </div>
                    </form>
                    <!-- Navbar -->
                    <ul class="navbar-nav ml-auto ml-md-0">
                        <li class="nav-item">
                            <a class="nav-link invite text-theme" style="cursor: pointer;"
                               onclick="setState('main-content','<?php echo SECURE_PATH;?>users/','getLayout=true')">
                     <span class="pt-2 d-none d-lg-inline-block"><i class="material-icons md-14">add</i> Add
                     User</span>
                                <span
                                        class="mt-1 d-xl-none d-lg-none text-theme btn btn-light btn-circle material-icons md-18">add</span>
                            </a>
                        </li>
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle pt-1" href="#" id="userDropdown" role="button"
                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="<?php echo SECURE_PATH;?>vendor/images/user-profile.png" width="35" alt="profile-user" class="rounded-circle">
                                <div class="d-none d-xl-inline-block"><?php echo $this->username;?></div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right logout" aria-labelledby="userDropdown">
                                <a class="dropdown-item" style="cursor: pointer;" onclick="setStateGet('main-content','<?php echo SECURE_PATH;?>changePassword.php','changePassword=1')"><i class="material-icons">settings</i> Change Password</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="<?php echo SECURE_PATH;?>indexout.php"><i
                                            class="material-icons">exit_to_app</i>
                                    Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>

        <?php
    }
    function commonAdminCSS(){
        ?>

        <!--        <link href="--><?php //echo SECURE_PATH;?><!--summernote/summernote.css" rel="stylesheet">-->
        <link href="<?php echo SECURE_PATH;?>theme/js/upload/fileuploader.css" rel="stylesheet">
        <link href="<?php echo SECURE_PATH;?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom styles for this template-->
        <link href="<?php echo SECURE_PATH;?>vendor/app/css/style.css" rel="stylesheet">

        <!-- Scrollbar Custom CSS -->
        <link rel="stylesheet" href="<?php echo SECURE_PATH;?>vendor/jquery-mousewheel-scrollbar/css/jquery.mCustomScrollbar.min.css">

        <!-- bootstrap-datetimepicker CSS -->
        <link rel="stylesheet" href="<?php echo SECURE_PATH;?>vendor/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css">

        <!-- Page level plugin CSS-->
        <link href="<?php echo SECURE_PATH;?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
        <link href="<?php echo SECURE_PATH;?>theme/css/nprogress.css" rel="stylesheet">
        <link href="<?php echo SECURE_PATH;?>vendor/app/css/select2.min.css" rel="stylesheet">

        <?php
    }
    function vmc_title(){
        ?>
        <title>VMC</title>
        <?php
    }
    function getTasks($username)
    {
        global $database,$session;
        $return  = '';
        $task = array();
        $getN = $database->get_name('employee','username',$username,'id');
        /*$get = $database->query("select * from task"); */
        $get = $this->query("select * from task where (status != :three and status != :four ) OR forwardto= :getN");
        $get->execute(array('three'=>3,'four'=>4,'getN'=>$getN));
        while($row = $get->fetch(PDO::FETCH_ASSOC))
        {
            $assigned = explode(',',$row['assignedto']);
            if (in_array($getN, $assigned))
            {
                $task[] = $row['task_id'];
                $project[] = $row['project_name'];
//                array_push($task,$row['task_id'],',');
//                array_push($project,$row['project_name']);
            }
        }
        return $task;
    }
    function getProjects($username)
    {
        global $database,$session;
        $return  = '';
        $project = array();
        $getN = $database->get_name('employee','username',$username,'id');
        /*$get = $database->query("select * from task"); */
        $get = $this->query("select * from project");
        $get->execute();
        while($row = $get->fetch(PDO::FETCH_ASSOC))
        {
            $assigned = explode(',',$row['stakeholder']);
            if (in_array($getN, $assigned))
            {
                $project[] = $row['project_id'];
            }
        }
        return $project;
    }
    function getAssignedTo($project_id)
        {
            $getTask = $this->query("select DISTINCT task_id from task where project_name=:project_id");
            $getTask->execute(array('project_id'=>$project_id));
            $taskId = '';
            if($getTask->rowCount() >0)
            {
                while($row = $getTask->fetch(PDO::FETCH_ASSOC))
                {
                    echo $this->getCurretlyWith($row['task_id']);
                }
            }
            else {
                return "None";
            }
        }
    function getCurretlyWith($task_id)
    {
        $getCurrentlyWith = $this->query('select assignedto from task where task_id = :task_id');
        $getCurrentlyWith->execute(array('task_id'=>$task_id));
        $row = $getCurrentlyWith->fetch(PDO::FETCH_ASSOC);
        return $task_id." ".$row['assignedto'];
    }
    function number_to_words($number){
        $no = round($number);
        $point = round($number - $no, 2) * 100;
        $hundred = null;
        $digits_1 = strlen($no);
        $i = 0;
        $str = array();
        $words = array('0' => '', '1' => 'one', '2' => 'two',
            '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six',
            '7' => 'seven', '8' => 'eight', '9' => 'nine',
            '10' => 'ten', '11' => 'eleven', '12' => 'twelve',
            '13' => 'thirteen', '14' => 'fourteen',
            '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
            '18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty',
            '30' => 'thirty', '40' => 'forty', '50' => 'fifty',
            '60' => 'sixty', '70' => 'seventy',
            '80' => 'eighty', '90' => 'ninety');
        $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
        while ($i < $digits_1) {
            $divider = ($i == 2) ? 10 : 100;
            $number = floor($no % $divider);
            $no = floor($no / $divider);
            $i += ($divider == 10) ? 1 : 2;
            if ($number) {

                $counter = count($str);
                $plural = null;//(($counter = count($str)) && $number > 9) ? 's' : null;


                $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                $str [] = ($number < 21) ? $words[$number] .
                    " " . $digits[$counter] . $plural . " " . $hundred
                    :
                    $words[floor($number / 10) * 10]
                    . " " . $words[$number % 10] . " "
                    . $digits[$counter] . $plural . " " . $hundred;
            } else $str[] = null;
        }
        $str = array_reverse($str);
        $result = implode('', $str);
        $points = ($point) ?
            "." . $words[$point / 10] . " " .
            $words[$point = $point % 10] : '';
        return ucwords($result)  ;

    }
    function validatePan($pan){
        $pattern = '/^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/';
        $result = preg_match($pattern, $pan);
        if ($result) {
            $findme = ucfirst(substr($pan, 3, 1));
            $mystring = 'CPHFATBLJG';
            $pos = strpos($mystring, $findme);
            if ($pos === false) {
                $msg = 0;
            } else {
                $msg = 1;
            }
        } else {
            $msg = 0;
        }
        return $msg;
    }
    function validateVoter($voter){
        $pattern = '/^([a-zA-Z]){3}([0-9]){7}?$/';
        $result = preg_match($pattern, $voter);
        if ($result) {
            $msg = 1;
        } else {
            $msg = 0;
        }
        return $msg;
    }
    function validatePassport($passport){
        $pattern = '/^([a-zA-Z]){1}([0-9]){8}?$/';
        $result = preg_match($pattern, $passport);
        if ($result) {
            $msg = 1;
        } else {
            $msg = 0;
        }
        return $msg;
    }
    function validateAadhar($aadhar){

        $aadharArray = array();
        for($i=0;$i < strlen($aadhar); $i++){
            $aadharArray[$i] = substr($aadhar,$i,1);
        }
        if(!$this->CheckArrayByVerhoeffAlogirithm($aadharArray))
            return false;

        else if($aadharArray[0] == 1 || $aadharArray[0] == 0)
            return false;

        else if($aadhar == '222222222222' || $aadhar == '333333333333' || $aadhar == '444444444444' || $aadhar == '555555555555' || $aadhar == '666666666666' || $aadhar == '777777777777' || $aadhar == '888888888888' || $aadhar == '999999999999')
            return false;

        else{
            $part1 = substr($aadhar,0,4);
            $part2 = substr($aadhar,4,4);
            $part3 = substr($aadhar,8,4);

            if($part1 == $part2 || $part1 == $part3 || $part2 == $part3)
                return false;

        }

        return true;
    }
    function CheckArrayByVerhoeffAlogirithm($aadharArray){

        $op = array();
        $op[0] =  array( 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 );
        $op[1] =    array(  1, 2, 3, 4, 0, 6, 7, 8, 9, 5 );
        $op[2] =    array(  2, 3, 4, 0, 1, 7, 8, 9, 5, 6 );
        $op[3] =   array(  3, 4, 0, 1, 2, 8, 9, 5, 6, 7 );
        $op[4] =    array(  4, 0, 1, 2, 3, 9, 5, 6, 7, 8 );
        $op[5] =    array(  5, 9, 8, 7, 6, 0, 4, 3, 2, 1 );
        $op[6] =    array(  6, 5, 9, 8, 7, 1, 0, 4, 3, 2 );
        $op[7] =    array(  7, 6, 5, 9, 8, 2, 1, 0, 4, 3 );
        $op[8] =    array(  8, 7, 6, 5, 9, 3, 2, 1, 0, 4 );
        $op[9] =    array(  9, 8, 7, 6, 5, 4, 3, 2, 1, 0 );

        $F = array();
        $F[0] =   array(  0, 1, 2, 3, 4, 5, 6, 7, 8, 9 );
        $F[1] =    array(  1, 5, 7, 6, 2, 8, 3, 0, 9, 4 );
        for ($i = 2; $i < 8; $i++)
        {
            for (  $j = 0; $j < 10; $j++)
                $F[$i][$j] = $F[$i - 1][$F[1][$j]];
        }




        // First we need to reverse the order of the input digits
        $reversedInput = array();
        for ($i = 0; $i < count($aadharArray); $i++)
            $reversedInput[$i] = $aadharArray[count($aadharArray) - ($i + 1)];

        $check = 0;
        for ($i = 0; $i < count($reversedInput); $i++)
            $check = $op[$check][$F[$i % 8][$reversedInput[$i]]];

        return ($check == 0);
    }

    function displayAadhar($aadhar){

        $a4 = substr($aadhar,0,4);

        $a2 = substr($aadhar,-1,2);

        return $a4.'XXXXXX'.$a2;

    }

    function displayMobile($mobile){

        $a4 = substr($mobile,0,4);

        $a2 = substr($mobile,-1,2);

        return $a4.'XXXXX'.$a2;
    }

};


/**
 * Initialize session object - This must be initialized before
 * the form object because the form uses session variables,
 * which cannot be accessed unless the session has started.
 */
$session = new Session;

/* Initialize form object */
$form = new Form;

?>
