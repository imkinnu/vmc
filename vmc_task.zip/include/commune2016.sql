-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 166.62.8.52
-- Generation Time: Mar 15, 2017 at 03:26 AM
-- Server version: 5.5.43
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ticketingsystem2016`
--

-- --------------------------------------------------------

--
-- Table structure for table `active_guests`
--

CREATE TABLE `active_guests` (
  `ip` varchar(10) NOT NULL,
  `timestamp` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `active_guests`
--

INSERT INTO `active_guests` VALUES('115.112.10', 1488365245);
INSERT INTO `active_guests` VALUES('115.112.10', 1488365246);

-- --------------------------------------------------------

--
-- Table structure for table `active_users`
--

CREATE TABLE `active_users` (
  `username` varchar(30) NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `active_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `add_bank`
--

CREATE TABLE `add_bank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(33) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `add_bank`
--

INSERT INTO `add_bank` VALUES(1, 'SBI', '1463382698');
INSERT INTO `add_bank` VALUES(2, 'Indiabulls', '1465801025');
INSERT INTO `add_bank` VALUES(3, 'Axis Bank', '1465801035');
INSERT INTO `add_bank` VALUES(4, 'ICICI', '1465801046');
INSERT INTO `add_bank` VALUES(5, 'SBH', '1465801061');
INSERT INTO `add_bank` VALUES(6, 'UBI', '1465801069');
INSERT INTO `add_bank` VALUES(7, 'DFHL', '1465801077');
INSERT INTO `add_bank` VALUES(8, 'Kotak', '1465801086');
INSERT INTO `add_bank` VALUES(9, 'Bajaj', '1465801092');
INSERT INTO `add_bank` VALUES(10, 'Future', '1465801100');
INSERT INTO `add_bank` VALUES(11, 'PNB', '1465801111');
INSERT INTO `add_bank` VALUES(12, 'Sundaram', '1465801115');
INSERT INTO `add_bank` VALUES(13, 'UCO', '1465801122');
INSERT INTO `add_bank` VALUES(14, 'SBT', '1465801133');
INSERT INTO `add_bank` VALUES(15, 'Andhra Bank', '1465801139');
INSERT INTO `add_bank` VALUES(16, 'HDFC', '1465801149');
INSERT INTO `add_bank` VALUES(17, 'Reliance Capital', '1465801168');
INSERT INTO `add_bank` VALUES(18, 'NA', '1465801172');

-- --------------------------------------------------------

--
-- Table structure for table `apartment`
--

CREATE TABLE `apartment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appt_tower` int(11) NOT NULL,
  `appt_block` varchar(20) NOT NULL,
  `appt_floor` varchar(44) NOT NULL,
  `flatno` varchar(33) NOT NULL,
  `size` varchar(33) NOT NULL,
  `type` varchar(33) NOT NULL,
  `no_bedrooms` varchar(33) NOT NULL,
  `no_bathrooms` varchar(33) NOT NULL,
  `no_balconies` varchar(33) NOT NULL,
  `facing` varchar(33) NOT NULL,
  `floorno` varchar(33) NOT NULL,
  `avroom` varchar(33) NOT NULL,
  `photo` longtext NOT NULL,
  `availabilitystatus` varchar(33) NOT NULL,
  `share` varchar(33) NOT NULL,
  `construction_stage` varchar(33) NOT NULL,
  `totalcost` varchar(33) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=252 ;

--
-- Dumping data for table `apartment`
--

INSERT INTO `apartment` VALUES(1, 1, '0', '1', '101', '1709', '', '3', '', '', 'south', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(2, 1, '0', '1', '102', '1705', '', '3', '', '', 'NORTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(3, 1, '0', '1', '103', '1688', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(4, 1, '0', '1', '104', '1705', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(5, 1, '0', '1', '105', '1688', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(6, 1, '0', '1', '106', '1699', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(7, 1, '0', '2', '201', '1709', '', '3', '', '', 'south', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(8, 1, '0', '2', '202', '1705', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(9, 1, '0', '2', '203', '1688', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(10, 1, '0', '2', '204', '1705', '', '3', '', '', 'NORTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(11, 1, '0', '2', '205', '1688', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(12, 1, '0', '2', '206', '1699', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(13, 1, '0', '3', '301', '1710', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(14, 1, '0', '3', '302', '1705', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(15, 1, '0', '3', '303', '1664', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(16, 1, '0', '3', '304', '1705', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(17, 1, '0', '3', '305', '1664', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(18, 1, '0', '3', '306', '1699', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(19, 1, '0', '4', '401', '1710', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(20, 1, '0', '4', '402', '1705', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(21, 1, '0', '4', '403', '1664', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(22, 1, '0', '4', '404', '1705', '', '3', '', '', 'NORTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(23, 1, '0', '4', '405', '1664', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(24, 1, '0', '4', '406', '1699', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(25, 2, '0', '1', '101', '1709', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(26, 2, '0', '1', '102', '1705', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(27, 2, '0', '1', '103', '1688', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(28, 2, '0', '1', '104', '1705', '', '3', '', '', 'NORTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(29, 2, '0', '1', '105', '1688', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(30, 2, '0', '1', '106', '1699', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(31, 2, '0', '2', '201', '1709', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(32, 2, '0', '2', '202', '1705', '', '3', '', '', 'NORTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(33, 2, '0', '2', '203', '1688', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(34, 2, '0', '2', '204', '1705', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(35, 2, '0', '2', '205', '1688', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(36, 2, '0', '2', '206', '1699', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(37, 2, '0', '3', '301', '1710', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(38, 2, '0', '3', '302', '1705', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(39, 2, '0', '3', '303', '1664', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(40, 2, '0', '3', '304', '1705', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(41, 2, '0', '3', '305', '1664', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(42, 2, '0', '3', '306', '1699', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(43, 2, '0', '4', '401', '1710', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(44, 2, '0', '4', '402', '1705', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(45, 2, '0', '4', '403', '1664', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(46, 2, '0', '4', '404', '1705', '', '3', '', '', 'NORTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(47, 2, '0', '4', '405', '1664', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(48, 2, '0', '4', '406', '1699', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(49, 3, '0', '1', '101', '1723', '', '3', '', '', 'NORTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(50, 3, '0', '1', '102', '1337', '', '2', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(51, 3, '0', '1', '103', '1337', '', '2', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(52, 3, '0', '1', '104', '1723', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(53, 3, '0', '1', '105', '1586', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(54, 3, '0', '1', '106', '1278', '', '2', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(55, 3, '0', '1', '107', '1278', '', '2', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(56, 3, '0', '1', '108', '1586', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(57, 3, '0', '2', '201', '1666', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(58, 3, '0', '2', '202', '1279', '', '2', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(59, 3, '0', '2', '203', '1279', '', '2', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(60, 3, '0', '2', '204', '1666', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(61, 3, '0', '2', '205', '1529', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(62, 3, '0', '2', '206', '1221', '', '2', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(63, 3, '0', '2', '207', '1221', '', '2', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(64, 3, '0', '2', '208', '1529', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(65, 3, '0', '3', '301', '1666', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(66, 3, '0', '3', '302', '1279', '', '2', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(67, 3, '0', '3', '303', '1279', '', '2', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(68, 3, '0', '3', '304', '1666', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(69, 3, '0', '3', '305', '1529', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(70, 3, '0', '3', '306', '1221', '', '2', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(71, 3, '0', '3', '307', '1221', '', '2', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(72, 3, '0', '3', '308', '1529', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(73, 3, '0', '4', '401', '1666', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(74, 3, '0', '4', '402', '1279', '', '2', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(75, 3, '0', '4', '403', '1279', '', '2', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(76, 3, '0', '4', '404', '1666', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(77, 3, '0', '4', '405', '1529', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(78, 3, '0', '4', '406', '1221', '', '2', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(79, 3, '0', '4', '407', '1221', '', '2', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(80, 3, '0', '4', '408', '1529', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(81, 3, '0', '5', '501', '1666', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(82, 3, '0', '5', '502', '1279', '', '2', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(83, 3, '0', '5', '503', '1279', '', '2', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(84, 3, '0', '5', '504', '1666', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(85, 3, '0', '5', '505', '1529', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(86, 3, '0', '5', '506', '1221', '', '2', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(87, 3, '0', '5', '507', '1221', '', '2', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(88, 3, '0', '5', '508', '1529', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(89, 3, '0', '6', '601', '1723', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(90, 3, '0', '6', '602', '1279', '', '2', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(91, 3, '0', '6', '603', '1279', '', '2', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(92, 3, '0', '6', '604', '1723', '', '3', '', '', 'NORTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(93, 3, '0', '6', '605', '1586', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(94, 3, '0', '6', '606', '1221', '', '2', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(95, 3, '0', '6', '607', '1221', '', '2', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(96, 3, '0', '6', '608', '1586', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(97, 3, '0', '7', '701', '1723', '', '3', '', '', 'NORTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(98, 3, '0', '7', '702', '1279', '', '2', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(99, 3, '0', '7', '703', '1279', '', '2', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(100, 3, '0', '7', '704', '1723', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(101, 3, '0', '7', '705', '1586', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(102, 3, '0', '7', '706', '1221', '', '2', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(103, 3, '0', '7', '707', '1221', '', '2', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(104, 3, '0', '7', '708', '1586', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(105, 3, '0', '8', '801', '1723', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(106, 3, '0', '8', '802', '1337', '', '2', '', '', 'NORTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(107, 3, '0', '8', '803', '1337', '', '2', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(108, 3, '0', '8', '804', '1723', '', '3', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(109, 3, '0', '8', '805', '1586', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(110, 3, '0', '8', '806', '1279', '', '2', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(111, 3, '0', '8', '807', '1278', '', '2', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(112, 3, '0', '8', '808', '1586', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(113, 3, '0', '9', '901', '1723', '', '3', '', '', 'NORTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(114, 3, '0', '9', '902', '1211', '', '2', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(115, 3, '0', '9', '903', '1337', '', '2', '', '', 'NORTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(116, 3, '0', '9', '904', '1723', '', '3', '', '', 'NORTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(117, 3, '0', '9', '905', '1586', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(118, 3, '0', '9', '906', '1279', '', '2', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(119, 3, '0', '9', '907', '1279', '', '2', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(120, 3, '0', '9', '908', '1586', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(121, 4, '0', 'G', 'SAV 01', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(122, 4, '0', 'G', 'SAV 02', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(123, 4, '0', 'G', 'SAV 03', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(124, 4, '0', 'G', 'SAV 04', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(125, 4, '0', 'G', 'SAV 05', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(126, 4, '0', 'G', 'SAV 06', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(127, 4, '0', 'G', 'SAV 07', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(128, 4, '0', 'G', 'SAV 08', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(129, 4, '0', 'G', 'SAV 09', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(130, 4, '0', 'G', 'SAV 10', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(131, 4, '0', 'G', 'SAV 11', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(132, 4, '0', 'G', 'SAV 12', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(133, 4, '0', 'G', 'SAV 13', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(134, 4, '0', 'G', 'SAV 14', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(135, 4, '0', 'G', 'SAV 15', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(136, 4, '0', 'G', 'SAV 16', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(137, 4, '0', 'G', 'SAV 17', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(138, 4, '0', 'G', 'SAV 18', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(139, 4, '0', 'G', 'SAV 19', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(140, 4, '0', 'G', 'SAV 20', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(141, 4, '0', 'G', 'SAV 21', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(142, 4, '0', 'G', 'SAV 22', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(143, 4, '0', 'G', 'SAV 23', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(144, 4, '0', 'G', 'SAV 24', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(145, 4, '0', 'G', 'SAV 25', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(146, 4, '0', 'G', 'SAV 26', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(147, 4, '0', 'G', 'SAV 27', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(148, 4, '0', 'G', 'SAV 28', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(149, 4, '0', 'G', 'SAV 29', '2705', '', '3', '', '', 'SOUTH', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(150, 5, '0', 'G', 'V 01', '4370', '', '5', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(151, 5, '0', 'G', 'V 02', '4370', '', '5', '', '', 'EAST', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(152, 5, '0', 'G', 'V 03', '4370', '', '5', '', '', 'EAST', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(153, 5, '0', 'G', 'V 04', '4370', '', '5', '', '', 'EAST', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(154, 5, '0', 'G', 'V 05', '4370', '', '5', '', '', 'EAST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(155, 5, '0', 'G', 'V 06', '4370', '', '5', '', '', 'EAST', '', '', '', 'no', 'landlord', '', '', '');
INSERT INTO `apartment` VALUES(156, 5, '0', 'G', 'V 07', '4370', '', '5', '', '', 'EAST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(157, 5, '0', 'G', 'V 08', '4370', '', '5', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(158, 5, '0', 'G', 'V 09', '4370', '', '5', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(159, 5, '0', 'G', 'V 10', '4370', '', '5', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(160, 5, '0', 'G', 'V 11', '4370', '', '5', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(161, 5, '0', 'G', 'V 12', '4370', '', '5', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(162, 5, '0', 'G', 'V 13', '4370', '', '5', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(163, 5, '0', 'G', 'V 14', '4370', '', '5', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(164, 5, '0', 'G', 'V 15', '4370', '', '5', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(165, 5, '0', 'G', 'V 16', '4370', '', '5', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(166, 5, '0', 'G', 'V 17', '4370', '', '5', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(167, 5, '0', 'G', 'V 18', '4370', '', '5', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(168, 6, 'Block 19', 'G', 'IRIS - W-V1-M1', '1263', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(169, 6, 'Block 19', 'G', 'IRIS - W-V2-M2', '1241', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(170, 6, 'Block 19', 'G', 'IRIS - W-V3-M3', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(171, 6, 'Block 19', 'G', 'IRIS - W-V4-M4', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(172, 6, 'Block 19', 'G', 'IRIS - W-V5-M5', '1241', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(173, 6, 'Block 19', 'G', 'IRIS - W-V6-M6', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(174, 6, 'Block 19', 'G', 'IRIS - W-V7-M7', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(175, 6, 'Block 19', 'G', 'IRIS - W-V8-M8', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(176, 6, 'Block 19', 'G', 'IRIS - W-V9-M9', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(177, 6, 'Block 19', 'G', 'IRIS - W-V10-M10', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(178, 6, 'Block 19', 'G', 'IRIS - W-V11-M11', '1263', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(179, 6, 'Block 18', 'G', 'IRIS - E-V1-M12', '1255', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(180, 6, 'Block 18', 'G', 'IRIS - E-V2-M13', '1233', '', '', '', '', 'EAST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(181, 6, 'Block 18', 'G', 'IRIS - E-V3-M14', '1233', '', '', '', '', 'EAST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(182, 6, 'Block 18', 'G', 'IRIS - E-V4-M15', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(183, 6, 'Block 18', 'G', 'IRIS - E-V5-M16', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(184, 6, 'Block 18', 'G', 'IRIS - E-V6-M17', '1233', '', '', '', '', 'EAST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(185, 6, 'Block 18', 'G', 'IRIS - E-V7-M18', '1233', '', '', '', '', 'EAST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(186, 6, 'Block 18', 'G', 'IRIS - E-V8-M19', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(187, 6, 'Block 18', 'G', 'IRIS - E-V9-M20', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(188, 6, 'Block 18', 'G', 'IRIS - E-V10-M21', '1233', '', '', '', '', 'EAST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(189, 6, 'Block 18', 'G', 'IRIS - E-V11-M22', '1255', '', '', '', '', 'EAST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(190, 6, 'Block 17', 'G', 'IRIS - W-V1-M23', '1263', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(191, 6, 'Block 17', 'G', 'IRIS - W-V2-M24', '1241', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(192, 6, 'Block 17', 'G', 'IRIS - W-V3-M25', '1241', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(193, 6, 'Block 17', 'G', 'IRIS - W-V4-M26', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(194, 6, 'Block 17', 'G', 'IRIS - W-V5-M27', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(195, 6, 'Block 17', 'G', 'IRIS - W-V6-M28', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(196, 6, 'Block 17', 'G', 'IRIS - W-V7-M29', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(197, 6, 'Block 17', 'G', 'IRIS - W-V8-M30', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(198, 6, 'Block 17', 'G', 'IRIS - W-V9-M31', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(199, 6, 'Block 17', 'G', 'IRIS - W-V10-M32', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(200, 6, 'Block 17', 'G', 'IRIS - W-V11-M33', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(201, 6, 'Block 17', 'G', 'IRIS - W-V12-M34', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(202, 6, 'Block 17', 'G', 'IRIS - W-V13-M35', '1241', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(203, 6, 'Block 17', 'G', 'IRIS - W-V14-M36', '1263', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(204, 6, 'Block 16', 'G', 'IRIS - E-V1-M37', '1255', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(205, 6, 'Block 16', 'G', 'IRIS - E-V2-M38', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(206, 6, 'Block 16', 'G', 'IRIS - E-V3-M39', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(207, 6, 'Block 16', 'G', 'IRIS - E-V4-M40', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(208, 6, 'Block 16', 'G', 'IRIS - E-V5-M41', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(209, 6, 'Block 16', 'G', 'IRIS - E-V6-M42', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(210, 6, 'Block 16', 'G', 'IRIS - E-V7-M43', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(211, 6, 'Block 16', 'G', 'IRIS - E-V8-M44', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(212, 6, 'Block 16', 'G', 'IRIS - E-V9-M45', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(213, 6, 'Block 16', 'G', 'IRIS - E-V10-M46', '1233', '', '', '', '', 'EAST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(214, 6, 'Block 16', 'G', 'IRIS - E-V11-M47', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(215, 6, 'Block 16', 'G', 'IRIS - E-V12-M48', '1233', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(216, 6, 'Block 16', 'G', 'IRIS - E-V13-M49', '1233', '', '', '', '', 'EAST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(217, 6, 'Block 16', 'G', 'IRIS - E-V14-M50', '1255', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(218, 7, 'SAV-1', 'G', 'ASTER - W-V1-M1', '1801', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(219, 7, 'SAV-1', 'G', 'ASTER - W-V2-M2', '1801', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(220, 7, 'SAV-2', 'G', 'ASTER - W-V3-M3', '1801', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(221, 7, 'SAV-2', 'G', 'ASTER - W-V4-M4', '1801', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(222, 7, 'SAV-3', 'G', 'ASTER - W-V5-M5', '1801', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(223, 7, 'SAV-3', 'G', 'ASTER - W-V6-M6', '1801', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(224, 7, 'SAV-4', 'G', 'ASTER - W-V7-M7', '1801', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(225, 7, 'SAV-4', 'G', 'ASTER - W-V8-M8', '1801', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(226, 7, 'SAV-5', 'G', 'ASTER - W-V9-M9', '1801', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(227, 7, 'SAV-5', 'G', 'ASTER - W-V10-M10', '1801', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(228, 7, 'SAV-6', 'G', 'ASTER - W-V11-M11', '1801', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(229, 7, 'SAV-6', 'G', 'ASTER - W-V12-M12', '1801', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(230, 7, 'V-19', 'G', 'ASTER - W-V-19-M13', '1839', '', '', '', '', 'WEST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(231, 7, 'SAV-7', 'G', 'ASTER - W-V13-M14', '1801', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(232, 7, 'SAV-7', 'G', 'ASTER - W-V14-M15', '1801', '', '', '', '', 'WEST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(233, 7, 'SAV-8', 'G', 'ASTER - E-V32-M16', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(234, 7, 'SAV-8', 'G', 'ASTER - E-V31-M17', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(235, 7, 'SAV-9', 'G', 'ASTER - E-V30-M18', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(236, 7, 'SAV-9', 'G', 'ASTER - E-V29-M19', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(237, 7, 'SAV-10', 'G', 'ASTER - E-V28-M20', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(238, 7, 'SAV-10', 'G', 'ASTER - E-V27-M21', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(239, 7, 'SAV-11', 'G', 'ASTER - E-V26-M22', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(240, 7, 'SAV-11', 'G', 'ASTER - E-V25-M23', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(241, 7, 'SAV-12', 'G', 'ASTER - E-V24-M24', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(242, 7, 'SAV-12', 'G', 'ASTER - E-V23-M25', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(243, 7, 'SAV-13', 'G', 'ASTER - E-V22-M26', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(244, 7, 'SAV-13', 'G', 'ASTER - E-V21-M27', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(245, 7, 'V-20', 'G', 'ASTER - E-V-20-M28', '1852', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(246, 7, 'SAV-14', 'G', 'ASTER - E-V20-M29', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(247, 7, 'SAV-14', 'G', 'ASTER - E-V19-M30', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(248, 7, 'SAV-15', 'G', 'ASTER - E-V18-M31', '1806', '', '', '', '', 'EAST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(249, 7, 'SAV-15', 'G', 'ASTER - E-V17-M32', '1806', '', '', '', '', 'EAST', '', '', '', 'yes', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(250, 7, 'SAV-16', 'G', 'ASTER - E-V16-M33', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');
INSERT INTO `apartment` VALUES(251, 7, 'SAV-16', 'G', 'ASTER - E-V15-M34', '1806', '', '', '', '', 'EAST', '', '', '', 'no', 'developer', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `banned_users`
--

CREATE TABLE `banned_users` (
  `username` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `banned_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `block`
--

CREATE TABLE `block` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `block_tower` varchar(44) NOT NULL,
  `block_name` varchar(44) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `block`
--

INSERT INTO `block` VALUES(1, '1', '1(F-1)', '1465282484');
INSERT INTO `block` VALUES(2, '1', '2(F-2)', '1465282562');
INSERT INTO `block` VALUES(3, '1', '3(F-3)', '1465282573');
INSERT INTO `block` VALUES(4, '1', '4(F-4)', '1465282582');
INSERT INTO `block` VALUES(5, '1', '5(F-5)', '1465282595');
INSERT INTO `block` VALUES(6, '1', '6(F-6)', '1465282603');
INSERT INTO `block` VALUES(7, '1', '7(F-7)', '1465282612');
INSERT INTO `block` VALUES(8, '1', '8(F-8)', '1465282621');
INSERT INTO `block` VALUES(9, '2', '1(E-1)', '1465282658');
INSERT INTO `block` VALUES(10, '2', '2(E-2)', '1465282671');
INSERT INTO `block` VALUES(11, '2', '3(E-3)', '1465282687');
INSERT INTO `block` VALUES(12, '2', '4(E-4)', '1465282723');
INSERT INTO `block` VALUES(13, '2', '5(E-5)', '1465282731');
INSERT INTO `block` VALUES(14, '2', '6(E-6)', '1465282740');
INSERT INTO `block` VALUES(15, '3', '1(O-1)', '1465282761');
INSERT INTO `block` VALUES(16, '3', '2(O-2)', '1465282770');
INSERT INTO `block` VALUES(17, '3', '3(O-3)', '1465282778');
INSERT INTO `block` VALUES(18, '3', '4(O-4)', '1465282788');

-- --------------------------------------------------------

--
-- Table structure for table `campaign`
--

CREATE TABLE `campaign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(33) NOT NULL,
  `description` varchar(33) NOT NULL,
  `photo` longtext NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `campaign`
--

INSERT INTO `campaign` VALUES(3, 'Hoardings', 'Hoardings @ Madhapur,Hitech city,', 'ec0b51eb6d71681836910fbf36b0f8fd.jpg', '1465800651');
INSERT INTO `campaign` VALUES(2, 'Banners', 'Banners at major parts in the cit', '4699c4c61af8dc51bd0881ff2ee15a5c.jpg', '1465800602');
INSERT INTO `campaign` VALUES(4, 'commonfloor', 'online ad', '', '1470030529');
INSERT INTO `campaign` VALUES(5, 'Direct Walkin', 'direct walk-ins', '', '1470200167');
INSERT INTO `campaign` VALUES(6, 'Centre Medians-Film nagar road', 'at Film nagar road from praksh ar', '', '1470200287');
INSERT INTO `campaign` VALUES(7, 'Luxury Magic bricks', 'Luxury magic bricks', '', '1470200320');
INSERT INTO `campaign` VALUES(8, '99acres', 'campaign', '', '1470200429');
INSERT INTO `campaign` VALUES(9, 'Website', 'website -  halcyonphoenix.com', '', '1470200487');
INSERT INTO `campaign` VALUES(10, 'Google', 'search', '', '1470200503');
INSERT INTO `campaign` VALUES(11, 'Events', 'Events', '', '1470635067');
INSERT INTO `campaign` VALUES(12, 'Friend', 'Friend', '', '1470635084');
INSERT INTO `campaign` VALUES(13, 'Limelight', 'Limelight', '', '1470635093');
INSERT INTO `campaign` VALUES(14, 'Reference', 'Reference', '', '1470635110');
INSERT INTO `campaign` VALUES(15, 'Top management', 'Top management', '', '1470635152');
INSERT INTO `campaign` VALUES(16, 'Channel Partner', 'GOCO', '', '1471071768');

-- --------------------------------------------------------

--
-- Table structure for table `construction_stages`
--

CREATE TABLE `construction_stages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cs_tower` varchar(55) NOT NULL,
  `stagename` varchar(33) NOT NULL,
  `description` longtext NOT NULL,
  `perc` int(11) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `construction_stages`
--

INSERT INTO `construction_stages` VALUES(1, '1', 'F-BA', '', 5, '1465295108');
INSERT INTO `construction_stages` VALUES(2, '1', 'F-AOS', '', 15, '1465295121');
INSERT INTO `construction_stages` VALUES(3, '1', 'F-Stage1', '', 10, '1465295138');
INSERT INTO `construction_stages` VALUES(4, '1', 'F-Stage2', '', 15, '1465295150');
INSERT INTO `construction_stages` VALUES(5, '1', 'F-Stage3', '', 15, '1465295159');
INSERT INTO `construction_stages` VALUES(6, '1', 'F-Stage4', '', 10, '1465295166');
INSERT INTO `construction_stages` VALUES(7, '1', 'F-Stage5', '', 10, '1465295172');
INSERT INTO `construction_stages` VALUES(8, '1', 'F-Stage6', '', 10, '1465295179');
INSERT INTO `construction_stages` VALUES(9, '1', 'F-Stage7', '', 5, '1465295189');
INSERT INTO `construction_stages` VALUES(10, '1', 'F-Stage8', '', 5, '1465295197');
INSERT INTO `construction_stages` VALUES(11, '2', 'E-BA', '', 5, '1465295212');
INSERT INTO `construction_stages` VALUES(12, '2', 'E-AOS', '', 15, '1465295223');
INSERT INTO `construction_stages` VALUES(13, '2', 'E-Stage1', '', 10, '1465295238');
INSERT INTO `construction_stages` VALUES(14, '2', 'E-Stage2', '', 15, '1465295250');
INSERT INTO `construction_stages` VALUES(15, '2', 'E-Stage3', '', 15, '1465295257');
INSERT INTO `construction_stages` VALUES(16, '2', 'E-Stage4', '', 10, '1465295263');
INSERT INTO `construction_stages` VALUES(17, '2', 'E-Stage5', '', 10, '1465295269');
INSERT INTO `construction_stages` VALUES(18, '2', 'E-Stage6', '', 10, '1465295276');
INSERT INTO `construction_stages` VALUES(19, '2', 'E-Stage7', '', 5, '1465295282');
INSERT INTO `construction_stages` VALUES(20, '2', 'E-Stage8', '', 5, '1465295288');
INSERT INTO `construction_stages` VALUES(21, '3', 'O-BA', '', 5, '1465295303');
INSERT INTO `construction_stages` VALUES(22, '3', 'O-AOS', '', 15, '1465295310');
INSERT INTO `construction_stages` VALUES(23, '3', 'O-Stage1', '', 10, '1465295324');
INSERT INTO `construction_stages` VALUES(24, '3', 'O-Stage2', '', 20, '1465295331');
INSERT INTO `construction_stages` VALUES(25, '3', 'O-Stage3', '', 20, '1465295338');
INSERT INTO `construction_stages` VALUES(26, '3', 'O-Stage4', '', 10, '1465295345');
INSERT INTO `construction_stages` VALUES(27, '3', 'O-Stage5', '', 10, '1465295357');
INSERT INTO `construction_stages` VALUES(28, '3', 'O-Stage6', '', 5, '1465295363');
INSERT INTO `construction_stages` VALUES(29, '3', 'O-Stage7', '', 5, '1465295371');
INSERT INTO `construction_stages` VALUES(30, '3', 'O-Stage8', '', 0, '1465295377');

-- --------------------------------------------------------

--
-- Table structure for table `creatediscount`
--

CREATE TABLE `creatediscount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(23) NOT NULL,
  `margin` varchar(33) NOT NULL,
  `discount` varchar(33) NOT NULL,
  `remark` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `creatediscount`
--

INSERT INTO `creatediscount` VALUES(1, 'somu', '56', 'thousand', '1462336952');
INSERT INTO `creatediscount` VALUES(2, 'ganesh', '25000', 'fourty per', '1462337051');

-- --------------------------------------------------------

--
-- Table structure for table `createemployees`
--

CREATE TABLE `createemployees` (
  `id` int(23) NOT NULL AUTO_INCREMENT,
  `name` varchar(33) NOT NULL,
  `mobilenumber` varchar(33) NOT NULL,
  `emailid` varchar(33) NOT NULL,
  `employeeid` varchar(33) NOT NULL,
  `employee_type` varchar(33) NOT NULL,
  `address` longtext NOT NULL,
  `username` varchar(33) NOT NULL,
  `password` varchar(33) NOT NULL,
  `timstamp` varchar(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employeeid` (`employeeid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `createemployees`
--

INSERT INTO `createemployees` VALUES(14, 'Sai Priya', '8142288288', 'saipriya.g@phoenxindia.net', '0009', 'salesmanager', 'Hyderabad', 'saipriya', 'saipriya@123', '1470636492');
INSERT INTO `createemployees` VALUES(16, 'Mr. Chaitanya', '8125016951', 'chaitanya.b@phoenixindia.net', '0008', 'salesmanager', 'Hyderabad', 'chaitanya', 'chaitanya', '1471864895');
INSERT INTO `createemployees` VALUES(13, 'Jayaprada', '9885769423', 'jayapradag@halcyonphoenix.com', '0007', 'salesmanager', 'Hyderabad', 'jayapradag', 'jayaprada@123', '1470636395');
INSERT INTO `createemployees` VALUES(15, 'Mr. Vidhya Murthy', '7799677877', 'vidya.vmiyer@gmail.com', '001', 'director', 'hyderabad', 'vidhyamurthy', 'vidhya123', '1471854471');
INSERT INTO `createemployees` VALUES(7, 'siva kiran reddy', '8886478800', 'sivakiran.t@phoenixindia.net', '0006', 'salesmanager', 'hyderabad', 'sivakiran.t', 'siva@123', '1468922290');
INSERT INTO `createemployees` VALUES(17, 'bobbyg', '9948370707', 'jprada@hotmail.com', '123', 'salesmanager', 'padmalaya studios', 'bobbyg', 'bobbyg123', '1473835025');
INSERT INTO `createemployees` VALUES(18, 'Vinod', '9445093333', 'vinu@the-village.in', '00021', 'salesmanager', 'hyderabad', 'vinod', 'vinu@123', '1474529912');
INSERT INTO `createemployees` VALUES(19, 'Mr. Antony', '9445043333', 'antony@the-ticketingsystem.in', '020025', 'director', 'hyderabad', 'antony', 'antony123', '1474530241');

-- --------------------------------------------------------

--
-- Table structure for table `createflat`
--

CREATE TABLE `createflat` (
  `id` int(23) NOT NULL AUTO_INCREMENT,
  `flat_tower` varchar(23) NOT NULL,
  `flat_floor` varchar(23) NOT NULL,
  `flat_number` varchar(33) NOT NULL,
  `flat_description` longtext NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `createflat`
--


-- --------------------------------------------------------

--
-- Table structure for table `createtower`
--

CREATE TABLE `createtower` (
  `id` int(23) NOT NULL AUTO_INCREMENT,
  `name` varchar(33) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `createtower`
--

INSERT INTO `createtower` VALUES(1, 'Tower1', 1463057632);
INSERT INTO `createtower` VALUES(2, 'Tower2', 1463057642);
INSERT INTO `createtower` VALUES(3, 'Tower3', 1463465417);
INSERT INTO `createtower` VALUES(4, 'AV', 1477043337);
INSERT INTO `createtower` VALUES(5, 'VILLA', 1477044128);
INSERT INTO `createtower` VALUES(6, 'IRIS', 1477314022);
INSERT INTO `createtower` VALUES(7, 'ASTER', 1477314042);

-- --------------------------------------------------------

--
-- Table structure for table `criteriaforsale`
--

CREATE TABLE `criteriaforsale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `criteria` varchar(33) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `criteriaforsale`
--

INSERT INTO `criteriaforsale` VALUES(1, 'Regular', '1465800435');
INSERT INTO `criteriaforsale` VALUES(2, 'Furnishing', '1465800448');
INSERT INTO `criteriaforsale` VALUES(3, 'Pre-EMI with Furnishing', '1465800458');
INSERT INTO `criteriaforsale` VALUES(5, 'Pre-EMI', '1465800480');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unid` varchar(22) NOT NULL,
  `customer_name` varchar(33) NOT NULL,
  `tower` varchar(44) NOT NULL,
  `flat_no` varchar(33) NOT NULL,
  `landline` varchar(33) NOT NULL,
  `mobile1` varchar(33) NOT NULL,
  `mobile2` varchar(33) NOT NULL,
  `email_id` varchar(33) NOT NULL,
  `finance` varchar(33) NOT NULL,
  `type` varchar(33) NOT NULL,
  `booking_date` varchar(33) NOT NULL,
  `ageing` varchar(33) NOT NULL,
  `source` varchar(33) NOT NULL,
  `revised_sft` varchar(33) NOT NULL,
  `rateper_sft` varchar(33) NOT NULL,
  `construction_stage` varchar(33) NOT NULL,
  `basic_saleprice` varchar(33) NOT NULL,
  `infrastructure` varchar(33) NOT NULL,
  `deposits` varchar(33) NOT NULL,
  `dg_backup` varchar(33) NOT NULL,
  `charges` varchar(33) NOT NULL,
  `clubhouse` varchar(33) NOT NULL,
  `documentation_charges` varchar(33) NOT NULL,
  `totalvalue_excltax` varchar(33) NOT NULL,
  `servicetax` varchar(33) NOT NULL,
  `totalvalue_incltax` varchar(33) NOT NULL,
  `amt_receivable` varchar(33) NOT NULL,
  `amtreceived_customer` varchar(33) NOT NULL,
  `amtreceived_bank` varchar(33) NOT NULL,
  `totalamt_received` varchar(33) NOT NULL,
  `servicetax_collected` varchar(33) NOT NULL,
  `documentation_charges1` varchar(33) NOT NULL,
  `netamt_received` varchar(33) NOT NULL,
  `perc_received` varchar(33) NOT NULL,
  `amt_due` varchar(33) NOT NULL,
  `finance1` varchar(33) NOT NULL,
  `loan_status` varchar(33) NOT NULL,
  `bank_name` varchar(33) NOT NULL,
  `loan_accno` varchar(33) NOT NULL,
  `sanctioned_limit` varchar(33) NOT NULL,
  `perc_sanctioned` varchar(33) NOT NULL,
  `aos_date` varchar(33) NOT NULL,
  `pan_no` varchar(33) NOT NULL,
  `base_rate` varchar(33) NOT NULL,
  `roi` varchar(33) NOT NULL,
  `criteria_forsale` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `dob` varchar(33) NOT NULL,
  `marriage_date` varchar(33) NOT NULL,
  `service_tax` varchar(33) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unid` (`unid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customers`
--


-- --------------------------------------------------------

--
-- Table structure for table `ebrochure`
--

CREATE TABLE `ebrochure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eb_title` varchar(50) NOT NULL,
  `e_brochure` longtext NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `ebrochure`
--

INSERT INTO `ebrochure` VALUES(9, 'E-Brochure', '46f79fb38efafee16bee173530fa9afc.pdf', '1469085179');
INSERT INTO `ebrochure` VALUES(10, 'Snapshot', '3a4c6a89af274b122a5aee3a5d666a99.jpg', '1471335820');
INSERT INTO `ebrochure` VALUES(12, 'Pricing sheet', '9aecb3d6374037a967f356854e82058e.pdf', '1472799043');

-- --------------------------------------------------------

--
-- Table structure for table `flatnumber`
--

CREATE TABLE `flatnumber` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flatnum_tower` varchar(44) NOT NULL,
  `flatnum_block` varchar(44) NOT NULL,
  `flatnum_floor` varchar(44) NOT NULL,
  `flatnum_type` varchar(44) NOT NULL,
  `flat_number` varchar(44) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `flatnumber`
--


-- --------------------------------------------------------

--
-- Table structure for table `flattype`
--

CREATE TABLE `flattype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flat_type` varchar(33) NOT NULL,
  `flat_sft` varchar(44) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `flattype`
--

INSERT INTO `flattype` VALUES(1, '5b', '6757', '1465279531');
INSERT INTO `flattype` VALUES(2, '5b', '7757', '1465279544');
INSERT INTO `flattype` VALUES(3, '3b', '2862', '1465279572');
INSERT INTO `flattype` VALUES(4, '3b', '2699', '1465279581');
INSERT INTO `flattype` VALUES(5, '3b', '3798', '1465279601');
INSERT INTO `flattype` VALUES(6, '3b', '3537', '1465279641');
INSERT INTO `flattype` VALUES(7, '4b', '3500', '1465279676');
INSERT INTO `flattype` VALUES(8, '4b', '4082', '1465279685');
INSERT INTO `flattype` VALUES(9, '4b', '4330', '1465279708');
INSERT INTO `flattype` VALUES(10, '4b', '4897', '1465279719');
INSERT INTO `flattype` VALUES(11, '4b', '5624', '1465279734');
INSERT INTO `flattype` VALUES(12, '4b', '4731', '1465279765');
INSERT INTO `flattype` VALUES(13, '4b', '4725', '1465279781');
INSERT INTO `flattype` VALUES(14, '4b', '5190', '1465279792');
INSERT INTO `flattype` VALUES(17, '4b', '4725', '1469442496');

-- --------------------------------------------------------

--
-- Table structure for table `floors`
--

CREATE TABLE `floors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `floor_tower` varchar(44) NOT NULL,
  `floor_block` varchar(44) NOT NULL,
  `floor_name` varchar(33) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=170 ;

--
-- Dumping data for table `floors`
--

INSERT INTO `floors` VALUES(2, '1', '1', '1', '1465279870');
INSERT INTO `floors` VALUES(3, '1', '1', '2', '1465279887');
INSERT INTO `floors` VALUES(4, '1', '1', '3', '1465279900');
INSERT INTO `floors` VALUES(5, '1', '1', '4', '1465279917');
INSERT INTO `floors` VALUES(6, '1', '1', '5', '1465279924');
INSERT INTO `floors` VALUES(7, '1', '1', '6', '1465279937');
INSERT INTO `floors` VALUES(8, '1', '1', '7', '1465279959');
INSERT INTO `floors` VALUES(9, '1', '1', '8', '1465279967');
INSERT INTO `floors` VALUES(10, '1', '1', '9', '1465279975');
INSERT INTO `floors` VALUES(12, '1', '2', '1', '1465280006');
INSERT INTO `floors` VALUES(13, '1', '2', '2', '1465280013');
INSERT INTO `floors` VALUES(14, '1', '2', '3', '1465280039');
INSERT INTO `floors` VALUES(15, '1', '2', '4', '1465280046');
INSERT INTO `floors` VALUES(16, '1', '2', '5', '1465280090');
INSERT INTO `floors` VALUES(17, '1', '2', '6', '1465280107');
INSERT INTO `floors` VALUES(18, '1', '2', '7', '1465280114');
INSERT INTO `floors` VALUES(19, '1', '2', '8', '1465280123');
INSERT INTO `floors` VALUES(20, '1', '2', '9', '1465280129');
INSERT INTO `floors` VALUES(22, '1', '3', '1', '1465280164');
INSERT INTO `floors` VALUES(23, '1', '3', '2', '1465280192');
INSERT INTO `floors` VALUES(24, '1', '3', '3', '1465280204');
INSERT INTO `floors` VALUES(25, '1', '3', '4', '1465280210');
INSERT INTO `floors` VALUES(26, '1', '3', '5', '1465280220');
INSERT INTO `floors` VALUES(27, '1', '3', '6', '1465280234');
INSERT INTO `floors` VALUES(28, '1', '3', '7', '1465280240');
INSERT INTO `floors` VALUES(29, '1', '3', '8', '1465280252');
INSERT INTO `floors` VALUES(30, '1', '3', '9', '1465280258');
INSERT INTO `floors` VALUES(169, '1', '1', 'G', '1470916380');
INSERT INTO `floors` VALUES(32, '1', '4', '1', '1465280339');
INSERT INTO `floors` VALUES(33, '1', '4', '2', '1465280349');
INSERT INTO `floors` VALUES(34, '1', '4', '3', '1465280355');
INSERT INTO `floors` VALUES(35, '1', '4', '4', '1465280362');
INSERT INTO `floors` VALUES(36, '1', '4', '5', '1465280369');
INSERT INTO `floors` VALUES(37, '1', '4', '6', '1465280386');
INSERT INTO `floors` VALUES(38, '1', '4', '7', '1465280396');
INSERT INTO `floors` VALUES(39, '1', '4', '8', '1465280403');
INSERT INTO `floors` VALUES(40, '1', '4', '9', '1465280409');
INSERT INTO `floors` VALUES(41, '1', '5', '1', '1465280452');
INSERT INTO `floors` VALUES(42, '1', '5', '2', '1465280458');
INSERT INTO `floors` VALUES(43, '1', '5', '3', '1465280466');
INSERT INTO `floors` VALUES(44, '1', '5', '4', '1465280473');
INSERT INTO `floors` VALUES(45, '1', '5', '5', '1465280480');
INSERT INTO `floors` VALUES(46, '1', '5', '6', '1465280486');
INSERT INTO `floors` VALUES(47, '1', '5', '7', '1465280493');
INSERT INTO `floors` VALUES(48, '1', '5', '8', '1465280501');
INSERT INTO `floors` VALUES(49, '1', '5', '9', '1465280507');
INSERT INTO `floors` VALUES(50, '1', '6', '1', '1465280547');
INSERT INTO `floors` VALUES(51, '1', '6', '2', '1465280555');
INSERT INTO `floors` VALUES(52, '1', '6', '3', '1465280576');
INSERT INTO `floors` VALUES(53, '1', '6', '4', '1465280582');
INSERT INTO `floors` VALUES(54, '1', '6', '5', '1465280788');
INSERT INTO `floors` VALUES(55, '1', '6', '6', '1465280797');
INSERT INTO `floors` VALUES(56, '1', '6', '7', '1465280803');
INSERT INTO `floors` VALUES(57, '1', '6', '8', '1465280809');
INSERT INTO `floors` VALUES(58, '1', '6', '9', '1465280816');
INSERT INTO `floors` VALUES(59, '1', '7', '1', '1465280850');
INSERT INTO `floors` VALUES(60, '1', '7', '2', '1465280858');
INSERT INTO `floors` VALUES(61, '1', '7', '3', '1465280874');
INSERT INTO `floors` VALUES(62, '1', '7', '4', '1465280880');
INSERT INTO `floors` VALUES(63, '1', '7', '5', '1465280891');
INSERT INTO `floors` VALUES(64, '1', '7', '6', '1465280897');
INSERT INTO `floors` VALUES(65, '1', '7', '7', '1465280904');
INSERT INTO `floors` VALUES(66, '1', '7', '8', '1465280909');
INSERT INTO `floors` VALUES(67, '1', '7', '9', '1465280928');
INSERT INTO `floors` VALUES(68, '1', '8', '1', '1465280948');
INSERT INTO `floors` VALUES(69, '1', '8', '2', '1465280954');
INSERT INTO `floors` VALUES(70, '1', '8', '3', '1465280961');
INSERT INTO `floors` VALUES(71, '1', '8', '4', '1465280971');
INSERT INTO `floors` VALUES(72, '1', '8', '5', '1465280977');
INSERT INTO `floors` VALUES(73, '1', '8', '6', '1465280989');
INSERT INTO `floors` VALUES(74, '1', '8', '7', '1465280997');
INSERT INTO `floors` VALUES(75, '1', '8', '8', '1465281013');
INSERT INTO `floors` VALUES(76, '1', '8', '9', '1465281019');
INSERT INTO `floors` VALUES(77, '2', '9', 'G', '1465281074');
INSERT INTO `floors` VALUES(78, '2', '9', '1', '1465281082');
INSERT INTO `floors` VALUES(79, '2', '9', '2', '1465281087');
INSERT INTO `floors` VALUES(80, '2', '9', '3', '1465281116');
INSERT INTO `floors` VALUES(81, '2', '9', '4', '1465281122');
INSERT INTO `floors` VALUES(82, '2', '9', '5', '1465281127');
INSERT INTO `floors` VALUES(83, '2', '9', '6', '1465281132');
INSERT INTO `floors` VALUES(84, '2', '9', '7', '1465281150');
INSERT INTO `floors` VALUES(85, '2', '10', 'G', '1465281174');
INSERT INTO `floors` VALUES(86, '2', '10', '1', '1465281180');
INSERT INTO `floors` VALUES(87, '2', '10', '2', '1465281187');
INSERT INTO `floors` VALUES(88, '2', '10', '3', '1465281193');
INSERT INTO `floors` VALUES(89, '2', '10', '4', '1465281199');
INSERT INTO `floors` VALUES(90, '2', '10', '5', '1465281205');
INSERT INTO `floors` VALUES(91, '2', '10', '6', '1465281211');
INSERT INTO `floors` VALUES(92, '2', '10', '7', '1465281217');
INSERT INTO `floors` VALUES(93, '2', '11', 'G', '1465281261');
INSERT INTO `floors` VALUES(94, '2', '11', '1', '1465281278');
INSERT INTO `floors` VALUES(95, '2', '11', '2', '1465281284');
INSERT INTO `floors` VALUES(96, '2', '11', '3', '1465281290');
INSERT INTO `floors` VALUES(97, '2', '11', '4', '1465281297');
INSERT INTO `floors` VALUES(98, '2', '11', '5', '1465281311');
INSERT INTO `floors` VALUES(99, '2', '11', '6', '1465281318');
INSERT INTO `floors` VALUES(100, '2', '11', '7', '1465281332');
INSERT INTO `floors` VALUES(101, '2', '12', 'G', '1465281379');
INSERT INTO `floors` VALUES(102, '2', '12', '1', '1465281390');
INSERT INTO `floors` VALUES(103, '2', '12', '2', '1465281401');
INSERT INTO `floors` VALUES(104, '2', '12', '3', '1465281409');
INSERT INTO `floors` VALUES(105, '2', '12', '4', '1465281415');
INSERT INTO `floors` VALUES(106, '2', '12', '5', '1465281421');
INSERT INTO `floors` VALUES(107, '2', '12', '6', '1465281434');
INSERT INTO `floors` VALUES(108, '2', '12', '7', '1465281441');
INSERT INTO `floors` VALUES(109, '2', '13', 'G', '1465281456');
INSERT INTO `floors` VALUES(110, '2', '13', '1', '1465281463');
INSERT INTO `floors` VALUES(111, '2', '13', '2', '1465281486');
INSERT INTO `floors` VALUES(112, '2', '13', '3', '1465281497');
INSERT INTO `floors` VALUES(113, '2', '13', '4', '1465281504');
INSERT INTO `floors` VALUES(114, '2', '13', '5', '1465281510');
INSERT INTO `floors` VALUES(115, '2', '13', '6', '1465281518');
INSERT INTO `floors` VALUES(116, '2', '13', '7', '1465281524');
INSERT INTO `floors` VALUES(117, '2', '14', 'G', '1465281593');
INSERT INTO `floors` VALUES(118, '2', '14', '1', '1465281599');
INSERT INTO `floors` VALUES(119, '2', '14', '2', '1465281614');
INSERT INTO `floors` VALUES(120, '2', '14', '3', '1465281621');
INSERT INTO `floors` VALUES(121, '2', '14', '4', '1465281627');
INSERT INTO `floors` VALUES(122, '2', '14', '5', '1465281633');
INSERT INTO `floors` VALUES(123, '2', '14', '6', '1465281639');
INSERT INTO `floors` VALUES(124, '2', '14', '7', '1465281648');
INSERT INTO `floors` VALUES(125, '3', '15', 'G', '1465281747');
INSERT INTO `floors` VALUES(126, '3', '15', '1', '1465281771');
INSERT INTO `floors` VALUES(127, '3', '15', '2', '1465281779');
INSERT INTO `floors` VALUES(128, '3', '15', '3', '1465281785');
INSERT INTO `floors` VALUES(129, '3', '15', '4', '1465281791');
INSERT INTO `floors` VALUES(130, '3', '15', '5', '1465281797');
INSERT INTO `floors` VALUES(131, '3', '15', '6', '1465281803');
INSERT INTO `floors` VALUES(132, '3', '15', '7', '1465281813');
INSERT INTO `floors` VALUES(133, '3', '16', 'G', '1465281851');
INSERT INTO `floors` VALUES(134, '3', '16', '1', '1465281860');
INSERT INTO `floors` VALUES(135, '3', '16', '2', '1465281865');
INSERT INTO `floors` VALUES(136, '3', '16', '3', '1465281872');
INSERT INTO `floors` VALUES(137, '3', '16', '4', '1465281877');
INSERT INTO `floors` VALUES(138, '3', '16', '5', '1465281883');
INSERT INTO `floors` VALUES(139, '3', '16', '6', '1465281889');
INSERT INTO `floors` VALUES(140, '3', '16', '7', '1465281898');
INSERT INTO `floors` VALUES(141, '3', '17', 'G', '1465281950');
INSERT INTO `floors` VALUES(142, '3', '17', '1', '1465281957');
INSERT INTO `floors` VALUES(143, '3', '17', '2', '1465281963');
INSERT INTO `floors` VALUES(144, '3', '17', '3', '1465281969');
INSERT INTO `floors` VALUES(145, '3', '17', '4', '1465281975');
INSERT INTO `floors` VALUES(146, '3', '17', '5', '1465281981');
INSERT INTO `floors` VALUES(147, '3', '17', '6', '1465281987');
INSERT INTO `floors` VALUES(148, '3', '17', '7', '1465281994');
INSERT INTO `floors` VALUES(149, '3', '18', 'G', '1465282261');
INSERT INTO `floors` VALUES(150, '3', '18', '1', '1465282266');
INSERT INTO `floors` VALUES(151, '3', '18', '2', '1465282271');
INSERT INTO `floors` VALUES(152, '3', '18', '3', '1465282277');
INSERT INTO `floors` VALUES(153, '3', '18', '4', '1465282283');
INSERT INTO `floors` VALUES(154, '3', '18', '5', '1465282289');
INSERT INTO `floors` VALUES(155, '3', '18', '6', '1465282295');
INSERT INTO `floors` VALUES(156, '3', '18', '7', '1465282301');
INSERT INTO `floors` VALUES(168, '1', '4', '10', '1470468552');
INSERT INTO `floors` VALUES(167, '1', '3', '10', '1470468543');
INSERT INTO `floors` VALUES(166, '1', '2', '10', '1470468534');
INSERT INTO `floors` VALUES(165, '1', '1', '10', '1470468521');
INSERT INTO `floors` VALUES(161, '1', '5', '10', '1470467150');
INSERT INTO `floors` VALUES(162, '1', '6', '10', '1470467161');
INSERT INTO `floors` VALUES(163, '1', '7', '10', '1470467169');
INSERT INTO `floors` VALUES(164, '1', '8', '10', '1470467179');

-- --------------------------------------------------------

--
-- Table structure for table `floor_plan`
--

CREATE TABLE `floor_plan` (
  `id` int(33) NOT NULL AUTO_INCREMENT,
  `selecttower` varchar(33) NOT NULL,
  `flat_type` varchar(33) NOT NULL,
  `imageupload` varchar(100) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `floor_plan`
--

INSERT INTO `floor_plan` VALUES(11, '2', '10', '901b1c9259317b864c02441904d27f41.pdf', '1467786402');
INSERT INTO `floor_plan` VALUES(10, '2', '9', '3e2e5afab85856b96206d0575f4050c5.pdf', '1467786321');
INSERT INTO `floor_plan` VALUES(9, '2', '6', '5cbdf442f7d584583d031df72a875b84.pdf', '1467786249');
INSERT INTO `floor_plan` VALUES(8, '2', '5', '9ad88d14c7cb4b5fa1596b1adf7edbc3.pdf', '1467786029');
INSERT INTO `floor_plan` VALUES(12, '2', '11', 'bbff652e0b5dd4b61522a6a64c12592f.pdf', '1467786481');
INSERT INTO `floor_plan` VALUES(20, '1', '1', '54f90f906554a5d7fd62ec11a95d937f.JPG', '1472807402');
INSERT INTO `floor_plan` VALUES(17, '3', '14', 'a7af1bfca32cb4708d8f30708b846452.jpg', '1469442546');
INSERT INTO `floor_plan` VALUES(16, '3', '13', '7e9b09920e6feba990bce6241232cf6f.jpg', '1469442378');
INSERT INTO `floor_plan` VALUES(18, '3', '16', '16dbacc658602d6363ba443b20fcfc80.jpg', '1469442611');
INSERT INTO `floor_plan` VALUES(19, '3', '17', '81c186aa31db262d357fae20db0bf74a.jpg', '1469442641');
INSERT INTO `floor_plan` VALUES(21, '1', '2', 'ddf19c25f2d7adc00097337e6615ccb1.jpg', '1472807421');

-- --------------------------------------------------------

--
-- Table structure for table `homepage`
--

CREATE TABLE `homepage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unid` varchar(33) NOT NULL,
  `section` varchar(33) NOT NULL,
  `subsection` varchar(33) NOT NULL,
  `comment` varchar(33) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `homepage`
--

INSERT INTO `homepage` VALUES(14, '4444', '2', 'testing', 'hjjkbnjk', '1458556894');
INSERT INTO `homepage` VALUES(15, '601', '1', 'development', 'test', '1458722792');
INSERT INTO `homepage` VALUES(13, '4444', '1', 'development', 'jhbjhb', '1458556894');
INSERT INTO `homepage` VALUES(16, '1348', 'test999', 'Subtest9999', 'all nines', '1460710121');
INSERT INTO `homepage` VALUES(17, '1348', 'it', 'testing', 'it_testing', '1460710121');
INSERT INTO `homepage` VALUES(18, '6515', '1', 'development', 'all ones ones', '1460710267');
INSERT INTO `homepage` VALUES(19, '6515', '2', 'testing', 'all twos', '1460710267');

-- --------------------------------------------------------

--
-- Table structure for table `lead`
--

CREATE TABLE `lead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unid` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `lead_tower` varchar(55) NOT NULL,
  `lead_block` varchar(55) NOT NULL,
  `lead_floor` varchar(55) NOT NULL,
  `lead_flattype` varchar(33) NOT NULL,
  `lead_flatno` varchar(33) NOT NULL,
  `source_lead` varchar(33) NOT NULL,
  `name` varchar(33) NOT NULL,
  `mobile` varchar(33) NOT NULL,
  `other_mobile` varchar(33) NOT NULL,
  `email` varchar(33) NOT NULL,
  `other_email` varchar(33) NOT NULL,
  `lead_status` varchar(33) NOT NULL,
  `remarks` varchar(33) NOT NULL,
  `reminder` varchar(10) NOT NULL,
  `organization` varchar(33) NOT NULL,
  `client_address` varchar(33) NOT NULL,
  `city` varchar(33) NOT NULL,
  `broker` varchar(33) NOT NULL,
  `source_description` varchar(33) NOT NULL,
  `assigned_employee` varchar(33) NOT NULL,
  `is_investor` varchar(33) NOT NULL,
  `is_buy_back_investor` varchar(33) NOT NULL,
  `lead_stage` varchar(33) NOT NULL,
  `requirement_type` varchar(33) NOT NULL,
  `preferred_saleable_area` varchar(33) NOT NULL,
  `range` varchar(33) NOT NULL,
  `budget_minimum` varchar(33) NOT NULL,
  `budget_maximum` varchar(33) NOT NULL,
  `preferred_floor` varchar(33) NOT NULL,
  `country` varchar(33) NOT NULL,
  `state` varchar(33) NOT NULL,
  `block_date` varchar(33) NOT NULL,
  `status` varchar(30) NOT NULL,
  `inst_from` varchar(10) NOT NULL,
  `timestamp` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unid` (`unid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `lead`
--


-- --------------------------------------------------------

--
-- Table structure for table `lead_remarks`
--

CREATE TABLE `lead_remarks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unid` varchar(33) NOT NULL,
  `lead_source` varchar(33) NOT NULL,
  `lead_referto` varchar(33) NOT NULL,
  `lead_remarks` longtext NOT NULL,
  `status` varchar(11) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `lead_remarks`
--

INSERT INTO `lead_remarks` VALUES(1, '23fab83588845fba2a640e0ce15165ad', '', '', 'Activity Started', '1', '1473833253');
INSERT INTO `lead_remarks` VALUES(2, '3c6109bd1670b981f5519d93d2f5b301', '', '', 'Activity Started', '1', '1473833556');
INSERT INTO `lead_remarks` VALUES(3, 'eae2ebfb6eca46b725bd54041e12d4ab', '', '', 'Activity Started', '1', '1473833769');
INSERT INTO `lead_remarks` VALUES(4, '5e12cffe09b9d1a2c17ccea5ed60cb11', '', '', 'Activity Started', '1', '1474196587');
INSERT INTO `lead_remarks` VALUES(5, 'cb467a938899ed03b65c78983657ba11', '', '', 'Activity Started', '1', '1474196709');
INSERT INTO `lead_remarks` VALUES(6, 'a4169175ba9f06cc54e11b27816b63d9', '', '', 'Activity Started', '1', '1474198024');

-- --------------------------------------------------------

--
-- Table structure for table `lead_stages`
--

CREATE TABLE `lead_stages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stage` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `lead_stages`
--

INSERT INTO `lead_stages` VALUES(1, 'new');
INSERT INTO `lead_stages` VALUES(2, 'suspect');
INSERT INTO `lead_stages` VALUES(3, 'prospect');
INSERT INTO `lead_stages` VALUES(4, 'negotiation');
INSERT INTO `lead_stages` VALUES(5, 'blocked');
INSERT INTO `lead_stages` VALUES(6, 'saledone');
INSERT INTO `lead_stages` VALUES(7, 'dropped');
INSERT INTO `lead_stages` VALUES(8, 'hot');
INSERT INTO `lead_stages` VALUES(9, 'warm');
INSERT INTO `lead_stages` VALUES(10, 'cold');

-- --------------------------------------------------------

--
-- Table structure for table `lead_update`
--

CREATE TABLE `lead_update` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unid` varchar(33) NOT NULL,
  `username` varchar(50) NOT NULL,
  `remarks` longtext NOT NULL,
  `timestamp` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `lead_update`
--


-- --------------------------------------------------------

--
-- Table structure for table `loanstages`
--

CREATE TABLE `loanstages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_stages` varchar(55) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `loanstages`
--

INSERT INTO `loanstages` VALUES(3, 'MMD &gt; 45', '1465800699');
INSERT INTO `loanstages` VALUES(2, 'MMD &lt; 45', '1465800685');
INSERT INTO `loanstages` VALUES(5, 'CNR &lt; 45', '1465800722');
INSERT INTO `loanstages` VALUES(6, 'CNR &gt; 45', '1465800731');
INSERT INTO `loanstages` VALUES(7, 'Minor docs', '1465800738');
INSERT INTO `loanstages` VALUES(8, 'Logged In', '1465800746');
INSERT INTO `loanstages` VALUES(9, 'Sanctioned', '1465800754');
INSERT INTO `loanstages` VALUES(10, 'Rejected', '1465800762');
INSERT INTO `loanstages` VALUES(11, 'OD &lt; 45', '1465800773');
INSERT INTO `loanstages` VALUES(12, 'OD &gt; 45', '1465800781');
INSERT INTO `loanstages` VALUES(13, 'Others', '1465800788');
INSERT INTO `loanstages` VALUES(14, 'NA', '1465800795');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unid` varchar(33) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` VALUES(1, '9468', '1465214827');
INSERT INTO `notifications` VALUES(2, '53639', '1465214834');

-- --------------------------------------------------------

--
-- Table structure for table `password_log`
--

CREATE TABLE `password_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(33) NOT NULL,
  `ip_address` varchar(33) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  `type` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=523 ;

--
-- Dumping data for table `password_log`
--

INSERT INTO `password_log` VALUES(1, 'admin', '115.112.108.4', '1465383306', 'logout');
INSERT INTO `password_log` VALUES(2, 'admin', '115.112.108.4', '1465383311', 'login');
INSERT INTO `password_log` VALUES(3, 'admin', '115.112.108.4', '1465461952', 'login');
INSERT INTO `password_log` VALUES(4, 'admin', '115.112.108.4', '1465463767', 'login');
INSERT INTO `password_log` VALUES(5, 'admin', '202.53.80.251', '1465467872', 'login');
INSERT INTO `password_log` VALUES(6, 'admin', '202.53.80.251', '1465467872', 'login');
INSERT INTO `password_log` VALUES(7, 'admin', '202.53.80.251', '1465467883', 'login');
INSERT INTO `password_log` VALUES(8, 'admin', '115.112.108.4', '1465541359', 'login');
INSERT INTO `password_log` VALUES(9, 'admin', '115.112.108.4', '1465555677', 'login');
INSERT INTO `password_log` VALUES(10, 'admin', '115.112.108.4', '1465800016', 'login');
INSERT INTO `password_log` VALUES(11, 'admin', '115.112.108.4', '1465802882', 'logout');
INSERT INTO `password_log` VALUES(12, 'admin', '115.112.108.4', '1465803489', 'login');
INSERT INTO `password_log` VALUES(13, 'admin', '115.112.108.4', '1465807176', 'login');
INSERT INTO `password_log` VALUES(14, 'admin', '115.112.108.4', '1465807176', 'login');
INSERT INTO `password_log` VALUES(15, 'admin', '115.112.108.4', '1465811904', 'login');
INSERT INTO `password_log` VALUES(16, 'admin', '115.112.108.4', '1465816156', 'login');
INSERT INTO `password_log` VALUES(17, 'admin', '115.112.108.4', '1465885172', 'login');
INSERT INTO `password_log` VALUES(18, 'admin', '115.112.108.4', '1465885172', 'login');
INSERT INTO `password_log` VALUES(19, 'admin', '115.112.108.4', '1465970448', 'login');
INSERT INTO `password_log` VALUES(20, 'admin', '115.112.108.4', '1465971293', 'logout');
INSERT INTO `password_log` VALUES(21, 'admin', '115.112.108.4', '1465982897', 'login');
INSERT INTO `password_log` VALUES(22, 'admin', '115.112.108.4', '1465982897', 'login');
INSERT INTO `password_log` VALUES(23, 'admin', '115.112.108.4', '1465982904', 'login');
INSERT INTO `password_log` VALUES(24, 'admin', '115.112.108.4', '1465982980', 'logout');
INSERT INTO `password_log` VALUES(25, 'admin', '115.112.108.4', '1465990244', 'login');
INSERT INTO `password_log` VALUES(26, 'admin', '115.112.108.4', '1465990244', 'login');
INSERT INTO `password_log` VALUES(27, 'admin', '115.112.108.4', '1465990592', 'logout');
INSERT INTO `password_log` VALUES(28, 'admin', '115.112.108.4', '1466054984', 'login');
INSERT INTO `password_log` VALUES(29, 'admin', '115.112.108.4', '1466055465', 'login');
INSERT INTO `password_log` VALUES(30, 'admin', '115.112.108.4', '1466058140', 'login');
INSERT INTO `password_log` VALUES(31, 'admin', '115.112.108.4', '1466058389', 'login');
INSERT INTO `password_log` VALUES(32, 'admin', '115.112.108.4', '1466058852', 'login');
INSERT INTO `password_log` VALUES(33, 'admin', '115.112.108.4', '1466058853', 'login');
INSERT INTO `password_log` VALUES(34, 'admin', '115.112.108.4', '1466059216', 'login');
INSERT INTO `password_log` VALUES(35, 'admin', '115.112.108.4', '1466059418', 'login');
INSERT INTO `password_log` VALUES(36, 'admin', '115.112.108.4', '1466059600', 'login');
INSERT INTO `password_log` VALUES(37, 'admin', '115.112.108.4', '1466059702', 'login');
INSERT INTO `password_log` VALUES(38, 'admin', '115.112.108.4', '1466059921', 'login');
INSERT INTO `password_log` VALUES(39, 'admin', '115.112.108.4', '1466060076', 'login');
INSERT INTO `password_log` VALUES(40, 'Guest', '115.112.108.4', '1466060104', 'logout');
INSERT INTO `password_log` VALUES(41, 'admin', '115.112.108.4', '1466068390', 'login');
INSERT INTO `password_log` VALUES(42, 'admin', '115.112.108.4', '1466403334', 'login');
INSERT INTO `password_log` VALUES(43, 'admin', '115.112.108.4', '1466403366', 'logout');
INSERT INTO `password_log` VALUES(44, 'admin', '115.112.108.4', '1466418319', 'login');
INSERT INTO `password_log` VALUES(45, 'admin', '115.112.108.4', '1466418388', 'logout');
INSERT INTO `password_log` VALUES(46, 'admin', '115.112.108.4', '1466419498', 'login');
INSERT INTO `password_log` VALUES(47, 'admin', '202.53.80.251', '1466481664', 'login');
INSERT INTO `password_log` VALUES(48, 'admin', '115.112.108.4', '1466488732', 'login');
INSERT INTO `password_log` VALUES(49, 'admin', '202.53.80.251', '1466488906', 'login');
INSERT INTO `password_log` VALUES(50, 'admin', '115.112.108.4', '1466749420', 'login');
INSERT INTO `password_log` VALUES(51, 'admin', '115.112.108.4', '1467002331', 'login');
INSERT INTO `password_log` VALUES(52, 'admin', '115.112.108.4', '1467002331', 'login');
INSERT INTO `password_log` VALUES(53, 'admin', '115.112.108.4', '1467093431', 'login');
INSERT INTO `password_log` VALUES(54, 'admin', '115.112.108.4', '1467093761', 'logout');
INSERT INTO `password_log` VALUES(55, 'admin', '115.112.108.4', '1467095570', 'login');
INSERT INTO `password_log` VALUES(56, 'admin', '115.112.108.4', '1467103920', 'login');
INSERT INTO `password_log` VALUES(57, 'admin', '115.112.108.4', '1467107734', 'logout');
INSERT INTO `password_log` VALUES(58, 'admin', '115.112.108.4', '1467110788', 'login');
INSERT INTO `password_log` VALUES(59, 'admin', '115.112.108.4', '1467117173', 'logout');
INSERT INTO `password_log` VALUES(60, 'admin', '115.112.108.4', '1467121814', 'login');
INSERT INTO `password_log` VALUES(61, 'admin', '115.112.108.4', '1467122496', 'logout');
INSERT INTO `password_log` VALUES(62, 'admin', '115.112.108.4', '1467122840', 'login');
INSERT INTO `password_log` VALUES(63, 'admin', '115.112.108.4', '1467123190', 'logout');
INSERT INTO `password_log` VALUES(64, 'admin', '115.112.108.4', '1467123198', 'login');
INSERT INTO `password_log` VALUES(65, 'admin', '115.112.108.4', '1467123870', 'logout');
INSERT INTO `password_log` VALUES(66, 'admin', '115.112.108.4', '1467176805', 'login');
INSERT INTO `password_log` VALUES(67, 'admin', '115.112.108.4', '1467179550', 'login');
INSERT INTO `password_log` VALUES(68, 'admin', '115.112.108.4', '1467179550', 'login');
INSERT INTO `password_log` VALUES(69, 'admin', '202.53.80.251', '1467184659', 'login');
INSERT INTO `password_log` VALUES(70, 'Guest', '115.112.108.4', '1467193268', 'logout');
INSERT INTO `password_log` VALUES(71, 'admin', '115.112.108.4', '1467199259', 'login');
INSERT INTO `password_log` VALUES(72, 'admin', '115.112.108.4', '1467199259', 'login');
INSERT INTO `password_log` VALUES(73, 'admin', '115.112.108.4', '1467207319', 'login');
INSERT INTO `password_log` VALUES(74, 'admin', '115.112.108.4', '1467208594', 'logout');
INSERT INTO `password_log` VALUES(75, 'admin', '115.112.108.4', '1467209411', 'login');
INSERT INTO `password_log` VALUES(76, 'admin', '115.112.108.4', '1467209583', 'logout');
INSERT INTO `password_log` VALUES(77, 'admin', '49.204.247.43', '1467257457', 'login');
INSERT INTO `password_log` VALUES(78, 'admin', '49.204.247.43', '1467257611', 'logout');
INSERT INTO `password_log` VALUES(79, 'admin', '115.112.108.4', '1467264037', 'login');
INSERT INTO `password_log` VALUES(80, 'admin', '202.53.80.251', '1467270700', 'login');
INSERT INTO `password_log` VALUES(81, 'admin', '115.112.108.4', '1467270726', 'login');
INSERT INTO `password_log` VALUES(82, 'admin', '202.53.80.251', '1467270831', 'login');
INSERT INTO `password_log` VALUES(83, 'admin', '202.53.80.251', '1467270831', 'login');
INSERT INTO `password_log` VALUES(84, 'admin', '115.112.108.4', '1467270899', 'login');
INSERT INTO `password_log` VALUES(85, 'admin', '115.112.108.4', '1467270899', 'login');
INSERT INTO `password_log` VALUES(86, 'admin', '202.53.80.251', '1467270913', 'login');
INSERT INTO `password_log` VALUES(87, 'admin', '202.53.80.251', '1467270913', 'login');
INSERT INTO `password_log` VALUES(88, 'admin', '115.112.108.4', '1467272014', 'login');
INSERT INTO `password_log` VALUES(89, 'admin', '202.53.80.251', '1467272416', 'login');
INSERT INTO `password_log` VALUES(90, 'admin', '202.53.80.251', '1467272416', 'login');
INSERT INTO `password_log` VALUES(91, 'admin', '115.112.108.4', '1467272574', 'login');
INSERT INTO `password_log` VALUES(92, 'admin', '115.112.108.4', '1467272727', 'login');
INSERT INTO `password_log` VALUES(93, 'admin', '115.112.108.4', '1467272727', 'login');
INSERT INTO `password_log` VALUES(94, 'admin', '115.112.108.4', '1467272727', 'login');
INSERT INTO `password_log` VALUES(95, 'admin', '115.112.108.4', '1467272727', 'login');
INSERT INTO `password_log` VALUES(96, 'admin', '115.112.108.4', '1467272727', 'login');
INSERT INTO `password_log` VALUES(97, 'admin', '115.112.108.4', '1467272727', 'login');
INSERT INTO `password_log` VALUES(98, 'admin', '115.112.108.4', '1467272727', 'login');
INSERT INTO `password_log` VALUES(99, 'admin', '115.112.108.4', '1467272794', 'login');
INSERT INTO `password_log` VALUES(100, 'admin', '115.112.108.4', '1467274085', 'logout');
INSERT INTO `password_log` VALUES(101, 'admin', '115.112.108.4', '1467281457', 'login');
INSERT INTO `password_log` VALUES(102, 'admin', '115.112.108.4', '1467282978', 'logout');
INSERT INTO `password_log` VALUES(103, 'admin', '202.53.80.251', '1467287382', 'login');
INSERT INTO `password_log` VALUES(104, 'admin', '202.53.80.251', '1467287383', 'login');
INSERT INTO `password_log` VALUES(105, 'admin', '115.112.108.4', '1467287586', 'login');
INSERT INTO `password_log` VALUES(106, 'admin', '202.53.80.251', '1467287758', 'login');
INSERT INTO `password_log` VALUES(107, 'zestwings', '115.112.108.4', '1467288167', 'login');
INSERT INTO `password_log` VALUES(108, 'zestwings', '115.112.108.4', '1467289119', 'logout');
INSERT INTO `password_log` VALUES(109, 'admin', '115.112.108.4', '1467349987', 'login');
INSERT INTO `password_log` VALUES(110, 'admin', '115.112.108.4', '1467350074', 'logout');
INSERT INTO `password_log` VALUES(111, 'admin', '202.53.80.251', '1467350720', 'login');
INSERT INTO `password_log` VALUES(112, 'admin', '115.112.108.4', '1467354159', 'login');
INSERT INTO `password_log` VALUES(113, 'admin', '115.112.108.4', '1467354177', 'logout');
INSERT INTO `password_log` VALUES(114, 'admin', '115.112.108.4', '1467354510', 'login');
INSERT INTO `password_log` VALUES(115, 'admin', '202.53.80.251', '1467370567', 'login');
INSERT INTO `password_log` VALUES(116, 'admin', '202.53.80.251', '1467370567', 'login');
INSERT INTO `password_log` VALUES(117, 'admin', '106.51.30.161', '1467783409', 'login');
INSERT INTO `password_log` VALUES(118, 'admin', '106.51.30.161', '1467783434', 'logout');
INSERT INTO `password_log` VALUES(119, 'admin', '202.53.80.251', '1467783734', 'login');
INSERT INTO `password_log` VALUES(120, 'admin', '49.206.227.104', '1467893459', 'login');
INSERT INTO `password_log` VALUES(121, 'admin', '27.6.112.72', '1467954861', 'login');
INSERT INTO `password_log` VALUES(122, 'admin', '115.112.108.4', '1467955056', 'login');
INSERT INTO `password_log` VALUES(123, 'admin', '27.6.112.72', '1467955062', 'login');
INSERT INTO `password_log` VALUES(124, 'admin', '115.112.108.4', '1467955067', 'login');
INSERT INTO `password_log` VALUES(125, 'admin', '27.6.112.72', '1467955082', 'login');
INSERT INTO `password_log` VALUES(126, 'admin', '27.6.112.72', '1467955235', 'logout');
INSERT INTO `password_log` VALUES(127, 'admin', '115.112.108.4', '1467957747', 'login');
INSERT INTO `password_log` VALUES(128, 'admin', '115.112.108.4', '1467959692', 'logout');
INSERT INTO `password_log` VALUES(129, 'admin', '49.204.250.246', '1468165737', 'login');
INSERT INTO `password_log` VALUES(130, 'admin', '49.204.250.246', '1468165775', 'logout');
INSERT INTO `password_log` VALUES(131, 'admin', '115.112.108.4', '1468213278', 'login');
INSERT INTO `password_log` VALUES(132, 'admin', '202.53.80.251', '1468217222', 'login');
INSERT INTO `password_log` VALUES(133, 'admin', '115.112.108.4', '1468219050', 'login');
INSERT INTO `password_log` VALUES(134, 'admin', '202.53.80.251', '1468219075', 'login');
INSERT INTO `password_log` VALUES(135, 'admin', '115.112.108.4', '1468219233', 'login');
INSERT INTO `password_log` VALUES(136, 'admin', '115.112.108.4', '1468219461', 'login');
INSERT INTO `password_log` VALUES(137, 'admin', '49.205.98.91', '1468222749', 'login');
INSERT INTO `password_log` VALUES(138, 'admin', '115.112.108.4', '1468222888', 'login');
INSERT INTO `password_log` VALUES(139, 'admin', '202.53.80.251', '1468234408', 'login');
INSERT INTO `password_log` VALUES(140, 'admin', '115.112.108.4', '1468300094', 'login');
INSERT INTO `password_log` VALUES(141, 'admin', '49.205.98.91', '1468302888', 'login');
INSERT INTO `password_log` VALUES(142, 'admin', '115.112.108.4', '1468303028', 'login');
INSERT INTO `password_log` VALUES(143, 'admin', '49.205.98.91', '1468303137', 'login');
INSERT INTO `password_log` VALUES(144, 'admin', '115.112.108.4', '1468303150', 'login');
INSERT INTO `password_log` VALUES(145, 'admin', '115.112.108.4', '1468303608', 'login');
INSERT INTO `password_log` VALUES(146, 'admin', '115.112.108.4', '1468312586', 'login');
INSERT INTO `password_log` VALUES(147, 'admin', '115.112.108.4', '1468324403', 'login');
INSERT INTO `password_log` VALUES(148, 'admin', '202.53.80.251', '1468386646', 'login');
INSERT INTO `password_log` VALUES(149, 'admin', '115.112.108.4', '1468392361', 'login');
INSERT INTO `password_log` VALUES(150, 'admin', '202.53.80.251', '1468397177', 'login');
INSERT INTO `password_log` VALUES(151, 'admin', '202.53.80.251', '1468397476', 'logout');
INSERT INTO `password_log` VALUES(152, 'admin', '49.205.98.91', '1468471181', 'login');
INSERT INTO `password_log` VALUES(153, 'admin', '49.205.98.91', '1468472004', 'logout');
INSERT INTO `password_log` VALUES(154, 'admin', '1.39.21.33', '1468485144', 'login');
INSERT INTO `password_log` VALUES(155, 'admin', '202.53.80.251', '1468485293', 'login');
INSERT INTO `password_log` VALUES(156, 'admin', '183.82.106.127', '1468668602', 'login');
INSERT INTO `password_log` VALUES(157, 'admin', '115.112.108.4', '1468918191', 'login');
INSERT INTO `password_log` VALUES(158, 'admin', '49.204.247.131', '1468918911', 'login');
INSERT INTO `password_log` VALUES(159, 'zestwings', '115.112.108.4', '1468918939', 'login');
INSERT INTO `password_log` VALUES(160, 'admin', '49.205.76.19', '1468922105', 'login');
INSERT INTO `password_log` VALUES(161, 'admin', '49.205.76.19', '1469189388', 'logout');
INSERT INTO `password_log` VALUES(162, 'admin', '202.53.80.251', '1469437665', 'login');
INSERT INTO `password_log` VALUES(163, 'admin', '202.53.80.251', '1469437665', 'login');
INSERT INTO `password_log` VALUES(164, 'vidhyamurtty', '202.53.80.251', '1469437886', 'login');
INSERT INTO `password_log` VALUES(165, 'vidhyamurtty', '202.53.80.251', '1469438088', 'logout');
INSERT INTO `password_log` VALUES(166, 'admin', '202.53.80.251', '1469438092', 'logout');
INSERT INTO `password_log` VALUES(167, 'vidhyamurtty', '202.53.80.251', '1469438102', 'login');
INSERT INTO `password_log` VALUES(168, 'vidhyamurtty', '202.53.80.251', '1469438154', 'logout');
INSERT INTO `password_log` VALUES(169, 'admin', '202.53.80.251', '1469438165', 'login');
INSERT INTO `password_log` VALUES(170, 'vidhyamurtty', '202.53.80.251', '1469440550', 'login');
INSERT INTO `password_log` VALUES(171, 'vidhyamurtty', '202.53.80.251', '1469446393', 'logout');
INSERT INTO `password_log` VALUES(172, 'chaitanaya', '202.53.80.251', '1469446465', 'login');
INSERT INTO `password_log` VALUES(173, 'chaitanaya', '202.53.80.251', '1469446465', 'login');
INSERT INTO `password_log` VALUES(174, 'chaitanaya', '202.53.80.251', '1469446465', 'login');
INSERT INTO `password_log` VALUES(175, 'chaitanaya', '202.53.80.251', '1469446465', 'login');
INSERT INTO `password_log` VALUES(176, 'chaitanaya', '202.53.80.251', '1469446465', 'login');
INSERT INTO `password_log` VALUES(177, 'chaitanaya', '202.53.80.251', '1469446465', 'login');
INSERT INTO `password_log` VALUES(178, 'chaitanaya', '202.53.80.251', '1469446465', 'login');
INSERT INTO `password_log` VALUES(179, 'chaitanaya', '202.53.80.251', '1469446465', 'login');
INSERT INTO `password_log` VALUES(180, 'chaitanaya', '202.53.80.251', '1469446557', 'logout');
INSERT INTO `password_log` VALUES(181, 'chaitanaya', '202.53.80.251', '1469446730', 'login');
INSERT INTO `password_log` VALUES(182, 'chaitanaya', '202.53.80.251', '1469446731', 'login');
INSERT INTO `password_log` VALUES(183, 'chaitanaya', '202.53.80.251', '1469446771', 'login');
INSERT INTO `password_log` VALUES(184, 'chaitanaya', '202.53.80.251', '1469446771', 'login');
INSERT INTO `password_log` VALUES(185, 'admin', '115.112.108.4', '1469597765', 'login');
INSERT INTO `password_log` VALUES(186, 'admin', '49.205.76.19', '1469701435', 'login');
INSERT INTO `password_log` VALUES(187, 'admin', '49.205.76.19', '1469701436', 'login');
INSERT INTO `password_log` VALUES(188, 'admin', '49.205.76.19', '1469701446', 'login');
INSERT INTO `password_log` VALUES(189, 'admin', '49.205.76.19', '1469701462', 'logout');
INSERT INTO `password_log` VALUES(190, 'vidhyamurtty', '49.205.76.19', '1469701472', 'login');
INSERT INTO `password_log` VALUES(191, 'vidhyamurtty', '49.205.76.19', '1469701551', 'logout');
INSERT INTO `password_log` VALUES(192, 'admin', '115.112.108.4', '1469703893', 'login');
INSERT INTO `password_log` VALUES(193, 'admin', '115.112.108.4', '1469704482', 'logout');
INSERT INTO `password_log` VALUES(194, 'zestwingsits', '115.112.108.4', '1469704486', 'login');
INSERT INTO `password_log` VALUES(195, 'zestwingsits', '115.112.108.4', '1469704597', 'logout');
INSERT INTO `password_log` VALUES(196, 'admin', '115.112.108.4', '1469704640', 'login');
INSERT INTO `password_log` VALUES(197, 'admin', '115.112.108.4', '1469704656', 'logout');
INSERT INTO `password_log` VALUES(198, 'admin', '115.112.108.4', '1469704664', 'login');
INSERT INTO `password_log` VALUES(199, 'admin', '115.112.108.4', '1469704723', 'logout');
INSERT INTO `password_log` VALUES(200, '123@123$', '115.112.108.4', '1469704727', 'login');
INSERT INTO `password_log` VALUES(201, '123@123$', '115.112.108.4', '1469704734', 'logout');
INSERT INTO `password_log` VALUES(202, 'admin', '115.112.108.4', '1469705594', 'login');
INSERT INTO `password_log` VALUES(203, 'admin', '115.112.108.4', '1469707398', 'logout');
INSERT INTO `password_log` VALUES(204, 'admin', '49.205.76.19', '1469786972', 'login');
INSERT INTO `password_log` VALUES(205, 'admin', '115.112.108.4', '1469787768', 'login');
INSERT INTO `password_log` VALUES(206, 'admin', '115.112.108.4', '1469788367', 'logout');
INSERT INTO `password_log` VALUES(207, 'admin', '49.205.76.19', '1469788984', 'login');
INSERT INTO `password_log` VALUES(208, 'admin', '49.204.252.149', '1469980491', 'login');
INSERT INTO `password_log` VALUES(209, 'admin', '49.204.252.149', '1469980491', 'login');
INSERT INTO `password_log` VALUES(210, 'admin', '49.204.252.149', '1469980582', 'logout');
INSERT INTO `password_log` VALUES(211, 'admin', '49.204.252.149', '1469980608', 'login');
INSERT INTO `password_log` VALUES(212, 'admin', '49.204.252.149', '1469980650', 'logout');
INSERT INTO `password_log` VALUES(213, 'admin', '49.204.252.149', '1469980757', 'login');
INSERT INTO `password_log` VALUES(214, 'admin', '49.204.252.149', '1469980757', 'login');
INSERT INTO `password_log` VALUES(215, 'admin', '49.204.252.149', '1469980757', 'login');
INSERT INTO `password_log` VALUES(216, 'admin', '49.204.252.149', '1469980757', 'login');
INSERT INTO `password_log` VALUES(217, 'vidhyamurtty', '103.206.115.137', '1469980841', 'login');
INSERT INTO `password_log` VALUES(218, 'admin', '49.204.252.149', '1469980850', 'logout');
INSERT INTO `password_log` VALUES(219, 'vidhyamurtty', '103.206.115.137', '1469980877', 'logout');
INSERT INTO `password_log` VALUES(220, 'sivakiran.t', '103.206.115.137', '1469980934', 'login');
INSERT INTO `password_log` VALUES(221, 'sivakiran.t', '103.206.115.137', '1469980981', 'logout');
INSERT INTO `password_log` VALUES(222, 'Guest', '49.205.76.19', '1470028099', 'logout');
INSERT INTO `password_log` VALUES(223, 'admin', '49.205.76.19', '1470028115', 'login');
INSERT INTO `password_log` VALUES(224, 'sivakiran.t', '115.112.108.4', '1470029258', 'login');
INSERT INTO `password_log` VALUES(225, 'chaitanaya', '49.205.76.19', '1470029918', 'logout');
INSERT INTO `password_log` VALUES(226, 'sivakiran.t', '49.205.76.19', '1470029926', 'login');
INSERT INTO `password_log` VALUES(227, 'Guest', '115.112.108.4', '1470032308', 'logout');
INSERT INTO `password_log` VALUES(228, 'admin', '49.205.76.19', '1470054739', 'logout');
INSERT INTO `password_log` VALUES(229, 'sivakiran.t', '49.205.76.19', '1470054741', 'logout');
INSERT INTO `password_log` VALUES(230, 'admin', '115.112.108.4', '1470135975', 'login');
INSERT INTO `password_log` VALUES(231, 'admin', '115.112.108.4', '1470137651', 'logout');
INSERT INTO `password_log` VALUES(232, 'admin', '49.205.76.19', '1470199871', 'login');
INSERT INTO `password_log` VALUES(233, 'sivakiran.t', '49.205.76.19', '1470199937', 'login');
INSERT INTO `password_log` VALUES(234, 'admin', '115.112.108.4', '1470201209', 'login');
INSERT INTO `password_log` VALUES(235, 'admin', '115.112.108.4', '1470201418', 'logout');
INSERT INTO `password_log` VALUES(236, 'admin', '49.205.76.19', '1470201482', 'login');
INSERT INTO `password_log` VALUES(237, 'admin', '115.112.108.4', '1470201596', 'login');
INSERT INTO `password_log` VALUES(238, 'admin', '115.112.108.4', '1470202387', 'logout');
INSERT INTO `password_log` VALUES(239, 'admin', '202.53.80.251', '1470213574', 'login');
INSERT INTO `password_log` VALUES(240, 'admin', '49.205.76.19', '1470230731', 'logout');
INSERT INTO `password_log` VALUES(241, 'sivakiran.t', '49.205.76.19', '1470230734', 'logout');
INSERT INTO `password_log` VALUES(242, 'admin', '202.53.80.251', '1470373360', 'login');
INSERT INTO `password_log` VALUES(243, 'admin', '202.53.80.251', '1470373360', 'login');
INSERT INTO `password_log` VALUES(244, 'admin', '202.53.80.251', '1470373493', 'login');
INSERT INTO `password_log` VALUES(245, 'sivakiran.t', '202.53.80.251', '1470374244', 'login');
INSERT INTO `password_log` VALUES(246, 'admin', '49.205.76.19', '1470459681', 'logout');
INSERT INTO `password_log` VALUES(247, 'admin', '49.205.76.19', '1470466492', 'login');
INSERT INTO `password_log` VALUES(248, 'admin', '49.205.76.19', '1470634904', 'logout');
INSERT INTO `password_log` VALUES(249, 'admin', '49.205.76.19', '1470634927', 'login');
INSERT INTO `password_log` VALUES(250, 'admin', '202.53.80.251', '1470637697', 'login');
INSERT INTO `password_log` VALUES(251, 'Guest', '49.205.76.19', '1470651478', 'logout');
INSERT INTO `password_log` VALUES(252, 'admin', '202.53.80.251', '1470652638', 'login');
INSERT INTO `password_log` VALUES(253, 'admin', '202.53.80.251', '1470657102', 'logout');
INSERT INTO `password_log` VALUES(254, 'admin', '49.205.76.19', '1470657356', 'login');
INSERT INTO `password_log` VALUES(255, 'admin', '49.206.235.59', '1470669943', 'login');
INSERT INTO `password_log` VALUES(256, 'admin', '49.206.235.59', '1470669943', 'login');
INSERT INTO `password_log` VALUES(257, 'admin', '49.206.235.59', '1470669948', 'login');
INSERT INTO `password_log` VALUES(258, 'sandeep', '49.206.235.59', '1470673148', 'login');
INSERT INTO `password_log` VALUES(259, 'sandeep', '49.206.235.59', '1470673179', 'logout');
INSERT INTO `password_log` VALUES(260, 'sivakiran.t', '49.206.235.59', '1470673189', 'login');
INSERT INTO `password_log` VALUES(261, 'sivakiran.t', '49.206.235.59', '1470673202', 'logout');
INSERT INTO `password_log` VALUES(262, 'arun', '49.206.235.59', '1470673208', 'login');
INSERT INTO `password_log` VALUES(263, 'arun', '49.206.235.59', '1470673232', 'logout');
INSERT INTO `password_log` VALUES(264, 'vidhyamurtty', '49.206.235.59', '1470673240', 'login');
INSERT INTO `password_log` VALUES(265, 'vidhyamurtty', '49.206.235.59', '1470673282', 'logout');
INSERT INTO `password_log` VALUES(266, 'sekhar', '49.206.235.59', '1470673285', 'login');
INSERT INTO `password_log` VALUES(267, 'sekhar', '49.206.235.59', '1470704512', 'logout');
INSERT INTO `password_log` VALUES(268, 'arun', '49.206.235.59', '1470704517', 'login');
INSERT INTO `password_log` VALUES(269, 'arun', '49.206.235.59', '1470704546', 'logout');
INSERT INTO `password_log` VALUES(270, 'sivakiran.t', '49.206.235.59', '1470704557', 'login');
INSERT INTO `password_log` VALUES(271, 'admin', '49.205.76.19', '1470718700', 'login');
INSERT INTO `password_log` VALUES(272, 'admin', '202.53.80.251', '1470724095', 'login');
INSERT INTO `password_log` VALUES(273, 'sivakiran.t', '49.205.76.19', '1470724110', 'login');
INSERT INTO `password_log` VALUES(274, 'admin', '49.205.76.19', '1470724259', 'login');
INSERT INTO `password_log` VALUES(275, 'admin', '202.53.80.251', '1470724710', 'login');
INSERT INTO `password_log` VALUES(276, 'Guest', '49.205.76.19', '1470726567', 'logout');
INSERT INTO `password_log` VALUES(277, 'admin', '49.205.76.19', '1470726680', 'login');
INSERT INTO `password_log` VALUES(278, 'admin', '49.205.76.19', '1470731600', 'logout');
INSERT INTO `password_log` VALUES(279, 'admin', '49.205.76.19', '1470731629', 'login');
INSERT INTO `password_log` VALUES(280, 'admin', '49.205.76.19', '1470731629', 'login');
INSERT INTO `password_log` VALUES(281, 'sivakiran.t', '49.205.76.19', '1470731647', 'logout');
INSERT INTO `password_log` VALUES(282, 'vidhyamurtty', '49.205.76.19', '1470731663', 'login');
INSERT INTO `password_log` VALUES(283, 'admin', '202.53.80.251', '1470804831', 'login');
INSERT INTO `password_log` VALUES(284, 'admin', '202.53.80.251', '1470806708', 'login');
INSERT INTO `password_log` VALUES(285, 'admin', '49.205.76.19', '1470807079', 'login');
INSERT INTO `password_log` VALUES(286, 'admin', '49.205.76.19', '1470826970', 'logout');
INSERT INTO `password_log` VALUES(287, 'admin', '115.112.108.4', '1470892423', 'login');
INSERT INTO `password_log` VALUES(288, 'admin', '115.112.108.4', '1470892423', 'login');
INSERT INTO `password_log` VALUES(289, 'admin', '115.112.108.4', '1470892423', 'login');
INSERT INTO `password_log` VALUES(290, 'admin', '115.112.108.4', '1470892423', 'login');
INSERT INTO `password_log` VALUES(291, 'admin', '202.53.80.251', '1470897258', 'login');
INSERT INTO `password_log` VALUES(292, 'admin', '202.53.80.251', '1470899948', 'login');
INSERT INTO `password_log` VALUES(293, 'admin', '115.112.108.4', '1470900023', 'login');
INSERT INTO `password_log` VALUES(294, 'admin', '115.112.108.4', '1470900212', 'logout');
INSERT INTO `password_log` VALUES(295, 'vidhyamurtty', '115.112.108.4', '1470900231', 'login');
INSERT INTO `password_log` VALUES(296, 'vidhyamurtty', '115.112.108.4', '1470900546', 'logout');
INSERT INTO `password_log` VALUES(297, 'sivakiran.t', '115.112.108.4', '1470900565', 'login');
INSERT INTO `password_log` VALUES(298, 'sivakiran.t', '115.112.108.4', '1470907351', 'logout');
INSERT INTO `password_log` VALUES(299, 'admin', '115.112.108.4', '1470907360', 'login');
INSERT INTO `password_log` VALUES(300, 'admin', '202.53.80.251', '1470907980', 'login');
INSERT INTO `password_log` VALUES(301, 'arun', '115.112.108.4', '1470908400', 'login');
INSERT INTO `password_log` VALUES(302, 'vidhyamurtty', '115.112.108.4', '1470918988', 'login');
INSERT INTO `password_log` VALUES(303, 'admin', '115.112.108.4', '1470982452', 'login');
INSERT INTO `password_log` VALUES(304, 'admin', '115.112.108.4', '1470987954', 'logout');
INSERT INTO `password_log` VALUES(305, 'admin', '202.53.80.251', '1470997709', 'login');
INSERT INTO `password_log` VALUES(306, 'admin', '202.53.80.251', '1471000579', 'logout');
INSERT INTO `password_log` VALUES(307, 'admin', '202.53.80.251', '1471068308', 'login');
INSERT INTO `password_log` VALUES(308, 'admin', '202.53.80.251', '1471069491', 'logout');
INSERT INTO `password_log` VALUES(309, 'admin', '202.53.80.251', '1471070074', 'login');
INSERT INTO `password_log` VALUES(310, 'admin', '202.53.80.251', '1471071573', 'login');
INSERT INTO `password_log` VALUES(311, 'admin', '202.53.80.251', '1471071895', 'login');
INSERT INTO `password_log` VALUES(312, 'admin', '202.53.80.251', '1471071913', 'login');
INSERT INTO `password_log` VALUES(313, 'admin', '202.53.80.251', '1471072435', 'login');
INSERT INTO `password_log` VALUES(314, 'admin', '202.53.80.251', '1471245213', 'login');
INSERT INTO `password_log` VALUES(315, 'admin', '202.53.80.251', '1471245329', 'login');
INSERT INTO `password_log` VALUES(316, 'admin', '202.53.80.251', '1471245344', 'login');
INSERT INTO `password_log` VALUES(317, 'admin', '202.53.80.251', '1471250668', 'login');
INSERT INTO `password_log` VALUES(318, 'Guest', '202.53.80.251', '1471262630', 'logout');
INSERT INTO `password_log` VALUES(319, 'admin', '183.82.106.127', '1471335252', 'login');
INSERT INTO `password_log` VALUES(320, 'admin', '202.53.80.251', '1471335353', 'login');
INSERT INTO `password_log` VALUES(321, 'admin', '183.82.106.127', '1471335376', 'login');
INSERT INTO `password_log` VALUES(322, 'admin', '202.53.80.251', '1471335428', 'login');
INSERT INTO `password_log` VALUES(323, 'sivakiran.t', '183.82.106.127', '1471335601', 'login');
INSERT INTO `password_log` VALUES(324, 'admin', '202.53.80.251', '1471336579', 'login');
INSERT INTO `password_log` VALUES(325, 'sivakiran.t', '183.82.106.127', '1471337714', 'logout');
INSERT INTO `password_log` VALUES(326, 'admin', '183.82.106.127', '1471337733', 'login');
INSERT INTO `password_log` VALUES(327, 'admin', '183.82.106.127', '1471337733', 'login');
INSERT INTO `password_log` VALUES(328, 'admin', '183.82.106.127', '1471337742', 'login');
INSERT INTO `password_log` VALUES(329, 'admin', '202.53.80.251', '1471337819', 'login');
INSERT INTO `password_log` VALUES(330, 'sivakiran.t', '183.82.106.127', '1471338495', 'login');
INSERT INTO `password_log` VALUES(331, 'admin', '202.53.80.251', '1471338855', 'logout');
INSERT INTO `password_log` VALUES(332, 'saipriya', '202.53.80.251', '1471338859', 'login');
INSERT INTO `password_log` VALUES(333, 'saipriya', '202.53.80.251', '1471338859', 'login');
INSERT INTO `password_log` VALUES(334, 'chaitanaya', '202.53.80.251', '1471339125', 'login');
INSERT INTO `password_log` VALUES(335, 'chaitanaya', '202.53.80.251', '1471339125', 'login');
INSERT INTO `password_log` VALUES(336, 'admin', '115.112.108.4', '1471339198', 'login');
INSERT INTO `password_log` VALUES(337, 'admin', '115.112.108.4', '1471339199', 'login');
INSERT INTO `password_log` VALUES(338, 'admin', '115.112.108.4', '1471339944', 'logout');
INSERT INTO `password_log` VALUES(339, 'sivakiran.t', '202.53.80.251', '1471348430', 'logout');
INSERT INTO `password_log` VALUES(340, 'admin', '202.53.80.251', '1471348455', 'login');
INSERT INTO `password_log` VALUES(341, 'admin', '202.53.80.251', '1471348509', 'logout');
INSERT INTO `password_log` VALUES(342, 'admin', '202.53.80.251', '1471348802', 'login');
INSERT INTO `password_log` VALUES(343, 'admin', '115.112.108.4', '1471349382', 'login');
INSERT INTO `password_log` VALUES(344, 'admin', '115.112.108.4', '1471349447', 'logout');
INSERT INTO `password_log` VALUES(345, 'admin', '202.53.80.251', '1471349462', 'login');
INSERT INTO `password_log` VALUES(346, 'admin', '115.112.108.4', '1471349494', 'login');
INSERT INTO `password_log` VALUES(347, 'admin', '115.112.108.4', '1471349577', 'logout');
INSERT INTO `password_log` VALUES(348, 'chaitanaya', '202.53.80.251', '1471353394', 'logout');
INSERT INTO `password_log` VALUES(349, 'admin', '115.112.108.4', '1471513877', 'login');
INSERT INTO `password_log` VALUES(350, 'admin', '115.112.108.4', '1471516477', 'logout');
INSERT INTO `password_log` VALUES(351, 'vidhyamurtty', '115.112.108.4', '1471516496', 'login');
INSERT INTO `password_log` VALUES(352, 'vidhyamurtty', '115.112.108.4', '1471517812', 'logout');
INSERT INTO `password_log` VALUES(353, 'admin', '49.205.76.19', '1471585937', 'login');
INSERT INTO `password_log` VALUES(354, 'admin', '49.205.76.19', '1471586188', 'logout');
INSERT INTO `password_log` VALUES(355, 'admin', '49.205.76.19', '1471586217', 'login');
INSERT INTO `password_log` VALUES(356, 'admin', '49.205.76.19', '1471586217', 'login');
INSERT INTO `password_log` VALUES(357, 'admin', '49.205.76.19', '1471586233', 'login');
INSERT INTO `password_log` VALUES(358, 'vidhyamurtty', '49.205.76.19', '1471586311', 'login');
INSERT INTO `password_log` VALUES(359, 'vidhyamurtty', '49.205.76.19', '1471586311', 'login');
INSERT INTO `password_log` VALUES(360, 'admin', '49.205.76.19', '1471588604', 'logout');
INSERT INTO `password_log` VALUES(361, 'admin', '202.53.80.251', '1471844365', 'login');
INSERT INTO `password_log` VALUES(362, 'admin', '202.53.80.251', '1471844365', 'login');
INSERT INTO `password_log` VALUES(363, 'admin', '202.53.80.251', '1471844376', 'login');
INSERT INTO `password_log` VALUES(364, 'admin', '202.53.80.251', '1471854650', 'logout');
INSERT INTO `password_log` VALUES(365, 'vidhyamurthy', '202.53.80.251', '1471854663', 'login');
INSERT INTO `password_log` VALUES(366, 'vidhyamurthy', '202.53.80.251', '1471858097', 'logout');
INSERT INTO `password_log` VALUES(367, 'sivakiran.t', '202.53.80.251', '1471858110', 'login');
INSERT INTO `password_log` VALUES(368, 'admin', '115.112.108.4', '1471858110', 'login');
INSERT INTO `password_log` VALUES(369, 'sivakiran.t', '202.53.80.251', '1471858201', 'logout');
INSERT INTO `password_log` VALUES(370, 'admin', '202.53.80.251', '1471858209', 'login');
INSERT INTO `password_log` VALUES(371, 'vidhyamurtty', '202.53.80.251', '1471864498', 'logout');
INSERT INTO `password_log` VALUES(372, 'sivakiran.t', '202.53.80.251', '1471864509', 'login');
INSERT INTO `password_log` VALUES(373, 'sivakiran.t', '202.53.80.251', '1471864713', 'logout');
INSERT INTO `password_log` VALUES(374, 'chaitanaya', '202.53.80.251', '1471864736', 'login');
INSERT INTO `password_log` VALUES(375, 'chaitanaya', '202.53.80.251', '1471864903', 'logout');
INSERT INTO `password_log` VALUES(376, 'chaitanya', '202.53.80.251', '1471864924', 'login');
INSERT INTO `password_log` VALUES(377, 'chaitanya', '202.53.80.251', '1471864924', 'login');
INSERT INTO `password_log` VALUES(378, 'admin', '202.53.80.251', '1471866162', 'logout');
INSERT INTO `password_log` VALUES(379, 'admin', '49.205.76.19', '1471939793', 'login');
INSERT INTO `password_log` VALUES(380, 'chaitanya', '202.53.80.251', '1471950027', 'login');
INSERT INTO `password_log` VALUES(381, 'saipriya', '202.53.80.251', '1471951591', 'logout');
INSERT INTO `password_log` VALUES(382, 'admin', '202.53.80.251', '1471951608', 'login');
INSERT INTO `password_log` VALUES(383, 'admin', '202.53.80.251', '1471951945', 'logout');
INSERT INTO `password_log` VALUES(384, 'saipriya', '202.53.80.251', '1471951955', 'login');
INSERT INTO `password_log` VALUES(385, 'sivakiran.t', '49.205.76.19', '1471951969', 'login');
INSERT INTO `password_log` VALUES(386, 'admin', '49.205.76.19', '1471952228', 'login');
INSERT INTO `password_log` VALUES(387, 'saipriya', '202.53.80.251', '1471952723', 'logout');
INSERT INTO `password_log` VALUES(388, 'admin', '202.53.80.251', '1471952734', 'login');
INSERT INTO `password_log` VALUES(389, 'admin', '202.53.80.251', '1471952787', 'logout');
INSERT INTO `password_log` VALUES(390, 'saipriya', '202.53.80.251', '1471952796', 'login');
INSERT INTO `password_log` VALUES(391, 'saipriya', '202.53.80.251', '1471953519', 'logout');
INSERT INTO `password_log` VALUES(392, 'admin', '202.53.80.251', '1471953527', 'login');
INSERT INTO `password_log` VALUES(393, 'admin', '49.205.76.19', '1471955165', 'login');
INSERT INTO `password_log` VALUES(394, 'admin', '49.205.76.19', '1471955869', 'logout');
INSERT INTO `password_log` VALUES(395, 'chaitanya', '202.53.80.251', '1471958439', 'logout');
INSERT INTO `password_log` VALUES(396, 'admin', '49.205.76.19', '1472015724', 'login');
INSERT INTO `password_log` VALUES(397, 'admin', '49.205.76.19', '1472190014', 'logout');
INSERT INTO `password_log` VALUES(398, 'admin', '202.53.80.251', '1472196683', 'login');
INSERT INTO `password_log` VALUES(399, 'chaitanya', '202.53.80.251', '1472196757', 'login');
INSERT INTO `password_log` VALUES(400, 'chaitanya', '202.53.80.251', '1472215061', 'logout');
INSERT INTO `password_log` VALUES(401, 'chaitanya', '202.53.80.251', '1472634383', 'login');
INSERT INTO `password_log` VALUES(402, 'chaitanya', '202.53.80.251', '1472650929', 'logout');
INSERT INTO `password_log` VALUES(403, 'admin', '202.53.80.251', '1472708542', 'logout');
INSERT INTO `password_log` VALUES(404, 'saipriya', '202.53.80.251', '1472708557', 'login');
INSERT INTO `password_log` VALUES(405, 'chaitanya', '202.53.80.251', '1472708919', 'login');
INSERT INTO `password_log` VALUES(406, 'sivakiran.t', '49.205.76.19', '1472798355', 'login');
INSERT INTO `password_log` VALUES(407, 'chaitanya', '202.53.80.251', '1472798386', 'logout');
INSERT INTO `password_log` VALUES(408, 'admin', '202.53.80.251', '1472798410', 'login');
INSERT INTO `password_log` VALUES(409, 'admin', '202.53.80.251', '1472798410', 'login');
INSERT INTO `password_log` VALUES(410, 'sivakiran.t', '49.205.76.19', '1472798436', 'logout');
INSERT INTO `password_log` VALUES(411, 'chaitanya', '49.205.76.19', '1472798445', 'login');
INSERT INTO `password_log` VALUES(412, 'chaitanya', '49.205.76.19', '1472798537', 'logout');
INSERT INTO `password_log` VALUES(413, 'admin', '49.205.76.19', '1472807307', 'login');
INSERT INTO `password_log` VALUES(414, 'admin', '49.205.76.19', '1472807307', 'login');
INSERT INTO `password_log` VALUES(415, 'admin', '49.205.76.19', '1472807307', 'login');
INSERT INTO `password_log` VALUES(416, 'admin', '49.205.76.19', '1472807307', 'login');
INSERT INTO `password_log` VALUES(417, 'admin', '49.205.76.19', '1472807307', 'login');
INSERT INTO `password_log` VALUES(418, 'admin', '49.205.76.19', '1472807307', 'login');
INSERT INTO `password_log` VALUES(419, 'admin', '49.205.76.19', '1472807307', 'login');
INSERT INTO `password_log` VALUES(420, 'admin', '49.205.76.19', '1472807307', 'login');
INSERT INTO `password_log` VALUES(421, 'admin', '49.205.76.19', '1472807317', 'login');
INSERT INTO `password_log` VALUES(422, 'admin', '49.205.76.19', '1472887564', 'logout');
INSERT INTO `password_log` VALUES(423, 'arun', '115.112.108.4', '1473144905', 'logout');
INSERT INTO `password_log` VALUES(424, 'chaitanya', '115.112.108.4', '1473144910', 'login');
INSERT INTO `password_log` VALUES(425, 'chaitanya', '115.112.108.4', '1473146904', 'logout');
INSERT INTO `password_log` VALUES(426, 'arun', '115.112.108.4', '1473146921', 'login');
INSERT INTO `password_log` VALUES(427, 'arun', '115.112.108.4', '1473147389', 'logout');
INSERT INTO `password_log` VALUES(428, 'chaitanya', '115.112.108.4', '1473147402', 'login');
INSERT INTO `password_log` VALUES(429, 'chaitanya', '115.112.108.4', '1473147699', 'logout');
INSERT INTO `password_log` VALUES(430, 'arun', '115.112.108.4', '1473147708', 'login');
INSERT INTO `password_log` VALUES(431, 'chaitanya', '49.205.76.19', '1473227271', 'login');
INSERT INTO `password_log` VALUES(432, 'chaitanya', '49.205.76.19', '1473227304', 'logout');
INSERT INTO `password_log` VALUES(433, 'saipriya', '202.53.80.251', '1473663433', 'logout');
INSERT INTO `password_log` VALUES(434, 'admin', '202.53.80.251', '1473663445', 'login');
INSERT INTO `password_log` VALUES(435, 'admin', '202.53.80.251', '1473664117', 'login');
INSERT INTO `password_log` VALUES(436, 'saipriya', '202.53.80.251', '1473664337', 'login');
INSERT INTO `password_log` VALUES(437, 'saipriya', '202.53.80.251', '1473664337', 'login');
INSERT INTO `password_log` VALUES(438, 'saipriya', '202.53.80.251', '1473664338', 'login');
INSERT INTO `password_log` VALUES(439, 'admin', '49.205.76.19', '1473668918', 'login');
INSERT INTO `password_log` VALUES(440, 'admin', '202.53.80.251', '1473670043', 'login');
INSERT INTO `password_log` VALUES(441, 'admin', '202.53.80.251', '1473670043', 'login');
INSERT INTO `password_log` VALUES(442, 'admin', '202.53.80.251', '1473670166', 'logout');
INSERT INTO `password_log` VALUES(443, 'admin', '49.205.76.19', '1473671108', 'login');
INSERT INTO `password_log` VALUES(444, 'admin', '202.53.80.251', '1473671490', 'login');
INSERT INTO `password_log` VALUES(445, 'Guest', '49.205.76.19', '1473671689', 'logout');
INSERT INTO `password_log` VALUES(446, 'admin', '49.205.76.19', '1473671709', 'login');
INSERT INTO `password_log` VALUES(447, 'admin', '49.205.76.19', '1473671709', 'login');
INSERT INTO `password_log` VALUES(448, 'admin', '49.205.76.19', '1473671725', 'login');
INSERT INTO `password_log` VALUES(449, 'admin', '49.205.76.19', '1473671726', 'login');
INSERT INTO `password_log` VALUES(450, 'admin', '49.205.76.19', '1473671745', 'login');
INSERT INTO `password_log` VALUES(451, 'admin', '49.205.76.19', '1473673351', 'logout');
INSERT INTO `password_log` VALUES(452, 'chaitanya', '202.53.80.251', '1473674717', 'login');
INSERT INTO `password_log` VALUES(453, 'chaitanya', '202.53.80.251', '1473674845', 'logout');
INSERT INTO `password_log` VALUES(454, 'admin', '202.53.80.251', '1473674875', 'login');
INSERT INTO `password_log` VALUES(455, 'admin', '202.53.80.251', '1473674875', 'login');
INSERT INTO `password_log` VALUES(456, 'admin', '202.53.80.251', '1473675462', 'logout');
INSERT INTO `password_log` VALUES(457, 'saipriya', '202.53.80.251', '1473682893', 'logout');
INSERT INTO `password_log` VALUES(458, 'saipriya', '202.53.80.251', '1473683739', 'login');
INSERT INTO `password_log` VALUES(459, 'saipriya', '202.53.80.251', '1473683758', 'logout');
INSERT INTO `password_log` VALUES(460, 'admin', '202.53.80.251', '1473753542', 'login');
INSERT INTO `password_log` VALUES(461, 'admin', '202.53.80.251', '1473753542', 'login');
INSERT INTO `password_log` VALUES(462, 'admin', '202.53.80.251', '1473753542', 'login');
INSERT INTO `password_log` VALUES(463, 'admin', '202.53.80.251', '1473753542', 'login');
INSERT INTO `password_log` VALUES(464, 'admin', '202.53.80.251', '1473753542', 'login');
INSERT INTO `password_log` VALUES(465, 'admin', '202.53.80.251', '1473753542', 'login');
INSERT INTO `password_log` VALUES(466, 'admin', '202.53.80.251', '1473753542', 'login');
INSERT INTO `password_log` VALUES(467, 'chaitanya', '202.53.80.251', '1473832978', 'login');
INSERT INTO `password_log` VALUES(468, 'chaitanya', '202.53.80.251', '1473832978', 'login');
INSERT INTO `password_log` VALUES(469, 'chaitanya', '202.53.80.251', '1473834993', 'logout');
INSERT INTO `password_log` VALUES(470, 'admin', '202.53.80.251', '1473835004', 'login');
INSERT INTO `password_log` VALUES(471, 'admin', '202.53.80.251', '1473835051', 'login');
INSERT INTO `password_log` VALUES(472, 'admin', '202.53.80.251', '1473835353', 'login');
INSERT INTO `password_log` VALUES(473, 'admin', '202.53.80.251', '1473837627', 'login');
INSERT INTO `password_log` VALUES(474, 'admin', '202.53.80.251', '1474004035', 'login');
INSERT INTO `password_log` VALUES(475, 'admin', '202.53.80.251', '1474004161', 'logout');
INSERT INTO `password_log` VALUES(476, 'chaitanya', '202.53.80.251', '1474196449', 'login');
INSERT INTO `password_log` VALUES(477, 'chaitanya', '202.53.80.251', '1474198033', 'logout');
INSERT INTO `password_log` VALUES(478, 'admin', '183.82.69.63', '1474529839', 'login');
INSERT INTO `password_log` VALUES(479, 'antony', '103.219.247.238', '1474536601', 'login');
INSERT INTO `password_log` VALUES(480, 'admin', '183.82.69.63', '1474539132', 'logout');
INSERT INTO `password_log` VALUES(481, 'vinod', '103.219.247.238', '1474609285', 'login');
INSERT INTO `password_log` VALUES(482, 'admin', '202.53.80.251', '1474719601', 'login');
INSERT INTO `password_log` VALUES(483, 'admin', '202.53.80.251', '1474719821', 'logout');
INSERT INTO `password_log` VALUES(484, 'admin', '202.53.80.251', '1474721863', 'login');
INSERT INTO `password_log` VALUES(485, 'admin', '202.53.80.251', '1474721930', 'logout');
INSERT INTO `password_log` VALUES(486, 'admin', '202.53.80.251', '1474872552', 'login');
INSERT INTO `password_log` VALUES(487, 'admin', '202.53.80.251', '1474953773', 'login');
INSERT INTO `password_log` VALUES(488, 'admin', '202.53.80.251', '1474953997', 'login');
INSERT INTO `password_log` VALUES(489, 'Guest', '202.53.80.251', '1474954031', 'logout');
INSERT INTO `password_log` VALUES(490, 'admin', '202.53.80.251', '1474954405', 'login');
INSERT INTO `password_log` VALUES(491, 'admin', '202.53.80.251', '1474954622', 'logout');
INSERT INTO `password_log` VALUES(492, 'admin', '127.0.0.1', '1475060806', 'login');
INSERT INTO `password_log` VALUES(493, 'admin', '115.112.108.4', '1475141134', 'login');
INSERT INTO `password_log` VALUES(494, 'admin', '115.112.108.4', '1475141134', 'login');
INSERT INTO `password_log` VALUES(495, 'admin', '115.112.108.4', '1475141134', 'login');
INSERT INTO `password_log` VALUES(496, 'admin', '115.112.108.4', '1475141134', 'login');
INSERT INTO `password_log` VALUES(497, 'admin', '115.112.108.4', '1475141134', 'login');
INSERT INTO `password_log` VALUES(498, 'admin', '115.112.108.4', '1475141134', 'login');
INSERT INTO `password_log` VALUES(499, 'admin', '115.112.108.4', '1475141134', 'login');
INSERT INTO `password_log` VALUES(500, 'admin', '115.112.108.4', '1475141143', 'login');
INSERT INTO `password_log` VALUES(501, 'admin', '115.112.108.4', '1475141287', 'logout');
INSERT INTO `password_log` VALUES(502, 'admin', '115.112.108.4', '1475471900', 'login');
INSERT INTO `password_log` VALUES(503, 'admin', '115.112.108.4', '1475472790', 'login');
INSERT INTO `password_log` VALUES(504, 'admin', '115.112.108.4', '1475567173', 'login');
INSERT INTO `password_log` VALUES(505, 'admin', '115.112.108.4', '1475567905', 'login');
INSERT INTO `password_log` VALUES(506, 'admin', '115.112.108.4', '1475570149', 'login');
INSERT INTO `password_log` VALUES(507, 'admin', '115.112.108.4', '1476879416', 'login');
INSERT INTO `password_log` VALUES(508, 'admin', '115.112.108.4', '1476879738', 'logout');
INSERT INTO `password_log` VALUES(509, 'admin', '115.112.108.4', '1477372648', 'login');
INSERT INTO `password_log` VALUES(510, 'admin', '115.112.108.4', '1477373725', 'logout');
INSERT INTO `password_log` VALUES(511, 'arun', '49.206.238.230', '1484652037', 'login');
INSERT INTO `password_log` VALUES(512, 'arun', '49.206.238.230', '1484652037', 'login');
INSERT INTO `password_log` VALUES(513, 'arun', '49.206.238.230', '1484652037', 'login');
INSERT INTO `password_log` VALUES(514, 'arun', '49.206.238.230', '1484652037', 'login');
INSERT INTO `password_log` VALUES(515, 'arun', '49.206.238.230', '1484652037', 'login');
INSERT INTO `password_log` VALUES(516, 'arun', '49.206.238.230', '1484652037', 'login');
INSERT INTO `password_log` VALUES(517, 'arun', '49.206.238.230', '1484652038', 'login');
INSERT INTO `password_log` VALUES(518, 'arun', '49.206.238.230', '1484652038', 'login');
INSERT INTO `password_log` VALUES(519, 'arun', '49.206.238.230', '1484652038', 'login');
INSERT INTO `password_log` VALUES(520, 'arun', '49.206.238.230', '1484652038', 'login');
INSERT INTO `password_log` VALUES(521, 'arun', '49.206.238.230', '1484652038', 'login');
INSERT INTO `password_log` VALUES(522, 'arun', '49.206.238.230', '1484652049', 'login');

-- --------------------------------------------------------

--
-- Table structure for table `pricing`
--

CREATE TABLE `pricing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appt_tower` varchar(22) NOT NULL,
  `block` varchar(22) NOT NULL,
  `sft_price` varchar(33) NOT NULL,
  `revised_sft` varchar(12) NOT NULL,
  `basecost` varchar(12) NOT NULL,
  `deposits` varchar(12) NOT NULL,
  `dg` varchar(12) NOT NULL,
  `documentation_charge` varchar(12) NOT NULL,
  `car_parking` varchar(12) NOT NULL,
  `club_house_deve_charges` varchar(12) NOT NULL,
  `other_tax` varchar(12) NOT NULL,
  `servicetax_base` varchar(12) NOT NULL,
  `sumoftax` varchar(12) NOT NULL,
  `flatcost` varchar(12) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `pricing`
--

INSERT INTO `pricing` VALUES(8, '2', '1', '9750', '4330', '42217500', '324750', '433000', '30000', '1500000', '500000', '162698', '1899787.5', '2062485.5', '47067735.5', '1468471803');
INSERT INTO `pricing` VALUES(6, '2', '1', '9750', '4897', '47745750', '367275', '489700', '30000', '1500000', '500000', '171628', '2148558.75', '2320186.75', '52952911.75', '1468471466');
INSERT INTO `pricing` VALUES(7, '3', '1', '9750', '4725', '46068750', '354375', '472500', '30000', '1500000', '500000', '168919', '2073093.75', '2242012.75', '51167637.75', '1468471504');
INSERT INTO `pricing` VALUES(5, '1', '1', '9750', '6643', '64769250', '498225', '664300', '30000', '2000000', '500000', '221628', '2914616.25', '3136244.25', '71598019.25', '1468471376');
INSERT INTO `pricing` VALUES(9, '2', '1', '9750', '3537', '34485750', '265275', '353700', '30000', '1500000', '500000', '150208', '1551858.75', '1702066.75', '38836791.75', '1468471830');
INSERT INTO `pricing` VALUES(10, '2', '1', '9750', '3798', '37030500', '284850', '379800', '30000', '1500000', '500000', '154319', '1666372.5', '1820691.5', '41545841.5', '1468471852');
INSERT INTO `pricing` VALUES(11, '2', '1', '9750', '5624', '54834000', '421800', '562400', '30000', '1500000', '500000', '183078', '2467530', '2650608', '60498808', '1468471878');
INSERT INTO `pricing` VALUES(12, '3', '1', '9750', '5190', '50602500', '389250', '519000', '30000', '1500000', '500000', '176243', '2277112.5', '2453355.5', '55994105.5', '1468471925');
INSERT INTO `pricing` VALUES(13, '1', '1', '9750', '7575', '73856250', '568125', '757500', '30000', '2000000', '500000', '236307', '3323531.25', '3559838.25', '81271713.25', '1468668691');

-- --------------------------------------------------------

--
-- Table structure for table `quatation`
--

CREATE TABLE `quatation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `q_title` varchar(55) NOT NULL,
  `photo` longtext NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `quatation`
--

INSERT INTO `quatation` VALUES(2, 'Halcyon Quote', '6000f4032f69a6be8913690aadff3fc2.pdf', '1465543147');

-- --------------------------------------------------------

--
-- Table structure for table `reminder`
--

CREATE TABLE `reminder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_unid` varchar(33) NOT NULL,
  `assigned_user` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `timestamp` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `reminder`
--


-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section` varchar(33) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `section`
--

INSERT INTO `section` VALUES(1, '1', '1458537468');
INSERT INTO `section` VALUES(2, '2', '1458545608');
INSERT INTO `section` VALUES(3, 'it', '1458546010');
INSERT INTO `section` VALUES(4, 'it', '1458553237');
INSERT INTO `section` VALUES(5, 'test9999', '1460710061');

-- --------------------------------------------------------

--
-- Table structure for table `servicetax`
--

CREATE TABLE `servicetax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` varchar(33) NOT NULL,
  `servicetax` varchar(33) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `servicetax`
--

INSERT INTO `servicetax` VALUES(3, '2016- Maintenance ST', '15', '1466751278');
INSERT INTO `servicetax` VALUES(2, '2016- Construction tax', '4.5', '1463568785');

-- --------------------------------------------------------

--
-- Table structure for table `sms_mails`
--

CREATE TABLE `sms_mails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unid` varchar(15) NOT NULL,
  `name` varchar(33) NOT NULL,
  `mobile` varchar(14) NOT NULL,
  `email` varchar(33) NOT NULL,
  `timestamp` varchar(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `sms_mails`
--

INSERT INTO `sms_mails` VALUES(1, '1', 'Ravi Chandra', '8125736031', 'ravi28990@gmail.com', '1467207586');
INSERT INTO `sms_mails` VALUES(2, '1', 'Swachan Reddy', '8125736031', 'ravi28990@gmail.com', '1467208168');
INSERT INTO `sms_mails` VALUES(3, '1', 'Ravi', '8125736031', 'ravi28990@gmail.com', '1467208292');
INSERT INTO `sms_mails` VALUES(4, '1', 'Santosh', '8121593979', 'ravi28990@gmail.com', '1467208525');
INSERT INTO `sms_mails` VALUES(5, '1', 'Ravi', '8125736031', 'ravi28990@gmail.com', '1467209444');
INSERT INTO `sms_mails` VALUES(6, '5', 'siva', '8886478800', 'sivakiran.t@phoenixindia.net', '1469080849');
INSERT INTO `sms_mails` VALUES(7, '5', 'siva', '8886478800', 'sivakiran.t@phoenixindia.net', '1469080853');
INSERT INTO `sms_mails` VALUES(8, '5', 'test', '9898787878', 'rajeev@zestwings.com', '1469081179');
INSERT INTO `sms_mails` VALUES(9, '5', 'test', '9898787878', 'rajeev@zestwings.com', '1474118893');

-- --------------------------------------------------------

--
-- Table structure for table `subsection`
--

CREATE TABLE `subsection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section` varchar(33) NOT NULL,
  `subsection` varchar(33) NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `subsection`
--

INSERT INTO `subsection` VALUES(15, 'it', 'development', '1458553263');
INSERT INTO `subsection` VALUES(14, 'it', 'testing', '1458553253');
INSERT INTO `subsection` VALUES(16, 'test999', 'Subtest9999', '1460710078');

-- --------------------------------------------------------

--
-- Table structure for table `update_customers`
--

CREATE TABLE `update_customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unid` varchar(33) NOT NULL,
  `construction_stage` varchar(33) NOT NULL,
  `amount_paid` varchar(33) NOT NULL,
  `update_remarks` longtext NOT NULL,
  `timestamp` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=74 ;

--
-- Dumping data for table `update_customers`
--

INSERT INTO `update_customers` VALUES(17, 'f5282d83581ae23202ea38', '13', '9710550.9', '', '1470806405');
INSERT INTO `update_customers` VALUES(2, '976e335e9eb9b4c5ba907f71ac088d38', '13', '', '', '1465468358');
INSERT INTO `update_customers` VALUES(3, '8bd314b69dcb6c886c9cd72f5308a589', '13', '', '', '1467271762');
INSERT INTO `update_customers` VALUES(4, '', '13', '9710551', '', '1467272482');
INSERT INTO `update_customers` VALUES(5, '80cf44beaaa8118c0554c846dddd70e5', '1', '', '', '1467273420');
INSERT INTO `update_customers` VALUES(6, '935b9e6e2bc40419e37c8586c38d3e77', '13', '', '', '1467287607');
INSERT INTO `update_customers` VALUES(8, '', '13', '', '', '1467287795');
INSERT INTO `update_customers` VALUES(15, 'f5282d83581ae23202ea386e8e70b632', '', '', '', '1470806333');
INSERT INTO `update_customers` VALUES(16, 'f5282d83581ae23202ea38', '13', '9710550.9', '', '1470806374');
INSERT INTO `update_customers` VALUES(11, 'b509384d96cabf3c6c8754f688c39d5e', '', '', '', '1469440434');
INSERT INTO `update_customers` VALUES(12, '434cb25fac2cef5dc3b0d089d4a18b33', '', '', '', '1469787223');
INSERT INTO `update_customers` VALUES(13, '21b298510c35bc79e22d0c14782eb098', '', '', '', '1469787972');
INSERT INTO `update_customers` VALUES(14, '45756a19a2d871a646c2c72d8c498bba', '', '', '', '1469789233');
INSERT INTO `update_customers` VALUES(18, '52bbb4b0b4c193f641ba639460ef3204', '', '', '', '1470998906');
INSERT INTO `update_customers` VALUES(19, '93c74748a961c8caa2ac0e7a532bd6a3', '', '', '', '1470999292');
INSERT INTO `update_customers` VALUES(20, '48ab39170eaaa03dbead07276fd5f19c', '', '', '', '1470999603');
INSERT INTO `update_customers` VALUES(21, '680338cde43b800077bf39dbe0ba2f61', '', '', '', '1470999827');
INSERT INTO `update_customers` VALUES(22, 'ee79cb2645c50166ee495f30b981da2c', '', '', '', '1471000193');
INSERT INTO `update_customers` VALUES(23, '28aebb9c9c5cdf2553d68ac585351126', '', '', '', '1471000474');
INSERT INTO `update_customers` VALUES(24, 'c62b8beca9dc33948f7ef7f7ebe7e5f3', '', '', '', '1471068635');
INSERT INTO `update_customers` VALUES(25, '7c0282b98cb47b1fc6ab0137ba7a7389', '', '', '', '1471070789');
INSERT INTO `update_customers` VALUES(30, '93c74748a961c8caa2ac0e', '22', '16893548.6', '', '1471337059');
INSERT INTO `update_customers` VALUES(29, '3d2e33be85d01048a58ff1624b2d8036', '', '', '', '1471243645');
INSERT INTO `update_customers` VALUES(28, '67a8160b16e647450012aacf5f621734', '', '', '', '1471243278');
INSERT INTO `update_customers` VALUES(31, 'c62b8beca9dc33948f7ef7', '13', '9073200.9', '', '1471337262');
INSERT INTO `update_customers` VALUES(32, '28aebb9c9c5cdf2553d68a', '13', '12423501.9', '', '1471337319');
INSERT INTO `update_customers` VALUES(33, 'ccd6e3b57e2a76987b7bd95ba6fcade7', '', '', '', '1471337771');
INSERT INTO `update_customers` VALUES(34, 'ccd6e3b57e2a76987b7bd9', '1', '2952342.15', '', '1471337889');
INSERT INTO `update_customers` VALUES(35, 'ccd6e3b57e2a76987b7bd9', '1', '2952342.15', '', '1471337891');
INSERT INTO `update_customers` VALUES(36, 'ccd6e3b57e2a76987b7bd9', '1', '2952342.15', '', '1471337892');
INSERT INTO `update_customers` VALUES(37, 'ccd6e3b57e2a76987b7bd9', '1', '2952342.15', '', '1471339531');
INSERT INTO `update_customers` VALUES(38, 'b10179cd0ae63e79d6fc32b0c67576de', '', '', '', '1471589058');
INSERT INTO `update_customers` VALUES(39, '0827213cd50f5b1bf57885abc4e8b6d5', '', '', '', '1471589173');
INSERT INTO `update_customers` VALUES(40, '181f66b31b5eb4a6233eafa23e62ca33', '', '', '', '1471589279');
INSERT INTO `update_customers` VALUES(41, '7f7cd8bdfd2db9e5e8e8ae5bff71ae49', '', '', '', '1471589411');
INSERT INTO `update_customers` VALUES(42, '036814357b90bc4a4fa44de83844af31', '', '', '', '1471599396');
INSERT INTO `update_customers` VALUES(43, '633494cda3627433f16988a2fe1a2fb7', '', '', '', '1471599631');
INSERT INTO `update_customers` VALUES(44, '61dc67d9135000bccc5d797fbdb777a0', '', '', '', '1471599722');
INSERT INTO `update_customers` VALUES(45, 'c9e19b1ddbe559062d50885e353daef0', '', '', '', '1471599788');
INSERT INTO `update_customers` VALUES(46, '4f6ddee0cc4592b6d645968f817a1476', '', '', '', '1471599907');
INSERT INTO `update_customers` VALUES(47, 'fab30e3dcc0a09175735fa4c45ea394d', '', '', '', '1471600011');
INSERT INTO `update_customers` VALUES(48, '840266d1526870a67bd837e4a267d9d6', '', '', '', '1471600135');
INSERT INTO `update_customers` VALUES(49, 'b48dfad77befd6b5a3307733aa6d1686', '', '', '', '1471601159');
INSERT INTO `update_customers` VALUES(50, '8610f60f4822e29d53dd955d9770d6ad', '', '', '', '1471601263');
INSERT INTO `update_customers` VALUES(51, '35f39ffb73fb8dff0f0820fdb7df1e28', '', '', '', '1471673357');
INSERT INTO `update_customers` VALUES(52, 'c42d3deb41ee2e603edbd186a89d9c60', '', '', '', '1471673473');
INSERT INTO `update_customers` VALUES(53, '1f6dfe0d2c7123eda3315117866985da', '', '', '', '1471673581');
INSERT INTO `update_customers` VALUES(54, '5149ff765f0cf3c0e2ea44246d063561', '', '', '', '1471695220');
INSERT INTO `update_customers` VALUES(55, '9c627cd0eaddc1120366ab579602eca4', '', '', '', '1471856646');
INSERT INTO `update_customers` VALUES(56, '3886c3d6870d09e6cda6d050a259e883', '', '', '', '1471867960');
INSERT INTO `update_customers` VALUES(57, '8016d1bf0ba88ff1712332d99e074be9', '', '', '', '1471950612');
INSERT INTO `update_customers` VALUES(58, 'e1d8a22d7e17b21cc46a6c581d00fd50', '', '', '', '1471950824');
INSERT INTO `update_customers` VALUES(59, 'bcd4ae88f8e45cea8bd8594bc4a75903', '', '', '', '1471951032');
INSERT INTO `update_customers` VALUES(60, '547f8766e9d8ab0571ecc2f53663ac15', '', '', '', '1471951434');
INSERT INTO `update_customers` VALUES(61, '0100460d25e33a75354877cde98c0659', '', '', '', '1471952103');
INSERT INTO `update_customers` VALUES(62, 'ae5d640745db653a2caa4c19e13a51c7', '', '', '', '1471952259');
INSERT INTO `update_customers` VALUES(63, '7252135b8667f2d094cce6b9859040dc', '', '', '', '1471952625');
INSERT INTO `update_customers` VALUES(64, '51c97f96f597cf2f7622433e540587b8', '', '', '', '1472976213');
INSERT INTO `update_customers` VALUES(65, 'a139e6c4713c2fda4180e18dd5dc42c3', '', '', '', '1473667869');
INSERT INTO `update_customers` VALUES(66, '8c3af5bc9fc1122a64b160dc9ef2f1fc', '', '', '', '1473667991');
INSERT INTO `update_customers` VALUES(67, 'ec648a84238a7308c5f06c83a7a86ccd', '', '', '', '1473668409');
INSERT INTO `update_customers` VALUES(68, '516efbce11ad6745022dd55cf97f8710', '', '', '', '1473670145');
INSERT INTO `update_customers` VALUES(69, 'fc6354b664f894303f8334ae20bf1ba4', '', '', '', '1473671675');
INSERT INTO `update_customers` VALUES(70, 'c782264313b7012644fab4ed99327a84', '', '', '', '1473675435');
INSERT INTO `update_customers` VALUES(71, 'd279a49e653cbc5e0eea366ffae4d111', '', '', '', '1473835324');
INSERT INTO `update_customers` VALUES(72, 'c77f04b57285a611eebe05456e024974', '', '', '', '1474719797');
INSERT INTO `update_customers` VALUES(73, '72f472f382050e216d7b44bf3b588f36', '', '', '', '1474954599');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `userid` varchar(32) NOT NULL,
  `userlevel` tinyint(1) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `valid` tinyint(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `hash` varchar(32) NOT NULL,
  `hash_generated` int(11) NOT NULL,
  `eid` varchar(40) NOT NULL,
  `city` varchar(55) NOT NULL,
  `branch` varchar(44) NOT NULL,
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES('admin', 'ticketingsystem2016', '36d4a4957fcb80bc104a83d6edda22c1', 9, '', '', 1477373725, 0, 'admin', '420aef96512dcabdcebf19d8e3ea5c4c', 1477372648, '', '', '');
INSERT INTO `users` VALUES('arun', 'arun', '608025b8e0106d4066ff65c4cb6271ef', 9, '9999999999', 'arun@zestwings.com', 1484652251, 1, 'Arun', '6a5ef8f4ce063b8e2f94a852bbb9167a', 1484652049, '212121', 'cochin', 'Tiruvanathapuram');
INSERT INTO `users` VALUES('chaitanya', 'chaitanya', '92c4ffe401d69c172b654528f521ed59', 7, '8125016951', 'chaitanya.b@phoenixindia.net', 1474198033, 1, 'Mr. Chaitanya', '9914b7fce1b965e7008688521515b85c', 1474196449, '', '', '');
INSERT INTO `users` VALUES('sekhar', 'sekhar', '03d24d584b09f30bea571b3445362305', 8, '7576757675', 'sekhar@gmail.com', 1470704512, 1, 'Sekhar', '00732a240b12d026de783b9a9907d731', 1470673286, '', '', '');
INSERT INTO `users` VALUES('sunil', 'sunil', '', 7, '5556555655', 'sunil@gmail.com', 1463396880, 1, 'sunil', '', 0, '', '', '');
INSERT INTO `users` VALUES('vidhyamurthy', 'vidhya123', '694486092f093ff5407087fb719279be', 8, '7799677877', 'vidya.vmiyer@gmail.com', 1471858097, 1, 'Mr. Vidhya Murthy', 'd48910c5c06feabdd9a95e23bd16a3cc', 1471854663, '', '', '');
INSERT INTO `users` VALUES('saipriya', 'saipriya@123', 'fb73e5e73db5fd4e2a1f33c82c4e6416', 7, '8142288288', 'saipriya.g@phoenxindia.net', 1473683758, 1, 'Sai Priya', 'e1f9deb4eea633c6ea7210ad54c74690', 1473660922, '', '', '');
INSERT INTO `users` VALUES('suresh', 'suresh', '', 8, '9596959695', 'suresh@gmail.com', 1468918927, 1, 'Suresh', '', 0, '', '', '');
INSERT INTO `users` VALUES('vidhyamurtty', 'vidhya123', '7dec1b6fab6e31b990ac328a0811c583', 8, '7799677877', 'vidya.vmiyer@gmail.com', 1471864498, 1, 'Mr. Vidhyamurtty', '0f459d1cb4ce09d52f6881091746de10', 1471861625, '', '', '');
INSERT INTO `users` VALUES('sivakiran.t', 'siva@123', '159049a7331f45132fbf032010bae9bf', 7, '8886478800', 'sivakiran.t@phoenixindia.net', 1472798436, 1, 'siva kiran reddy', '152890bc658dd6868fa42cc0f1884124', 1472798356, '', '', '');
INSERT INTO `users` VALUES('chaitanaya', 'chaitanaya123', 'e7818ea485c08a62c49606cd7baf6b56', 7, '8125016951', 'chaitanya.b@phoenixindia.net', 1471864903, 1, 'Chaitanya', '900190ecc2cd89215f1c52dcc2c4d0ba', 1471864739, '', '', '');
INSERT INTO `users` VALUES('jayapradag', 'jayaprada@123', '', 7, '9885769423', 'jayapradag@halcyonphoenix.com', 1470636395, 1, 'Jayaprada', '', 0, '', '', '');
INSERT INTO `users` VALUES('bobbyg', 'bobbyg123', '', 7, '9948370707', 'jprada@hotmail.com', 1473835025, 1, 'bobbyg', '', 0, '', '', '');
INSERT INTO `users` VALUES('vinod', 'vinu@123', '55bed560fb1e0410395d800f821f352a', 7, '9445093333', 'vinu@the-village.in', 1474618271, 1, 'Vinod', 'ea924e9fcfaad705b2296d089f280ce6', 1474609286, '', '', '');
INSERT INTO `users` VALUES('antony', 'antony123', 'df37ca17509bdbf9456a3e190a33016f', 8, '9445043333', 'antony@the-ticketingsystem.in', 1474536658, 1, 'Mr. Antony', '68da305a359707eb1423532fd9dba08d', 1474536602, '', '', '');
