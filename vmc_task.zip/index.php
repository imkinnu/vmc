<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<head>

	</head>
	<body>
		<script>
			location.replace("admin/");
		</script>
	</body>
</HTML>
