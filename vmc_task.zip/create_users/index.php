<?php
include('../include/session.php');

if(!$session->logged_in){
?>
<script type="text/javascript">
setStateGet('main','<?php echo SECURE_PATH;?>login_process.php','loginForm=1');
</script>

<?php
}
else{
	?>
    <div  id="adminForm" style="margin:2% 0 0 0;background-color:#fff;padding:10px;">
    	<script>
			setState('adminForm','<?php echo SECURE_PATH; ?>create_users/process.php','addForm=1');
		</script>
    </div>
     <div id="adminTable" style="margin:3% 0 5% 0;background-color:#fff;padding:10px;">
    	<script>
			setState('adminTable','<?php echo SECURE_PATH; ?>create_users/process.php','tableDisplay=1');
		</script>
    </div>
    <?php
	}
?>