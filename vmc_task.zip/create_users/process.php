<?php

include('../include/session.php');

if(!$session->logged_in){

?>
<script type="text/javascript">

setStateGet('main','<?php echo SECURE_PATH;?>login_process.php','loginForm=1');

</script>
<?php

}

?>
		<script src="<?php echo SECURE_PATH; ?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="<?php echo SECURE_PATH; ?>assets/plugins/datatables/dataTables.bootstrap.js"></script>
		<script src="<?php echo SECURE_PATH; ?>assets/plugins/datatables/dataTables.buttons.min.js"></script>
		<script src="<?php echo SECURE_PATH; ?>assets/plugins/datatables/buttons.bootstrap.min.js"></script>
		<script src="<?php echo SECURE_PATH; ?>assets/plugins/datatables/dataTables.responsive.min.js"></script>
		<script src="<?php echo SECURE_PATH; ?>assets/pages/datatables.init.js"></script>
		<script>
			jQuery(document).ready(function () {
				//Data Tables
				$('#datatable').dataTable();
				$('#datatable-responsive').DataTable();
            // Date Picker
            $('.datepicker, #datepicker2, #datepicker3').datepicker({
                format: "dd-mm-yyyy"
            });
            // Select2
            $(".select2").select2();				
			});
		</script>

<?php

if(isset($_REQUEST['addForm']))
{
	if($_REQUEST['addForm'] == 2 && isset($_REQUEST['editform']))
	{
		$data_sel = $database->query("SELECT * FROM users_new WHERE username = '".$_REQUEST['editform']."'");
		if(mysqli_num_rows($data_sel) > 0)
		{
			$data = mysqli_fetch_array($data_sel);
			$_REQUEST = array_merge($_REQUEST,$data);
   		}

	}

	?>
    <div class="content">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="alert-initiator">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="alert-form">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h3 class="has-lines">Create / Edit Users</h3>
                                                </div>
                                                <div class="col-md-3 col-sm-4 col-xs-6 form-group">
                                                    <label for="datepicker">Username<span class="error">*</span></label>
                                                    <input type="text" class="form-control" name="username" id="username" 
                                                    value="<?php if(isset($_REQUEST['username'])){ echo $_REQUEST['username'];} ?>"
                                                    onkeyup="setState('uname','<?php echo SECURE_PATH; ?>create_users/process.php','checkuser=true&user='+$(this).val())"
                                                    >
                                                    <span class="error" id="uname">
                                                    	<?php if(isset($_SESSION['error']['username'])){ echo $_SESSION['error']['username'];}?>
                                                    </span>
                                                </div>
                                                <div class="col-md-3 col-sm-4 col-xs-6 form-group">
                                                    <label class="time">Password<span class="error">*</span></label>
                                                    <input type="password" class="form-control" name="password" id="password"
                                                    value="<?php if(isset($_REQUEST['password'])){ echo $_REQUEST['password'];} ?>">
                                                    <span class="error">
                                                    <?php if(isset($_SESSION['error']['password'])){ echo $_SESSION['error']['password'];}?>
                                                    </span>
                                                </div>
                                                <div class="col-md-3 col-sm-4 col-xs-6 form-group">
                                                    <label class="time">E Mail</label>
                                                    <input type="text" class="form-control" name="email" id="email"
                                                    value="<?php if(isset($_REQUEST['email'])){ echo $_REQUEST['email'];} ?>">
                                                    <span class="error">
                                                    <?php if(isset($_SESSION['error']['time'])){ echo $_SESSION['error']['time'];}?>
                                                    </span>
                                                </div>
                                                <div class="col-md-3 col-sm-4 col-xs-6 form-group">
                                                    <label class="time">Mobile Number</label>
                                                    <input type="text" class="form-control" name="mobile" id="mobile" 
                                                    value="<?php if(isset($_REQUEST['mobile'])){ echo $_REQUEST['mobile'];} ?>">
                                                    <span class="error">
                                                    <?php if(isset($_SESSION['error']['mobile'])){ echo $_SESSION['error']['mobile'];}?>
                                                    </span>
                                                </div>
                                                </div>
                                                <div class="row">
                                                <div class="col-md-3 col-sm-4 col-xs-6 form-group">
                                                    <label for="selecthazard">User Level<span class="error">*</span></label>
                                                   <select class="form-control select2" name="userlevel" id="userlevel">
                                                        <option value="">Level</option>
                                                        <option value="1" <?php if(isset($_REQUEST['userlevel'])){ if($_REQUEST['userlevel']==1){ echo 'selected="selected"';} } ?>>Alert Initiator</option>
                                                        <option value="2" <?php if(isset($_REQUEST['userlevel'])){ if($_REQUEST['userlevel']==2){ echo 'selected="selected"';} } ?>>Calls Initiator</option>
                                                        <option value="3" <?php if(isset($_REQUEST['userlevel'])){ if($_REQUEST['userlevel']==3){ echo 'selected="selected"';} } ?>>Message Initiator</option>	
                                                        <option value="9" <?php if(isset($_REQUEST['userlevel'])){ if($_REQUEST['userlevel']==9){ echo 'selected="selected"';} } ?>>Admin</option>				
                                                    </select>
                                                    <span class="error">
                                                    <?php if(isset($_SESSION['error']['userlevel'])){ echo $_SESSION['error']['userlevel'];}?>
                                                    </span>
                                                </div>
                                                <div class="col-md-3 col-sm-4 col-xs-6 form-group">
                                                    <label class="time">Name</label>
                                                    <input type="text" class="form-control" name="name" id="name" 
                                                    value="<?php if(isset($_REQUEST['name'])){ echo $_REQUEST['name'];} ?>">
                                                    <span class="error">
                                                    	<?php if(isset($_SESSION['error']['name'])){ echo $_SESSION['error']['name'];}?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <input type="button" class="btn btn-md btn-primary" 
                                                    onClick="setState('adminForm','<?php echo SECURE_PATH;?>create_users/process.php','validateForm=1&username='+$('#username').val()+'&password='+$('#password').val()+'&email='+$('#email').val()+'&mobile='+$('#mobile').val()+'&userlevel='+$('#userlevel').val()+'&name='+$('#name').val()+'<?php if(isset($_REQUEST['editform'])){ echo '&editform='.$_REQUEST['editform'];}?>')" value="Submit" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            </div>
										  					
	 <?php
     
	 unset($_SESSION['error']);

}


if(isset($_REQUEST['validateForm']))
{
	


	$_SESSION['error'] = array();

	

	$post = $session->cleanInput($_REQUEST);


	if(!isset($post['editform']))
	{ 	
		$q1=$database->query("SELECT username FROM users_new WHERE username='".$post['username']."'");
		if(mysqli_num_rows($q1)>0)
		{
			$_SESSION['error']['username'] = "*Username already exists";
		}
	}

	$field = 'username';
	if(!isset($post[$field]) || strlen($post[$field]) == 0)
	{
		$_SESSION['error'][$field] = "*Please Enter username";
	}

	
	$field = 'password';
	if(!isset($post[$field]) || strlen($post[$field]) == 0)
	{
		$_SESSION['error'][$field] = "*Please Enter password";
	}	

	$field = 'userlevel';
	if(!isset($post[$field]) || strlen($post[$field]) == 0)
	{
		$_SESSION['error'][$field] = "*Please Select userlevel";
	}
	
		


//Check if any errors exist	

	if(count($_SESSION['error']) > 0 || $post['validateForm'] == 2)
	{
		?>
        
		<script type="text/javascript">
		setState('adminForm','<?php echo SECURE_PATH;?>create_users/process.php','addForm=1&username=<?php echo $post['username']; ?>&password=<?php echo $post['password']; ?>&email=<?php echo $post['email']; ?>&mobile=<?php echo $post['mobile']; ?>&userlevel=<?php echo $post['userlevel']; ?>&name=<?php echo $post['name']; ?>'+'<?php if(isset($_REQUEST['editform'])){ echo '&editform='.$_REQUEST['editform'];}?>');
		</script>
		<?php	
	}

	else
	{
		if(!isset($post['editform'])){
		$ins=$database->query("INSERT INTO users_new VALUES ('".$post['username']."','".$post['password']."','','".$post['email']."','".$post['mobile']."','".$post['userlevel']."','".$post['name']."','1')");
		}
		else
		{
			$ins=$database->query("UPDATE users_new SET password='".$post['password']."',email='".$post['email']."',mobile='".$post['mobile']."',userlevel='".$post['userlevel']."',name='".$post['name']."' WHERE username='".$post['username']."'");
		}
		
		if(!$ins) { echo mysqli_error($database->connection); }
		
		else
		{
			?>	
			<div class="alert alert-success " id="sucmsg"><i class="fa fa-thumbs-up fa-2x"></i>Information saved successfully!</div>
			<script type="text/javascript">
				setTimeout(function(){ 
						$('#sucmsg').hide(); setState('adminForm','<?php echo SECURE_PATH; ?>create_users/process.php','addForm=1'); 
						setState('adminTable','<?php echo SECURE_PATH; ?>create_users/process.php','tableDisplay=1')
					},3000);
			</script>
			<?php
		}
	}
}

if(isset($_REQUEST['tableDisplay']))
{
	$con='';
	$st=strtotime(date("d-m-Y")." 00:00:00");$tt=time();
	if(isset($_REQUEST['fromdate']) && isset($_REQUEST['todate']))
	{
		if(strlen($_REQUEST['fromdate'])>0  && strlen($_REQUEST['todate'])>0)
		{
			$st=strtotime($_REQUEST['fromdate']." 00:00:00");$tt=strtotime($_REQUEST['todate']." 23:59:59");
		}
	}
	
	//$con=" AND ( timestamp BETWEEN ".$st." AND ".$tt.")";
	
	if(isset($_REQUEST['hazard']) && strlen($_REQUEST['hazard'])>0)
	{
		if(strlen($con)>0)
		{
			$con.=" AND hazard='".$_REQUEST['hazard']."'";
		}
	}
	?>
    <div class="content">
        <div class="container">
        	<div id="dummy"></div>
        	<div class="row">
                <div class="col-sm-12">
                	<?php
						
						$q1=$database->query("SELECT * FROM users_new");
						if(mysqli_num_rows($q1)>0)
						{
							$sno=1;
					?>
                    <div class="card-box apgdc-data-table table-responsive">
                        <table id="datatable-responsive"
                        class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                        width="100%">
                            <thead>
                                <tr>
                                    <th class="text-center">S.No&nbsp;</th>
                                    <th class="text-center">Username</th>
                                    <th class="text-center">Password</th>
                                    <th class="text-center">Name</th>                                    
                                    <th class="text-center">E-Mail</th>
                                    <th class="text-center">Mobile</th>
                                    <th class="text-center">UserLevel</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            	<?php
									while($row=mysqli_fetch_assoc($q1))
									{

										?>
                                        <tr>
                                        	<td><?php echo $sno; ?></td>
                                            <td><?php echo $row['username']; ?></td>
                                            <td><?php echo $row['password']; ?></td>
                                            <td><?php echo $row['name']; ?></td>
                                            <td><?php echo $row['email']; ?></td>
                                            <td><?php echo $row['mobile']; ?></td>
                                            <td>
                                            	<?php
												if($row['userlevel']==1){ echo "Alert Initiator"; }
												else if($row['userlevel']==2){ echo "Calls Initiator"; }
												else if($row['userlevel']==3){ echo "Message Initiator"; }
												else if($row['userlevel']==9){ echo "Admin"; }
												?>
                                            </td>
                                            <td>
                                            	<input type="button" class="btn btn-sm btn-info" value="Edit" onclick="setState('adminForm','<?php echo SECURE_PATH;?>create_users/process.php','addForm=2&editform=<?php echo $row['username']; ?>');" /><br />
                                                <?php if($row['valid']==1)
												{ 
													?>
														<input type="button" class="btn btn-sm btn-success m-top-5" value="Enable" 
                                                        onclick="" />
													<?php 
												} 
												else
												{
													?>
														<input type="button" class="btn btn-sm btn-danger m-top-5" value="Disable" onclick="" />
													<?php 
												}
												 ?>
                                            </td>
                                        </tr>
                                        <?php
										$sno++;
									}
								?>
                            </tbody>
                        </table>
                    </div>
                    <?php
						}
						else
						{
							?>
                            <div class="alert alert-danger">No Results Found</div>
                            <?php
						}
					?>
                </div>
        </div>
        </div>
    </div>
    <?php
}


if(isset($_REQUEST['checkuser']))
{
	$q1=$database->query("SELECT username FROM users_new WHERE username='".$_REQUEST['user']."'");
	if(mysqli_num_rows($q1)>0)
	{
		echo "Username already exists";
	}
	else
		echo "Username Available";
}

//Delete events 
					?>	
