<?php
include('../include/session.php');

if(!$session->logged_in){
?>
<script type="text/javascript">
window.location = '<?php echo SECURE_PATH?>emp/';
</script>

<?php
}
else{
?>
<section class="wrapper">
              <!-- page start-->
              <div class="row">
                <div class="col-sm-12">
             
             


<section class="panel">
                          <div class="panel-body">
                          
                         <div id="addForm" class="mt-4">

<script type="text/javascript">

setStateGet('addForm','<?php echo SECURE_PATH;?>settings/process.php','addForm=2&editform=<?php echo $session->username;?>');

</script>


                          </div>
                      </section>

               
               
              </div>
              </div>
              
              <!-- page end-->
          </section>



<script type="text/javascript">

function userControl(val){

if(val== '9'){

$('#userfunc').text('Can Edit/Delete: Notifications,Users;View & Download  Files;Dashboard');

$('#politician').slideUp();

}
else if(val == '5'){
$('#userfunc').text('App Login & Usage; Manage Account, Notifications and Files uploaded');
$('#politician').slideDown();
}

else if(val == '0'){$('#userfunc').text('');


	$('#politician').slideUp();
}




}


</script>
<?php
}
?>