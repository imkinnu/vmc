<?php
include('../include/session.php');

if(!$session->logged_in){
?>
<script type="text/javascript">
setStateGet('main','<?php echo SECURE_PATH;?>login_process.php','loginForm=1');
</script>

<?php
}

//Metircs Forms, Tables and Functions
//Display users form
if(isset($_REQUEST['addForm'])){
	
	if($_REQUEST['addForm'] == 2 && isset($_REQUEST['editform'])){
   
   $data_sel = $database->query("SELECT * FROM users WHERE username = '".$_REQUEST['editform']."'");
   
   if(mysqli_num_rows($data_sel) > 0){
   $data = mysqli_fetch_array($data_sel);

  $_POST = array_merge($_POST,$data);

    
   }
}

	?>
<div class="content-wrapper">
<!-- Content Area-->
<section class="content-area">
<div class="container mt-4">
<div class="row">
<div class="col-xl-12 col-lg-12">
<div class="card border-0 shadow mb-4">
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">User Settings</h6>
    </div>
<div class="card-body">
<form role="form">
 <div class="form-group">
    <label for="user">Full Name</label>

    <input type="text" name="name" placeholder="Full Name" class="form-control" id="name" value="<?php if(isset($_POST['name'])){ echo $_POST['name'];}?>"  />
    <span class="error"><?php if(isset($_SESSION['error']['name'])){ echo $_SESSION['error']['name'];}?></span>
  </div>

  <div class="form-group">
    <label for="user">Username</label>

    <input type="text" name="username" disabled="disabled" placeholder="Username" class="form-control" id="username" value="<?php if(isset($_POST['username'])){ echo $_POST['username'];}?>"  />
    <span class="error"><?php if(isset($_SESSION['error']['username'])){ echo $_SESSION['error']['username'];}?></span>
  </div>



  <div class="form-group">
    <label for="password">New Password</label>

    <input type="password" name="password" class="form-control" id="password" value=""  />
    <span class="error"><?php if(isset($_SESSION['error']['password'])){ echo $_SESSION['error']['password'];}?></span>
  </div>
  <div class="form-group">
    <label for="c_password">Confirm Password</label>

    <input type="password" name="c_password" class="form-control" id="cpassword" value=""  />
    <span class="error"><?php if(isset($_SESSION['error']['c_password'])){ echo $_SESSION['error']['c_password'];}?></span>
  </div>

  <div class="form-group">
    <label for="email">Email</label>

    <input type="text" name="email" placeholder="Email ID" class="form-control" id="email" value="<?php if(isset($_POST['email'])){ echo $_POST['email'];}?>"  />
    <span class="error"><?php if(isset($_SESSION['error']['email'])){ echo $_SESSION['error']['email'];}?></span>
  </div>


  <div class="form-group">
    <label for="mobile">Mobile</label>
<div class="input-group">
  <span class="input-group-addon">+91</span>
<input type="text" name="mobile" placeholder="10-digit Mobile number" class="form-control" id="mobile" value="<?php if(isset($_POST['mobile'])){ echo $_POST['mobile'];}?>"  />

</div>
    <span class="error"><?php if(isset($_SESSION['error']['mobile'])){ echo $_SESSION['error']['mobile'];}?></span>
  </div>

    <div class="row">
        <div class="form-group col-lg-2">
            <input type="button" class="btn btn-info" onClick="setState('result','<?php echo SECURE_PATH;?>settings/process.php','validateForm=1&name='+$('#name').val()+'&username='+$('#username').val()+'&cpassword='+$('#cpassword').val()+'&password='+$('#password').val()+'&email='+$('#email').val()+'&mobile='+$('#mobile').val()+'&userlevel='+$('#userlevel').val()+'<?php if(isset($_POST['editform'])){ echo '&editform='.$_POST['editform'];} ?>')" value="Save">
        </div>
        <div id="result" class="mt-1 col-lg-6">
        </div>
    </div>

</form>
</div>
</div>
</div>
</div>
</div>
</section>
</div>



    <?php
	unset($_SESSION['error']);
}



//Process and Validate POST data
if(isset($_POST['validateForm'])){
	$_SESSION['error'] = array();

	$post = $session->cleanInput($_POST);


	 	$id = 'NULL';
		  $mobile = $post['mobile'];
		  $email = $post['email'];
		   $name = $post['name'];

	if(isset($post['editform'])){
	  $id = $post['editform'];

	}
$field = 'mobile';
	if(!$mobile || strlen(trim($mobile)) == 0){
	  $_SESSION['error'][$field] = "* Mobile cannot be empty";
	}
    else if(strlen($mobile) < 10){
            $_SESSION['error'][$field] = "* Mobile number below 10 digits";
     }
    else if(strlen($mobile) > 10){
             $_SESSION['error'][$field] = "* Mobile number above 10 digits";
      }
     /* mobile number check */
     else if(!preg_match("~^([7-8-9]{1}[0-9]{9})+$~", $mobile)){
             $_SESSION['error'][$field] = "* Invalid Mobile number";
      }


	$field = 'email';
	if(!$email || strlen(trim($email)) == 0){
	  $_SESSION['error'][$field] = "* Email cannot be empty";
	}
	elseif(strlen($email) > 0){
         /* Check if valid email address */
         $regex = "~^[_+a-z0-9-]+(\.[_+a-z0-9-]+)*"
                 ."@[a-z0-9-]+(\.[a-z0-9-]{1,})*"
                 ."\.([a-z]{2,}){1}$~";

		        $email = stripslashes($email);
		 if(!preg_match($regex,$email)){
           $_SESSION['error'][$field] = "* Invalid Email ID";
         }

	}

	$field = 'password';
	if(!$post['password'] || strlen(trim($post['password'])) == 0){
	  $_SESSION['error'][$field] = "* Password cannot be empty";
	}
	else if(strlen(trim($post['password'])) < 4){
      $_SESSION['error'][$field] = "* Length of Password Very low. Use atleast 4 Characters";

	}

	$field = 'cpassword';
	if(!$post['cpassword'] || strlen(trim($post['cpassword'])) == 0){
	  $_SESSION['error'][$field] = "*Confirm Password cannot be empty";
	}



	else if(strlen(trim($post['cpassword']))> 0){
		  if($post['cpassword'] != $post['password'])
      $_SESSION['error'][$field] = "* Passwords do not match";

	}



if(strlen(trim($name)) == 0){
	$name = $post['username'];
}

//Check if any errors exist
	if(count($_SESSION['error']) > 0 || $post['validateForm'] == 2){
	?>
    <script type="text/javascript">
    $('#addForm').slideDown();

	setState('addForm','<?php echo SECURE_PATH;?>settings/process.php','addForm=1&username=<?php echo $post['username'];?>&password=<?php echo $post['password'];?>&email=<?php echo $post['email'];?>&mobile=<?php echo $post['mobile'];?><?php if(isset($_POST['editform'])){ echo '&editform='.$post['editform'];}?>')
	
    </script>
    
<?php	
	}
	else{
		$employeeSql = $database->query("update employee set employee_name = '".$name."',mobile='".$mobile."',email='".$email."' ");
		if($employeeSql) {
            $updateUsers = $database->query("UPDATE users SET password = '".md5($post['password'])."', name = '".$name."', email = '".$post['email']."', mobile = '".$post['mobile']."' WHERE username = '".$post['username']."'");
        }
		if($employeeSql && $updateUsers)
        {
            echo "<span class='alert alert-success'>Details Succesfully Updated</span>"; ?>
            <script>
                setTimeout(function () {
                    setState('addForm','<?php echo SECURE_PATH;?>settings/process.php','addForm=2&editform=<?php echo $session->username;?>');
                },2000)
            </script>
        <?php }
	}
}